import SwiftUI

/// Bộ nhớ tạm của ứng dụng: sao chép ở một nơi, tự đi tới thư mục khác rồi bấm Dán
@MainActor
final class AppClipboard: ObservableObject {
    static let shared = AppClipboard()
    @Published private(set) var localURLs: [URL] = []
    @Published private(set) var driveFiles: [DriveFile] = []

    var count: Int { localURLs.count + driveFiles.count }
    var isEmpty: Bool { count == 0 }
    var sourceLabel: String { driveFiles.isEmpty ? "Jinn Files" : "Google Drive" }

    func setLocal(_ urls: [URL]) { localURLs = urls; driveFiles = [] }
    func setDrive(_ files: [DriveFile]) { driveFiles = files; localURLs = [] }
    func clear() { localURLs = []; driveFiles = [] }
}

/// Thanh nổi "Dán" hiện khi đã sao chép
struct PasteBar: View {
    @EnvironmentObject private var clipboard: AppClipboard
    let onPaste: () -> Void

    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: "doc.on.clipboard.fill").foregroundStyle(Color.accentColor).font(.title3)
            VStack(alignment: .leading, spacing: 1) {
                Text("Đã sao chép \(clipboard.count) mục").font(.subheadline.weight(.semibold))
                Text("Từ \(clipboard.sourceLabel) • mở thư mục đích rồi bấm Dán")
                    .font(.caption2).foregroundStyle(.secondary).lineLimit(1)
            }
            Spacer(minLength: 4)
            Button { onPaste() } label: { Text("Dán").fontWeight(.semibold).padding(.horizontal, 6) }
                .glassButtonStyle(prominent: true)
            Button { clipboard.clear() } label: { Image(systemName: "xmark.circle.fill").foregroundStyle(.secondary).font(.title3) }
                .buttonStyle(.plain)
        }
        .padding(.horizontal, 14).padding(.vertical, 10)
        .glassSurface(cornerRadius: 26)
        .padding(.horizontal, 16).padding(.bottom, 6)
    }
}

/// Thông báo nổi ngắn ở đầu màn hình
struct ToastModifier: ViewModifier {
    @Binding var message: String?

    func body(content: Content) -> some View {
        content
            .overlay(alignment: .top) {
                if let m = message {
                    Text(m)
                        .font(.footnote.weight(.medium))
                        .multilineTextAlignment(.center)
                        .padding(.horizontal, 16).padding(.vertical, 10)
                        .glassSurface(cornerRadius: 20)
                        .padding(.top, 8).padding(.horizontal, 20)
                        .transition(.move(edge: .top).combined(with: .opacity))
                        .task(id: m) {
                            try? await Task.sleep(nanoseconds: 2_400_000_000)
                            withAnimation { message = nil }
                        }
                }
            }
            .animation(.easeInOut(duration: 0.25), value: message)
    }
}

extension View {
    func toast(_ message: Binding<String?>) -> some View { modifier(ToastModifier(message: message)) }
}
