import SwiftUI
import UniformTypeIdentifiers

struct DriveFolderRef: Hashable {
    let id: String
    let name: String
    static let root = DriveFolderRef(id: "root", name: "Google Drive")
}

struct DriveFile: Identifiable, Hashable {
    let id: String
    let name: String
    let mime: String
    let size: Int64?
    let modified: Date?
    let thumbnail: String?
    let webLink: String?
    let parents: [String]

    var isFolder: Bool { mime == "application/vnd.google-apps.folder" }
    /// Tài liệu Google (Docs, Sheets, Slides...) không có nội dung gốc, phải xuất sang PDF
    var isGoogleDoc: Bool { mime.hasPrefix("application/vnd.google-apps.") && !isFolder }
    var kind: Kind {
        if isFolder { return .folder }
        if isGoogleDoc { return .pdf }
        return Kind.detect(URL(fileURLWithPath: name), isDirectory: false)
    }
    var ref: DriveFolderRef { DriveFolderRef(id: id, name: name) }
    var safeName: String {
        let n = (isGoogleDoc ? name + ".pdf" : name).replacingOccurrences(of: "/", with: "-")
        return n.isEmpty ? "tệp" : n
    }
}

struct DriveError: LocalizedError {
    let code: Int
    let message: String
    var errorDescription: String? { message }
}

/// Gọi Google Drive API v3 bằng REST
enum DriveAPI {
    static let base = "https://www.googleapis.com/drive/v3"
    static let fileFields = "id,name,mimeType,size,modifiedTime,thumbnailLink,webViewLink,parents"

    private static let transferSession: URLSession = {
        let c = URLSessionConfiguration.default
        c.timeoutIntervalForRequest = 600
        c.timeoutIntervalForResource = 14400
        c.waitsForConnectivity = true
        return URLSession(configuration: c)
    }()

    // MARK: Hỗ trợ

    private static func esc(_ s: String) -> String {
        s.replacingOccurrences(of: "\\", with: "\\\\").replacingOccurrences(of: "'", with: "\\'")
    }

    private static func friendly(_ d: Data, _ code: Int) -> DriveError {
        let o = (try? JSONSerialization.jsonObject(with: d)) as? [String: Any]
        let err = o?["error"] as? [String: Any]
        let msg = err?["message"] as? String ?? "Mã lỗi \(code)"
        let reason = (err?["errors"] as? [[String: Any]])?.first?["reason"] as? String ?? ""
        var text = "Google Drive: \(msg)"
        if reason == "accessNotConfigured" || msg.contains("has not been used") || msg.contains("is disabled") {
            text += "\n(Hãy bật Google Drive API trong Google Cloud: APIs & Services → Library → Google Drive API → Enable.)"
        } else if code == 403 && reason == "insufficientPermissions" {
            text += "\n(Hãy đăng nhập lại ở tab Tài khoản để cấp quyền Google Drive.)"
        }
        return DriveError(code: code, message: text)
    }

    private static func iso(_ s: String?) -> Date? {
        guard let s else { return nil }
        let f1 = ISO8601DateFormatter()
        let f2 = ISO8601DateFormatter(); f2.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        return f1.date(from: s) ?? f2.date(from: s)
    }

    static func parse(_ o: [String: Any]) -> DriveFile? {
        guard let id = o["id"] as? String, let name = o["name"] as? String else { return nil }
        return DriveFile(id: id, name: name, mime: o["mimeType"] as? String ?? "",
                         size: (o["size"] as? String).flatMap { Int64($0) },
                         modified: iso(o["modifiedTime"] as? String),
                         thumbnail: o["thumbnailLink"] as? String,
                         webLink: o["webViewLink"] as? String,
                         parents: o["parents"] as? [String] ?? [])
    }

    private static func parseData(_ d: Data) -> DriveFile? {
        guard let o = (try? JSONSerialization.jsonObject(with: d)) as? [String: Any] else { return nil }
        return parse(o)
    }

    @discardableResult
    static func send(_ url: URL, method: String = "GET", json: [String: Any]? = nil) async throws -> Data {
        for attempt in 0..<2 {
            let token = try await GoogleAuth.shared.accessToken(forceRefresh: attempt == 1)
            var r = URLRequest(url: url)
            r.httpMethod = method
            r.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
            if let json {
                r.setValue("application/json; charset=UTF-8", forHTTPHeaderField: "Content-Type")
                r.httpBody = try JSONSerialization.data(withJSONObject: json)
            }
            let (d, resp) = try await URLSession.shared.data(for: r)
            let code = (resp as? HTTPURLResponse)?.statusCode ?? 0
            if code == 401 && attempt == 0 { continue }
            guard (200..<300).contains(code) else { throw friendly(d, code) }
            return d
        }
        throw AppError("Phiên đăng nhập bị từ chối, hãy đăng nhập lại.")
    }

    private static func filesURL(_ path: String = "", _ items: [URLQueryItem] = []) -> URL {
        var c = URLComponents(string: base + "/files" + path)!
        c.queryItems = items
        return c.url!
    }

    // MARK: Liệt kê / tìm kiếm

    static func list(parent: String, foldersOnly: Bool = false, pageToken: String? = nil) async throws -> ([DriveFile], String?) {
        var q = "'\(esc(parent))' in parents and trashed = false"
        if foldersOnly { q += " and mimeType = 'application/vnd.google-apps.folder'" }
        return try await query(q, pageToken: pageToken)
    }

    static func search(_ text: String) async throws -> [DriveFile] {
        try await query("name contains '\(esc(text))' and trashed = false", pageToken: nil).0
    }

    private static func query(_ q: String, pageToken: String?) async throws -> ([DriveFile], String?) {
        var items: [URLQueryItem] = [
            .init(name: "q", value: q),
            .init(name: "fields", value: "nextPageToken,files(\(fileFields))"),
            .init(name: "pageSize", value: "100"),
            .init(name: "orderBy", value: "folder,name")
        ]
        if let t = pageToken { items.append(.init(name: "pageToken", value: t)) }
        let d = try await send(filesURL("", items))
        let o = (try? JSONSerialization.jsonObject(with: d)) as? [String: Any] ?? [:]
        let files = (o["files"] as? [[String: Any]] ?? []).compactMap(parse)
        return (files, o["nextPageToken"] as? String)
    }

    // MARK: Tạo / sửa / di chuyển / xóa

    @discardableResult
    static func createFolder(name: String, parent: String) async throws -> DriveFile {
        let d = try await send(filesURL("", [.init(name: "fields", value: fileFields)]), method: "POST",
                               json: ["name": name, "mimeType": "application/vnd.google-apps.folder", "parents": [parent]])
        guard let f = parseData(d) else { throw AppError("Không tạo được thư mục.") }
        return f
    }

    static func rename(_ id: String, to name: String) async throws {
        try await send(filesURL("/\(id)", [.init(name: "fields", value: "id")]), method: "PATCH", json: ["name": name])
    }

    static func move(_ f: DriveFile, to parent: String) async throws {
        var items: [URLQueryItem] = [.init(name: "addParents", value: parent), .init(name: "fields", value: "id")]
        if !f.parents.isEmpty { items.append(.init(name: "removeParents", value: f.parents.joined(separator: ","))) }
        try await send(filesURL("/\(f.id)", items), method: "PATCH", json: [:])
    }

    static func copy(_ f: DriveFile, to parent: String) async throws {
        try await send(filesURL("/\(f.id)/copy", [.init(name: "fields", value: "id")]), method: "POST",
                       json: ["name": f.name, "parents": [parent]])
    }

    /// Chuyển vào thùng rác của Google Drive (giữ 30 ngày, khôi phục được trong Drive)
    static func trash(_ id: String) async throws {
        try await send(filesURL("/\(id)", [.init(name: "fields", value: "id")]), method: "PATCH", json: ["trashed": true])
    }

    static func deleteForever(_ id: String) async throws {
        try await send(filesURL("/\(id)"), method: "DELETE")
    }

    // MARK: Tải xuống

    private static func downloadURL(_ f: DriveFile) -> URL {
        if f.isGoogleDoc {
            return filesURL("/\(f.id)/export", [.init(name: "mimeType", value: "application/pdf")])
        }
        return filesURL("/\(f.id)", [.init(name: "alt", value: "media")])
    }

    static func streamURL(_ f: DriveFile) -> URL { downloadURL(f) }

    /// Tải một tệp về đúng đường dẫn đích (đi qua tệp tạm nên không để lại tệp dở dang)
    static func download(_ f: DriveFile, to dest: URL) async throws {
        for attempt in 0..<2 {
            let token = try await GoogleAuth.shared.accessToken(forceRefresh: attempt == 1)
            var r = URLRequest(url: downloadURL(f))
            r.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
            let (tmp, resp) = try await transferSession.download(for: r)
            let code = (resp as? HTTPURLResponse)?.statusCode ?? 0
            if code == 401 && attempt == 0 { try? FileManager.default.removeItem(at: tmp); continue }
            guard code == 200 else {
                let d = (try? Data(contentsOf: tmp)) ?? Data()
                try? FileManager.default.removeItem(at: tmp)
                throw friendly(d, code)
            }
            try FileManager.default.createDirectory(at: dest.deletingLastPathComponent(), withIntermediateDirectories: true)
            try? FileManager.default.removeItem(at: dest)
            try FileManager.default.moveItem(at: tmp, to: dest)
            return
        }
        throw AppError("Phiên đăng nhập bị từ chối, hãy đăng nhập lại.")
    }

    /// Tải tệp hoặc cả thư mục (đệ quy) vào một thư mục trên máy
    @discardableResult
    static func downloadTree(_ f: DriveFile, into dir: URL) async throws -> URL {
        if f.isFolder {
            let local = FileOps.uniqueURL(dir: dir, name: f.safeName)
            try FileManager.default.createDirectory(at: local, withIntermediateDirectories: true)
            var token: String?
            repeat {
                let (files, next) = try await list(parent: f.id, pageToken: token)
                for c in files { try await downloadTree(c, into: local) }
                token = next
            } while token != nil
            return local
        }
        try FileOps.checkSpace(needed: f.size ?? 0)
        let dest = FileOps.uniqueURL(dir: dir, name: f.safeName)
        try await download(f, to: dest)
        return dest
    }

    // MARK: Bộ nhớ đệm xem trước

    static var cacheDir: URL { FileManager.default.temporaryDirectory.appendingPathComponent("drive-cache", isDirectory: true) }

    static func cachedFile(_ f: DriveFile) async throws -> URL {
        let stamp = Int(f.modified?.timeIntervalSince1970 ?? 0)
        let dir = cacheDir.appendingPathComponent("\(f.id)-\(stamp)", isDirectory: true)
        let dest = dir.appendingPathComponent(f.safeName)
        if FileManager.default.fileExists(atPath: dest.path) { return dest }
        try await download(f, to: dest)
        return dest
    }

    static func clearCache() { try? FileManager.default.removeItem(at: cacheDir) }

    // MARK: Hình thu nhỏ (cần xác thực)

    private static let thumbCache = NSCache<NSString, UIImage>()

    static func thumbnail(_ f: DriveFile) async -> UIImage? {
        guard var link = f.thumbnail else { return nil }
        if let c = thumbCache.object(forKey: f.id as NSString) { return c }
        link = link.replacingOccurrences(of: "=s220", with: "=s400")
        guard let url = URL(string: link), let token = try? await GoogleAuth.shared.accessToken() else { return nil }
        var r = URLRequest(url: url)
        r.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        guard let (d, resp) = try? await URLSession.shared.data(for: r),
              (resp as? HTTPURLResponse)?.statusCode == 200, let img = UIImage(data: d) else { return nil }
        thumbCache.setObject(img, forKey: f.id as NSString)
        return img
    }

    // MARK: Tải lên (resumable, phát trực tiếp từ tệp, không nạp vào RAM)

    static func upload(file: URL, name: String, parent: String,
                       progress: @escaping @Sendable (Double) -> Void) async throws {
        let size = Int64((try? file.resourceValues(forKeys: [.fileSizeKey]))?.fileSize ?? 0)
        let mime = UTType(filenameExtension: file.pathExtension.lowercased())?.preferredMIMEType ?? "application/octet-stream"
        if size == 0 {
            try await send(filesURL("", [.init(name: "fields", value: "id")]), method: "POST",
                           json: ["name": name, "parents": [parent]])
            progress(1)
            return
        }
        for attempt in 0..<2 {
            let token = try await GoogleAuth.shared.accessToken(forceRefresh: attempt == 1)
            // Bước 1: mở phiên tải lên
            var c = URLComponents(string: "https://www.googleapis.com/upload/drive/v3/files")!
            c.queryItems = [.init(name: "uploadType", value: "resumable"), .init(name: "fields", value: "id")]
            var r = URLRequest(url: c.url!)
            r.httpMethod = "POST"
            r.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
            r.setValue("application/json; charset=UTF-8", forHTTPHeaderField: "Content-Type")
            r.setValue(mime, forHTTPHeaderField: "X-Upload-Content-Type")
            r.setValue(String(size), forHTTPHeaderField: "X-Upload-Content-Length")
            r.httpBody = try JSONSerialization.data(withJSONObject: ["name": name, "parents": [parent]])
            let (d, resp) = try await URLSession.shared.data(for: r)
            let code = (resp as? HTTPURLResponse)?.statusCode ?? 0
            if code == 401 && attempt == 0 { continue }
            guard code == 200, let loc = (resp as? HTTPURLResponse)?.value(forHTTPHeaderField: "Location"),
                  let sessionURL = URL(string: loc) else { throw friendly(d, code) }

            // Bước 2: gửi nội dung tệp
            var put = URLRequest(url: sessionURL)
            put.httpMethod = "PUT"
            put.setValue(mime, forHTTPHeaderField: "Content-Type")
            let (d2, r2) = try await transferSession.upload(for: put, fromFile: file, delegate: UploadProgressDelegate(progress))
            let c2 = (r2 as? HTTPURLResponse)?.statusCode ?? 0
            guard c2 == 200 || c2 == 201 else { throw friendly(d2, c2) }
            return
        }
        throw AppError("Phiên đăng nhập bị từ chối, hãy đăng nhập lại.")
    }
}
