import SwiftUI

struct AccountTab: View {
    @EnvironmentObject var auth: GoogleAuth
    @EnvironmentObject var uploader: GooglePhotosUploader
    @State private var showPicker = false
    @State private var clientDraft = ""
    @State private var showSetup = false

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 16) {
                    if auth.isSignedIn { signedIn } else { signedOut }
                }
                .padding()
            }
            .background(AppBackground())
            .navigationTitle("Tài khoản")
            .sheet(isPresented: $showPicker) { PhotoUploadPicker() }
            .alert("Thông báo", isPresented: Binding(get: { auth.errorMessage != nil }, set: { if !$0 { auth.errorMessage = nil } })) {
                Button("OK") { auth.errorMessage = nil }
            } message: { Text(auth.errorMessage ?? "") }
            .onAppear { clientDraft = auth.clientID; showSetup = !auth.isConfigured }
        }
    }

    // MARK: Chưa đăng nhập

    private var signedOut: some View {
        VStack(spacing: 16) {
            VStack(spacing: 12) {
                Image(systemName: "person.crop.circle.badge.checkmark")
                    .font(.system(size: 54)).foregroundStyle(.blue)
                Text("Đăng nhập Google").font(.title2.bold())
                Text("Đăng nhập để tải ảnh và video từ Jinn Files lên Google Photos (dùng dung lượng Google One của bạn).")
                    .font(.subheadline).foregroundStyle(.secondary).multilineTextAlignment(.center)
                Button {
                    Task { await auth.signIn() }
                } label: {
                    HStack {
                        if auth.busy { ProgressView() }
                        Image(systemName: "g.circle.fill")
                        Text("Đăng nhập bằng Google")
                    }.frame(maxWidth: .infinity)
                }
                .glassButtonStyle(prominent: true).controlSize(.large)
                .disabled(!auth.isConfigured || auth.busy)
                if !auth.isConfigured {
                    Text("Cần nhập Client ID ở bên dưới trước.").font(.footnote).foregroundStyle(.orange)
                }
            }
            .padding(20).frame(maxWidth: .infinity).glassSurface(cornerRadius: 28)

            DisclosureGroup(isExpanded: $showSetup) {
                VStack(alignment: .leading, spacing: 10) {
                    Text("""
                    1. Vào console.cloud.google.com, tạo dự án mới.
                    2. APIs & Services → Library → bật "Photos Library API".
                    3. OAuth consent screen: chọn External, thêm Gmail của bạn vào Test users.
                    4. Credentials → Create credentials → OAuth client ID → loại iOS, Bundle ID: com.jinn.JinnFiles.
                    5. Sao chép Client ID (dạng …apps.googleusercontent.com) dán vào ô dưới.
                    """)
                    .font(.footnote).foregroundStyle(.secondary)
                    TextField("Client ID", text: $clientDraft, axis: .vertical)
                        .textInputAutocapitalization(.never).autocorrectionDisabled()
                        .padding(12).background(.quaternary, in: RoundedRectangle(cornerRadius: 12))
                    Button("Lưu Client ID") { auth.setClientID(clientDraft) }
                        .glassButtonStyle().disabled(clientDraft.isEmpty)
                }
                .padding(.top, 8)
            } label: {
                Label("Thiết lập Google (Client ID)", systemImage: "key")
            }
            .padding(16).glassSurface(cornerRadius: 24)
        }
    }

    // MARK: Đã đăng nhập

    private var signedIn: some View {
        VStack(spacing: 16) {
            HStack(spacing: 14) {
                AsyncImage(url: URL(string: auth.user?.picture ?? "")) { img in
                    img.resizable().scaledToFill()
                } placeholder: {
                    Image(systemName: "person.crop.circle.fill").resizable().foregroundStyle(.secondary)
                }
                .frame(width: 60, height: 60).clipShape(Circle())
                VStack(alignment: .leading, spacing: 2) {
                    Text(auth.user?.name ?? "").font(.headline)
                    Text(auth.user?.email ?? "").font(.subheadline).foregroundStyle(.secondary)
                }
                Spacer()
            }
            .padding(16).glassSurface(cornerRadius: 26)

            VStack(alignment: .leading, spacing: 12) {
                Label("Google Photos", systemImage: "photo.stack").font(.headline)
                Text("Chọn ảnh và video trong Jinn Files để tải lên. Hãy giữ ứng dụng mở khi đang tải.")
                    .font(.footnote).foregroundStyle(.secondary)
                Button { showPicker = true } label: {
                    Label("Chọn ảnh/video để tải lên", systemImage: "icloud.and.arrow.up").frame(maxWidth: .infinity)
                }
                .glassButtonStyle(prominent: true).controlSize(.large)
            }
            .padding(16).frame(maxWidth: .infinity, alignment: .leading).glassSurface(cornerRadius: 26)

            if !uploader.jobs.isEmpty { queue }

            Button(role: .destructive) { auth.signOut() } label: {
                Label("Đăng xuất", systemImage: "rectangle.portrait.and.arrow.right").frame(maxWidth: .infinity)
            }
            .glassButtonStyle().controlSize(.large)
        }
    }

    private var queue: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Text("Hàng đợi tải lên").font(.headline)
                Spacer()
                if uploader.running { ProgressView() }
            }
            ForEach(uploader.jobs.reversed().prefix(40)) { job in
                HStack(spacing: 10) {
                    statusIcon(job.state)
                    VStack(alignment: .leading, spacing: 2) {
                        Text(job.name).font(.subheadline).lineLimit(1)
                        switch job.state {
                        case .waiting: Text("Đang chờ").font(.caption).foregroundStyle(.secondary)
                        case .uploading(let p):
                            ProgressView(value: p)
                        case .done: Text("Đã tải lên").font(.caption).foregroundStyle(.green)
                        case .failed(let m): Text(m).font(.caption).foregroundStyle(.red)
                        }
                    }
                }
            }
            HStack {
                Button("Thử lại mục lỗi") { uploader.retryFailed() }.glassButtonStyle()
                Button("Xóa mục đã xong") { uploader.clearFinished() }.glassButtonStyle()
            }.font(.footnote)
        }
        .padding(16).frame(maxWidth: .infinity, alignment: .leading).glassSurface(cornerRadius: 26)
    }

    @ViewBuilder private func statusIcon(_ s: UploadJob.State) -> some View {
        switch s {
        case .waiting: Image(systemName: "clock").foregroundStyle(.secondary)
        case .uploading: Image(systemName: "arrow.up.circle").foregroundStyle(.blue)
        case .done: Image(systemName: "checkmark.circle.fill").foregroundStyle(.green)
        case .failed: Image(systemName: "exclamationmark.triangle.fill").foregroundStyle(.red)
        }
    }
}

/// Chọn ảnh/video trong Jinn Files để tải lên Google Photos
struct PhotoUploadPicker: View {
    @EnvironmentObject var uploader: GooglePhotosUploader
    @Environment(\.dismiss) private var dismiss
    @State private var items: [FileItem] = []
    @State private var selection = Set<URL>()
    @State private var showAll = false
    @State private var loading = true

    private var visible: [FileItem] { showAll ? items : items.filter { !uploader.isUploaded($0) } }
    private var allSelected: Bool { !visible.isEmpty && visible.allSatisfy { selection.contains($0.url) } }

    var body: some View {
        NavigationStack {
            Group {
                if loading { ProgressView() }
                else if visible.isEmpty {
                    ContentUnavailableView("Không có ảnh/video", systemImage: "photo",
                                           description: Text(showAll ? "Hãy nhập ảnh hoặc video vào Tệp của tôi." : "Tất cả đã được tải lên. Chọn \"Hiện cả mục đã tải lên\" để xem lại."))
                } else {
                    ScrollView {
                        LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 3), count: 3), spacing: 3) {
                            ForEach(visible) { item in cell(item) }
                        }
                        .padding(.horizontal, 3)
                    }
                }
            }
            .navigationTitle(selection.isEmpty ? "Chọn ảnh/video" : "Đã chọn \(selection.count)")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) { Button("Đóng") { dismiss() } }
                ToolbarItem(placement: .topBarTrailing) {
                    Menu {
                        Button(allSelected ? "Bỏ chọn tất cả" : "Chọn tất cả") {
                            let urls = Set(visible.map(\.url))
                            if allSelected { selection.subtract(urls) } else { selection.formUnion(urls) }
                        }
                        Toggle("Hiện cả mục đã tải lên", isOn: $showAll)
                    } label: { Image(systemName: "ellipsis.circle") }
                }
            }
            .safeAreaInset(edge: .bottom) {
                Button {
                    uploader.enqueue(items.filter { selection.contains($0.url) }.map(\.url))
                    dismiss()
                } label: {
                    Label("Tải lên \(selection.count) mục", systemImage: "icloud.and.arrow.up").frame(maxWidth: .infinity)
                }
                .glassButtonStyle(prominent: true).controlSize(.large)
                .disabled(selection.isEmpty).padding()
            }
            .task {
                items = await Task.detached { FileOps.allMedia(in: Paths.files) }.value
                loading = false
            }
        }
    }

    private func cell(_ item: FileItem) -> some View {
        Button {
            if selection.contains(item.url) { selection.remove(item.url) } else { selection.insert(item.url) }
        } label: {
            Color.clear.aspectRatio(1, contentMode: .fit)
                .overlay { ThumbView(item: item) }
                .clipped()
                .overlay(alignment: .topTrailing) {
                    Image(systemName: selection.contains(item.url) ? "checkmark.circle.fill" : "circle")
                        .foregroundStyle(selection.contains(item.url) ? Color.accentColor : .white)
                        .shadow(radius: 2).padding(6)
                }
                .overlay(alignment: .bottomLeading) {
                    HStack(spacing: 3) {
                        if item.kind == .video { Image(systemName: "video.fill") }
                        if uploader.isUploaded(item) { Image(systemName: "icloud.fill") }
                    }
                    .font(.caption2).foregroundStyle(.white).shadow(radius: 2).padding(5)
                }
        }
        .buttonStyle(.plain)
    }
}
