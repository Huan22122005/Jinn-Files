import SwiftUI

struct AccountTab: View {
    @EnvironmentObject var auth: GoogleAuth
    @EnvironmentObject var uploader: GooglePhotosUploader
    @State private var showPicker = false
    @State private var clientDraft = ""
    @State private var showSetup = false

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 16) {
                    if auth.isSignedIn { signedIn } else { signedOut }
                }
                .padding()
            }
            .background(AppBackground())
            .navigationTitle("Tài khoản")
            .sheet(isPresented: $showPicker) { PhotoUploadPicker() }
            .alert("Thông báo", isPresented: Binding(get: { auth.errorMessage != nil }, set: { if !$0 { auth.errorMessage = nil } })) {
                Button("OK") { auth.errorMessage = nil }
            } message: { Text(auth.errorMessage ?? "") }
            .onAppear { clientDraft = auth.clientID; showSetup = !auth.isConfigured }
        }
    }

    // MARK: Chưa đăng nhập

    private var signedOut: some View {
        VStack(spacing: 16) {
            VStack(spacing: 12) {
                Image(systemName: "person.crop.circle.badge.checkmark")
                    .font(.system(size: 54)).foregroundStyle(.blue)
                Text("Đăng nhập Google").font(.title2.bold())
                Text("Đăng nhập để tải ảnh và video từ Jinn Files lên Google Photos (dùng dung lượng Google One của bạn).")
                    .font(.subheadline).foregroundStyle(.secondary).multilineTextAlignment(.center)
                Button {
                    Task { await auth.signIn() }
                } label: {
                    HStack {
                        if auth.busy { ProgressView() }
                        Image(systemName: "g.circle.fill")
                        Text("Đăng nhập bằng Google")
                    }.frame(maxWidth: .infinity)
                }
                .glassButtonStyle(prominent: true).controlSize(.large)
                .disabled(!auth.isConfigured || auth.busy)
                if !auth.isConfigured {
                    Text("Cần nhập Client ID ở bên dưới trước.").font(.footnote).foregroundStyle(.orange)
                }
            }
            .padding(20).frame(maxWidth: .infinity).glassSurface(cornerRadius: 28)

            DisclosureGroup(isExpanded: $showSetup) {
                VStack(alignment: .leading, spacing: 10) {
                    Text("""
                    1. Vào console.cloud.google.com, tạo dự án mới.
                    2. APIs & Services → Library → bật "Photos Library API".
                    3. OAuth consent screen: chọn External, thêm Gmail của bạn vào Test users.
                    4. Credentials → Create credentials → OAuth client ID → loại iOS, Bundle ID: com.jinn.JinnFiles.
                    5. Sao chép Client ID (dạng …apps.googleusercontent.com) dán vào ô dưới.
                    """)
                    .font(.footnote).foregroundStyle(.secondary)
                    TextField("Client ID", text: $clientDraft, axis: .vertical)
                        .textInputAutocapitalization(.never).autocorrectionDisabled()
                        .padding(12).background(.quaternary, in: RoundedRectangle(cornerRadius: 12))
                    Button("Lưu Client ID") { auth.setClientID(clientDraft) }
                        .glassButtonStyle().disabled(clientDraft.isEmpty)
                }
                .padding(.top, 8)
            } label: {
                Label("Thiết lập Google (Client ID)", systemImage: "key")
            }
            .padding(16).glassSurface(cornerRadius: 24)
        }
    }

    // MARK: Đã đăng nhập

    private var signedIn: some View {
        VStack(spacing: 16) {
            HStack(spacing: 14) {
                AsyncImage(url: URL(string: auth.user?.picture ?? "")) { img in
                    img.resizable().scaledToFill()
                } placeholder: {
                    Image(systemName: "person.crop.circle.fill").resizable().foregroundStyle(.secondary)
                }
                .frame(width: 60, height: 60).clipShape(Circle())
                VStack(alignment: .leading, spacing: 2) {
                    Text(auth.user?.name ?? "").font(.headline)
                    Text(auth.user?.email ?? "").font(.subheadline).foregroundStyle(.secondary)
                }
                Spacer()
            }
            .padding(16).glassSurface(cornerRadius: 26)

            VStack(alignment: .leading, spacing: 12) {
                Label("Google Photos", systemImage: "photo.stack").font(.headline)
                Text("Chọn ảnh và video theo từng thư mục để tải lên. Ảnh đã tải xem trong Tệp của tôi → Google Photos. Hãy giữ ứng dụng mở khi đang tải.")
                    .font(.footnote).foregroundStyle(.secondary)
                Button { showPicker = true } label: {
                    Label("Chọn ảnh/video để tải lên", systemImage: "icloud.and.arrow.up").frame(maxWidth: .infinity)
                }
                .glassButtonStyle(prominent: true).controlSize(.large)
            }
            .padding(16).frame(maxWidth: .infinity, alignment: .leading).glassSurface(cornerRadius: 26)

            if !uploader.jobs.isEmpty { queue }

            Button(role: .destructive) { auth.signOut() } label: {
                Label("Đăng xuất", systemImage: "rectangle.portrait.and.arrow.right").frame(maxWidth: .infinity)
            }
            .glassButtonStyle().controlSize(.large)
        }
    }

    private var queue: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Text("Hàng đợi tải lên").font(.headline)
                Spacer()
                if uploader.running { ProgressView() }
            }
            ForEach(uploader.jobs.reversed().prefix(40)) { job in
                HStack(spacing: 10) {
                    statusIcon(job.state)
                    VStack(alignment: .leading, spacing: 2) {
                        Text(job.name).font(.subheadline).lineLimit(1)
                        switch job.state {
                        case .waiting: Text("Đang chờ").font(.caption).foregroundStyle(.secondary)
                        case .uploading(let p):
                            ProgressView(value: p)
                        case .done: Text("Đã tải lên").font(.caption).foregroundStyle(.green)
                        case .failed(let m): Text(m).font(.caption).foregroundStyle(.red)
                        }
                    }
                }
            }
            HStack {
                Button("Thử lại mục lỗi") { uploader.retryFailed() }.glassButtonStyle()
                Button("Xóa mục đã xong") { uploader.clearFinished() }.glassButtonStyle()
            }.font(.footnote)
        }
        .padding(16).frame(maxWidth: .infinity, alignment: .leading).glassSurface(cornerRadius: 26)
    }

    @ViewBuilder private func statusIcon(_ s: UploadJob.State) -> some View {
        switch s {
        case .waiting: Image(systemName: "clock").foregroundStyle(.secondary)
        case .uploading: Image(systemName: "arrow.up.circle").foregroundStyle(.blue)
        case .done: Image(systemName: "checkmark.circle.fill").foregroundStyle(.green)
        case .failed: Image(systemName: "exclamationmark.triangle.fill").foregroundStyle(.red)
        }
    }
}

/// Lựa chọn nhiều ảnh/video, giữ nguyên khi chuyển giữa các thư mục
final class UploadSelection: ObservableObject {
    @Published var urls = Set<URL>()
    @Published var showAll = false
}

/// Chọn ảnh/video để tải lên Google Photos: duyệt từng thư mục như trong Tệp của tôi
struct PhotoUploadPicker: View {
    @EnvironmentObject var uploader: GooglePhotosUploader
    @EnvironmentObject var auth: GoogleAuth
    @Environment(\.dismiss) private var dismiss
    @StateObject private var sel = UploadSelection()
    @StateObject private var lib = GooglePhotosLibrary()
    @State private var albumId: String?
    @State private var showNewAlbum = false
    @State private var newAlbumName = ""
    @State private var albumMessage: String?

    private var destinationTitle: String {
        lib.albums.first(where: { $0.id == albumId })?.title ?? "Thư viện chính"
    }

    var body: some View {
        NavigationStack {
            UploadFolderLevel(url: Paths.files, isRoot: true, onClose: { dismiss() })
        }
        .environmentObject(sel)
        .task { if auth.canReadLibrary { await lib.loadAlbums() } }
        .safeAreaInset(edge: .bottom) {
            VStack(spacing: 8) {
                Menu {
                    Button { albumId = nil } label: { Label("Thư viện chính", systemImage: albumId == nil ? "checkmark" : "photo") }
                    ForEach(lib.albums) { a in
                        Button { albumId = a.id } label: { Label(a.title, systemImage: albumId == a.id ? "checkmark" : "rectangle.stack") }
                    }
                    Divider()
                    Button { newAlbumName = ""; showNewAlbum = true } label: { Label("Tạo album mới…", systemImage: "plus") }
                } label: {
                    Label("Tải vào: \(destinationTitle)", systemImage: "rectangle.stack")
                        .font(.subheadline).padding(.horizontal, 14).padding(.vertical, 8)
                        .glassSurface(cornerRadius: 18, interactive: true)
                }
                Button {
                    uploader.enqueue(Array(sel.urls), albumId: albumId)
                    dismiss()
                } label: {
                    Label("Tải lên \(sel.urls.count) mục", systemImage: "icloud.and.arrow.up").frame(maxWidth: .infinity)
                }
                .glassButtonStyle(prominent: true).controlSize(.large)
                .disabled(sel.urls.isEmpty)
            }
            .padding()
        }
        .alert("Album mới", isPresented: $showNewAlbum) {
            TextField("Tên album", text: $newAlbumName)
            Button("Hủy", role: .cancel) {}
            Button("Tạo") {
                let name = newAlbumName
                Task {
                    do { albumId = try await lib.createAlbum(name).id }
                    catch { albumMessage = error.localizedDescription }
                }
            }
        }
        .alert("Thông báo", isPresented: Binding(get: { albumMessage != nil }, set: { if !$0 { albumMessage = nil } })) {
            Button("OK") { albumMessage = nil }
        } message: { Text(albumMessage ?? "") }
    }
}

struct UploadFolderLevel: View {
    let url: URL
    let isRoot: Bool
    let onClose: () -> Void
    @EnvironmentObject var uploader: GooglePhotosUploader
    @EnvironmentObject var sel: UploadSelection
    @AppStorage("uploadViewMode") private var mode = "grid"
    @State private var folders: [FileItem] = []
    @State private var media: [FileItem] = []
    @State private var loading = true

    private var visible: [FileItem] { sel.showAll ? media : media.filter { !uploader.isUploaded($0) } }
    private var allSelected: Bool { !visible.isEmpty && visible.allSatisfy { sel.urls.contains($0.url) } }

    var body: some View {
        ScrollView {
            LazyVStack(alignment: .leading, spacing: 0) {
                ForEach(folders) { f in
                    NavigationLink {
                        UploadFolderLevel(url: f.url, isRoot: false, onClose: onClose)
                    } label: {
                        HStack(spacing: 12) {
                            Image(systemName: "folder.fill").foregroundStyle(.blue).font(.title3)
                            Text(f.name).foregroundStyle(.primary)
                            Spacer()
                            Image(systemName: "chevron.right").font(.footnote).foregroundStyle(.tertiary)
                        }
                        .padding(.horizontal, 16).padding(.vertical, 12)
                        .contentShape(Rectangle())
                    }
                    .buttonStyle(.plain)
                    Divider().padding(.leading, 16)
                }
                if mode == "list" {
                    LazyVStack(spacing: 0) {
                        ForEach(visible) { item in
                            listRow(item)
                            Divider().padding(.leading, 76)
                        }
                    }
                    .padding(.top, 4)
                } else {
                    LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 3), count: 3), spacing: 3) {
                        ForEach(visible) { item in cell(item) }
                    }
                    .padding(.horizontal, 3).padding(.top, 6)
                }

                if !loading && folders.isEmpty && visible.isEmpty {
                    ContentUnavailableView("Không có ảnh/video ở đây", systemImage: "photo",
                                           description: Text(media.isEmpty ? "Thư mục này chưa có ảnh hay video." : "Tất cả đã được tải lên. Bật \"Hiện cả mục đã tải lên\" để xem lại."))
                        .padding(.top, 40)
                }
            }
        }
        .navigationTitle(isRoot ? "Chọn ảnh/video" : url.lastPathComponent)
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            if isRoot {
                ToolbarItem(placement: .topBarLeading) { Button("Đóng") { onClose() } }
            }
            ToolbarItem(placement: .topBarTrailing) {
                Menu {
                    Button(allSelected ? "Bỏ chọn ảnh/video ở đây" : "Chọn tất cả ở thư mục này") {
                        let urls = Set(visible.map(\.url))
                        if allSelected { sel.urls.subtract(urls) } else { sel.urls.formUnion(urls) }
                    }
                    Button("Chọn cả thư mục con") { selectRecursive() }
                    Button("Bỏ chọn tất cả (mọi thư mục)", role: .destructive) { sel.urls.removeAll() }
                    Toggle("Hiện cả mục đã tải lên", isOn: $sel.showAll)
                    Picker("Kiểu hiển thị", selection: $mode) {
                        Label("Lưới", systemImage: "square.grid.3x3").tag("grid")
                        Label("Danh sách (tên, dung lượng)", systemImage: "list.bullet").tag("list")
                    }
                } label: { Image(systemName: "ellipsis.circle") }
            }
        }
        .task(id: url) {
            let u = url
            let r: ([FileItem], [FileItem]) = await Task.detached {
                let all = FileOps.list(u)
                let f = all.filter { $0.isDirectory && !Paths.isGooglePhotos($0.url) }
                    .sorted { $0.name.localizedStandardCompare($1.name) == .orderedAscending }
                let m = all.filter { $0.kind == .image || $0.kind == .video }.sorted { $0.modified > $1.modified }
                return (f, m)
            }.value
            folders = r.0; media = r.1; loading = false
        }
    }

    private func selectRecursive() {
        let u = url
        Task {
            let all = await Task.detached { FileOps.allMedia(in: u) }.value
            let add = all.filter { sel.showAll || !uploader.isUploaded($0) }
            sel.urls.formUnion(add.map(\.url))
        }
    }

    private func listRow(_ item: FileItem) -> some View {
        let picked = sel.urls.contains(item.url)
        return Button {
            if picked { sel.urls.remove(item.url) } else { sel.urls.insert(item.url) }
        } label: {
            HStack(spacing: 12) {
                Image(systemName: picked ? "checkmark.circle.fill" : "circle")
                    .foregroundStyle(picked ? Color.accentColor : .secondary).font(.title3)
                ThumbView(item: item).frame(width: 48, height: 48)
                    .clipShape(RoundedRectangle(cornerRadius: 8))
                VStack(alignment: .leading, spacing: 2) {
                    Text(item.name).lineLimit(1).foregroundStyle(.primary)
                    Text("\(Fmt.size(item.size ?? 0)) • \(Fmt.date(item.modified))")
                        .font(.caption).foregroundStyle(.secondary)
                }
                Spacer()
                if item.kind == .video { Image(systemName: "video.fill").foregroundStyle(.secondary) }
                if uploader.isUploaded(item) { Image(systemName: "icloud.fill").foregroundStyle(.blue) }
            }
            .padding(.horizontal, 16).padding(.vertical, 8)
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
    }

    private func cell(_ item: FileItem) -> some View {
        Button {
            if sel.urls.contains(item.url) { sel.urls.remove(item.url) } else { sel.urls.insert(item.url) }
        } label: {
            Color.clear.aspectRatio(1, contentMode: .fit)
                .overlay { ThumbView(item: item) }
                .clipped()
                .overlay(alignment: .topTrailing) {
                    Image(systemName: sel.urls.contains(item.url) ? "checkmark.circle.fill" : "circle")
                        .foregroundStyle(sel.urls.contains(item.url) ? Color.accentColor : .white)
                        .shadow(radius: 2).padding(6)
                }
                .overlay(alignment: .bottomLeading) {
                    HStack(spacing: 3) {
                        if item.kind == .video { Image(systemName: "video.fill") }
                        if uploader.isUploaded(item) { Image(systemName: "icloud.fill") }
                    }
                    .font(.caption2).foregroundStyle(.white).shadow(radius: 2).padding(5)
                }
        }
        .buttonStyle(.plain)
    }
}
