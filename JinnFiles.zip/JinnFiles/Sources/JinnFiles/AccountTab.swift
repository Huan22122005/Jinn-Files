import SwiftUI

struct AccountTab: View {
    @EnvironmentObject var auth: GoogleAuth
    @EnvironmentObject var uploader: DriveUploader
    @State private var clientDraft = ""
    @State private var showSetup = false
    @State private var showPick = false
    @State private var showDest = false
    @State private var pendingURLs: [URL] = []

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 16) {
                    if auth.isSignedIn { signedIn } else { signedOut }
                }
                .padding()
            }
            .background(AppBackground())
            .navigationTitle("Tài khoản")
            .sheet(isPresented: $showPick, onDismiss: { if !pendingURLs.isEmpty { showDest = true } }) {
                LocalFilePickerSheet(rootTitle: "Chọn tệp để tải lên", icon: "arrow.right.circle", allowFolders: true,
                                     actionTitle: { "Tiếp tục với \($0) mục" }) { urls in pendingURLs = urls }
            }
            .sheet(isPresented: $showDest) {
                DriveFolderPicker(title: "Tải lên Drive vào…") { dest in
                    uploader.enqueue(pendingURLs, parentId: dest.id)
                    pendingURLs = []
                }
            }
            .alert("Thông báo", isPresented: Binding(get: { auth.errorMessage != nil }, set: { if !$0 { auth.errorMessage = nil } })) {
                Button("OK") { auth.errorMessage = nil }
            } message: { Text(auth.errorMessage ?? "") }
            .onAppear { clientDraft = auth.clientID; showSetup = !auth.isConfigured }
        }
    }

    // MARK: Chưa đăng nhập

    private var signedOut: some View {
        VStack(spacing: 16) {
            VStack(spacing: 12) {
                Image(systemName: "person.crop.circle.badge.checkmark")
                    .font(.system(size: 54)).foregroundStyle(Color.accentColor)
                Text("Đăng nhập Google").font(.title2.bold())
                Text("Đăng nhập để lưu trữ, tạo, di chuyển và xóa tệp, thư mục trên Google Drive ngay trong Jinn Files (dùng dung lượng Google One của bạn).")
                    .font(.subheadline).foregroundStyle(.secondary).multilineTextAlignment(.center)
                Button {
                    Task { await auth.signIn() }
                } label: {
                    HStack {
                        if auth.busy { ProgressView() }
                        Image(systemName: "g.circle.fill")
                        Text("Đăng nhập bằng Google")
                    }.frame(maxWidth: .infinity)
                }
                .glassButtonStyle(prominent: true).controlSize(.large)
                .disabled(!auth.isConfigured || auth.busy)
                if !auth.isConfigured {
                    Text("Cần nhập Client ID ở bên dưới trước.").font(.footnote).foregroundStyle(.orange)
                }
            }
            .padding(20).frame(maxWidth: .infinity).glassSurface(cornerRadius: 28)

            DisclosureGroup(isExpanded: $showSetup) {
                VStack(alignment: .leading, spacing: 10) {
                    Text("""
                    1. Vào console.cloud.google.com, chọn dự án của bạn.
                    2. APIs & Services → Library → bật "Google Drive API".
                    3. Google Auth Platform → Audience: để Testing và thêm Gmail của bạn vào Test users.
                    4. Credentials → OAuth client ID → loại iOS, Bundle ID: com.jinn.JinnFiles.
                    5. Sao chép Client ID (dạng …apps.googleusercontent.com) dán vào ô dưới.
                    """)
                    .font(.footnote).foregroundStyle(.secondary)
                    TextField("Client ID", text: $clientDraft, axis: .vertical)
                        .textInputAutocapitalization(.never).autocorrectionDisabled()
                        .padding(12).background(.quaternary, in: RoundedRectangle(cornerRadius: 12))
                    Button("Lưu Client ID") { auth.setClientID(clientDraft) }
                        .glassButtonStyle().disabled(clientDraft.isEmpty)
                }
                .padding(.top, 8)
            } label: {
                Label("Thiết lập Google (Client ID)", systemImage: "key")
            }
            .padding(16).glassSurface(cornerRadius: 24)
        }
    }

    // MARK: Đã đăng nhập

    private var signedIn: some View {
        VStack(spacing: 16) {
            HStack(spacing: 14) {
                AsyncImage(url: URL(string: auth.user?.picture ?? "")) { img in
                    img.resizable().scaledToFill()
                } placeholder: {
                    Image(systemName: "person.crop.circle.fill").resizable().foregroundStyle(.secondary)
                }
                .frame(width: 60, height: 60).clipShape(Circle())
                VStack(alignment: .leading, spacing: 2) {
                    Text(auth.user?.name ?? "").font(.headline)
                    Text(auth.user?.email ?? "").font(.subheadline).foregroundStyle(.secondary)
                }
                Spacer()
            }
            .padding(16).glassSurface(cornerRadius: 26)

            VStack(alignment: .leading, spacing: 12) {
                Label("Google Drive", systemImage: "externaldrive.badge.icloud").font(.headline)
                if auth.canUseDrive {
                    Text("Duyệt và quản lý tại Tệp của tôi → Google Drive. Bạn cũng có thể tải tệp, thư mục lên từ đây. Hãy giữ ứng dụng mở khi đang tải.")
                        .font(.footnote).foregroundStyle(.secondary)
                    Button { pendingURLs = []; showPick = true } label: {
                        Label("Tải lên Google Drive", systemImage: "icloud.and.arrow.up").frame(maxWidth: .infinity)
                    }
                    .glassButtonStyle(prominent: true).controlSize(.large)
                } else {
                    Text("Cần đăng nhập lại để cấp quyền Google Drive (bản cũ chỉ có quyền Google Photos).")
                        .font(.footnote).foregroundStyle(.orange)
                    Button { Task { await auth.signIn() } } label: {
                        Label("Đăng nhập lại để cấp quyền", systemImage: "arrow.triangle.2.circlepath").frame(maxWidth: .infinity)
                    }
                    .glassButtonStyle(prominent: true).controlSize(.large)
                }
            }
            .padding(16).frame(maxWidth: .infinity, alignment: .leading).glassSurface(cornerRadius: 26)

            if !uploader.jobs.isEmpty { UploadQueueView() }

            Button(role: .destructive) { auth.signOut() } label: {
                Label("Đăng xuất", systemImage: "rectangle.portrait.and.arrow.right").frame(maxWidth: .infinity)
            }
            .glassButtonStyle().controlSize(.large)
        }
    }
}
