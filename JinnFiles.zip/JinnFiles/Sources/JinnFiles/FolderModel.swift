import SwiftUI

@MainActor
final class FolderModel: ObservableObject {
    let url: URL
    @Published var items: [FileItem] = []
    @Published var searchResults: [FileItem] = []
    @Published var selection = Set<URL>()
    @Published var selecting = false
    @Published var busy: Busy?
    @Published var message: String?

    struct Busy { var title: String; var fraction: Double? }

    private var searchGen = 0

    init(url: URL) {
        self.url = url
        Paths.bootstrap()
        reload()
    }

    func reload() {
        let u = url
        Task {
            let r = await Task.detached { FileOps.list(u) }.value
            self.items = r
            self.selection = self.selection.filter { s in r.contains { $0.url == s } }
        }
    }

    func search(_ q: String) {
        searchGen += 1
        let g = searchGen
        guard !q.isEmpty else { searchResults = []; return }
        let u = url
        Task {
            let r = await Task.detached { FileOps.search(in: u, query: q) }.value
            if g == self.searchGen { self.searchResults = r }
        }
    }

    func toggle(_ item: FileItem) {
        if selection.contains(item.url) { selection.remove(item.url) } else { selection.insert(item.url) }
    }

    func endSelecting() { selecting = false; selection.removeAll() }

    // MARK: - Chạy tác vụ nền có tiến trình

    private func perform(_ title: String,
                         work: @escaping @Sendable (@escaping @Sendable (Double) -> Void) throws -> String) {
        busy = Busy(title: title, fraction: nil)
        let cb: @Sendable (Double) -> Void = { [weak self] f in
            Task { @MainActor in self?.busy?.fraction = f }
        }
        Task {
            do {
                let msg = try await Task.detached { try work(cb) }.value
                self.message = msg
            } catch {
                self.message = "Lỗi: \(error.localizedDescription)"
            }
            self.busy = nil
            self.reload()
        }
    }

    // MARK: - Thao tác

    func createFolder(_ name: String) {
        guard let n = FileOps.validName(name) else { message = "Tên không hợp lệ."; return }
        let t = url.appendingPathComponent(n, isDirectory: true)
        if FileManager.default.fileExists(atPath: t.path) { message = "Đã tồn tại mục trùng tên."; return }
        do {
            try FileManager.default.createDirectory(at: t, withIntermediateDirectories: false)
            reload()
        } catch { message = "Lỗi: \(error.localizedDescription)" }
    }

    func rename(_ item: FileItem, to name: String) {
        guard !Paths.isGooglePhotos(item.url) else { return }
        guard let n = FileOps.validName(name) else { message = "Tên không hợp lệ."; return }
        if n == item.name { return }
        let t = item.url.deletingLastPathComponent().appendingPathComponent(n)
        if FileManager.default.fileExists(atPath: t.path) { message = "Đã tồn tại mục trùng tên."; return }
        do { try FileManager.default.moveItem(at: item.url, to: t); reload() }
        catch { message = "Lỗi: \(error.localizedDescription)" }
    }

    func delete(_ urls: [URL]) {
        let urls = urls.filter { !Paths.isGooglePhotos($0) }
        var ok = 0, fail = 0
        for u in urls {
            do { try TrashStore.shared.moveToTrash(u); ok += 1 } catch { fail += 1 }
        }
        message = fail == 0 ? "Đã chuyển \(ok) mục vào Thùng rác." : "Đã xóa \(ok) mục, \(fail) mục thất bại (dữ liệu gốc vẫn được giữ)."
        endSelecting()
        reload()
        searchResults.removeAll { r in urls.contains(r.url) }
    }

    func copy(_ urls: [URL], to dest: URL) {
        perform("Đang sao chép…") { progress in
            let fm = FileManager.default
            var need: Int64 = 0
            for u in urls { need += FileOps.size(of: u) }
            try FileOps.checkSpace(needed: need)
            for (i, u) in urls.enumerated() {
                try fm.copyItem(at: u, to: FileOps.uniqueURL(dir: dest, name: u.lastPathComponent))
                progress(Double(i + 1) / Double(urls.count))
            }
            return "Đã sao chép \(urls.count) mục."
        }
        endSelecting()
    }

    func move(_ urls: [URL], to dest: URL) {
        let urls = urls.filter { !Paths.isGooglePhotos($0) }
        perform("Đang di chuyển…") { progress in
            let fm = FileManager.default
            for u in urls where u.isFileURL {
                if FileOps.isInside(dest, of: u) { throw AppError("Không thể di chuyển thư mục vào chính nó.") }
            }
            for (i, u) in urls.enumerated() {
                if u.deletingLastPathComponent().resolvingSymlinksInPath() == dest.resolvingSymlinksInPath() { continue }
                try fm.moveItem(at: u, to: FileOps.uniqueURL(dir: dest, name: u.lastPathComponent))
                progress(Double(i + 1) / Double(urls.count))
            }
            return "Đã di chuyển \(urls.count) mục."
        }
        endSelecting()
    }

    func importFiles(_ picked: [URL]) {
        let here = url
        perform("Đang nhập tệp…") { progress in
            let fm = FileManager.default
            var need: Int64 = 0
            for u in picked { need += FileOps.size(of: u) }
            try FileOps.checkSpace(needed: need)
            var ok = 0
            for (i, u) in picked.enumerated() {
                let it = FileOps.item(from: u)
                let dir: URL = (here.resolvingSymlinksInPath() == Paths.files.resolvingSymlinksInPath())
                    ? Paths.category(for: it.kind) : here
                try fm.createDirectory(at: dir, withIntermediateDirectories: true)
                let target = FileOps.uniqueURL(dir: dir, name: u.lastPathComponent)
                do { try fm.moveItem(at: u, to: target) }
                catch { try fm.copyItem(at: u, to: target); try? fm.removeItem(at: u) }
                ok += 1
                progress(Double(i + 1) / Double(picked.count))
            }
            return "Đã nhập \(ok) tệp thành công."
        }
    }

    func extract(_ item: FileItem, mode: ExtractMode) {
        let here = url, src = item.url
        perform("Đang giải nén…") { progress in
            try FileOps.checkSpace(needed: FileOps.size(of: src) * 3)
            try ArchiveOps.extract(archive: src, mode: mode, currentDir: here, progress: progress)
            return "Giải nén hoàn tất."
        }
    }

    func zipSelected(_ urls: [URL]) {
        let here = url
        perform("Đang nén ZIP…") { progress in
            var need: Int64 = 0
            for u in urls { need += FileOps.size(of: u) }
            try FileOps.checkSpace(needed: need)
            try ArchiveOps.zip(urls, in: here, progress: progress)
            return "Đã tạo tệp ZIP."
        }
        endSelecting()
    }
}
