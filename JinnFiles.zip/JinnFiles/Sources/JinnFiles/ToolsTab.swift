import SwiftUI
import UIKit

struct ToolsTab: View {
    var onOpenBrowser: () -> Void = {}
    @EnvironmentObject private var trash: TrashStore
    @EnvironmentObject private var downloads: DownloadManager

    private let columns = Array(repeating: GridItem(.flexible(), spacing: 12), count: 4)

    var body: some View {
        NavigationStack {
            ScrollView {
                LazyVGrid(columns: columns, spacing: 12) {
                    NavigationLink { QuickSendView() } label: {
                        ToolCard(title: "Gửi nhanh") {
                            ToolBadge(symbol: "paperplane.fill", colors: [Color(red: 0.35, green: 0.62, blue: 1.0), Color(red: 0.12, green: 0.38, blue: 0.95)])
                        }
                    }
                    NavigationLink { BatchRenameView() } label: {
                        ToolCard(title: "Đổi tên hàng loạt") {
                            ToolBadge(symbol: "character.cursor.ibeam", colors: [Color(red: 1.0, green: 0.72, blue: 0.25), Color(red: 0.95, green: 0.45, blue: 0.1)])
                        }
                    }
                    Button { onOpenBrowser() } label: {
                        ToolCard(title: "Trình duyệt Web") {
                            ToolBadge(symbol: "safari.fill", colors: [Color(red: 0.3, green: 0.8, blue: 0.95), Color(red: 0.05, green: 0.5, blue: 0.9)])
                        }
                    }
                    NavigationLink { ArchiveToolView() } label: {
                        ToolCard(title: "Nén và giải nén") {
                            ToolBadge(symbol: "doc.zipper", colors: [Color(red: 0.75, green: 0.5, blue: 1.0), Color(red: 0.5, green: 0.25, blue: 0.85)])
                        }
                    }
                    NavigationLink { ImagePDFToolView() } label: {
                        ToolCard(title: "Ảnh ⇄ PDF") { PDFImageBadge() }
                    }
                    NavigationLink { DownloadManagerView() } label: {
                        ToolCard(title: "Tải xuống", badge: downloads.records.filter { $0.state == .downloading }.count) {
                            ToolBadge(symbol: "arrow.down.to.line", colors: [Color(red: 0.4, green: 0.88, blue: 0.5), Color(red: 0.12, green: 0.65, blue: 0.35)])
                        }
                    }
                    NavigationLink { TrashScreen() } label: {
                        ToolCard(title: "Thùng rác", badge: trash.entries.count) {
                            ToolBadge(symbol: "trash.fill", colors: [Color(red: 1.0, green: 0.5, blue: 0.5), Color(red: 0.88, green: 0.2, blue: 0.25)])
                        }
                    }
                }
                .buttonStyle(.plain)
                .padding()
            }
            .background(AppBackground())
            .navigationTitle("Công cụ")
        }
    }
}

/// Biểu tượng dạng ô vuông bo góc, có chuyển màu
struct ToolBadge: View {
    let symbol: String
    let colors: [Color]

    var body: some View {
        RoundedRectangle(cornerRadius: 14, style: .continuous)
            .fill(LinearGradient(colors: colors, startPoint: .topLeading, endPoint: .bottomTrailing))
            .frame(width: 46, height: 46)
            .overlay(
                Image(systemName: symbol)
                    .font(.system(size: 21, weight: .semibold))
                    .foregroundStyle(.white)
                    .shadow(color: .black.opacity(0.18), radius: 1, y: 1)
            )
            .shadow(color: (colors.last ?? .blue).opacity(0.35), radius: 4, y: 2)
    }
}

/// Biểu tượng chuyển đổi PDF ⇄ ảnh (hai ô nhỏ và mũi tên)
struct PDFImageBadge: View {
    var body: some View {
        HStack(spacing: 2) {
            RoundedRectangle(cornerRadius: 9, style: .continuous)
                .fill(Color(red: 1.0, green: 0.84, blue: 0.86))
                .frame(width: 29, height: 29)
                .overlay(Text("PDF").font(.system(size: 9.5, weight: .heavy)).foregroundStyle(Color(red: 0.88, green: 0.25, blue: 0.32)))
            Image(systemName: "arrow.left.arrow.right")
                .font(.system(size: 8, weight: .bold)).foregroundStyle(.secondary)
            RoundedRectangle(cornerRadius: 9, style: .continuous)
                .fill(LinearGradient(colors: [Color(red: 0.4, green: 0.7, blue: 1.0), Color(red: 0.15, green: 0.45, blue: 0.95)],
                                     startPoint: .topLeading, endPoint: .bottomTrailing))
                .frame(width: 29, height: 29)
                .overlay(Image(systemName: "photo.fill").font(.system(size: 13)).foregroundStyle(.white))
        }
        .frame(height: 46)
    }
}

/// Ô công cụ hình vuông
struct ToolCard<Icon: View>: View {
    let title: String
    var badge: Int = 0
    @ViewBuilder let icon: () -> Icon

    var body: some View {
        VStack(spacing: 8) {
            ZStack(alignment: .topTrailing) {
                icon()
                if badge > 0 {
                    Text("\(badge)").font(.system(size: 10, weight: .bold)).foregroundStyle(.white)
                        .padding(.horizontal, 5).padding(.vertical, 1)
                        .background(Color.red, in: Capsule()).offset(x: 8, y: -6)
                }
            }
            .frame(height: 48)
            Text(title)
                .font(.system(size: 11, weight: .medium))
                .multilineTextAlignment(.center)
                .lineLimit(2)
                .minimumScaleFactor(0.85)
                .frame(maxWidth: .infinity)
        }
        .padding(.horizontal, 4).padding(.vertical, 8)
        .frame(maxWidth: .infinity)
        .aspectRatio(1, contentMode: .fit)
        .glassSurface(cornerRadius: 22, interactive: true)
    }
}

struct ActivityView: UIViewControllerRepresentable {
    let items: [Any]
    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: items, applicationActivities: nil)
    }
    func updateUIViewController(_ vc: UIActivityViewController, context: Context) {}
}

/// Gửi nhanh: duyệt từng thư mục, chọn tệp ở nhiều nơi rồi dùng bảng chia sẻ có sẵn của iOS
struct QuickSendView: View {
    @StateObject private var sel = PickSelection()

    var body: some View {
        FilePickerLevel(
            url: Paths.files, isRoot: true, sel: sel,
            config: PickConfig(rootTitle: "Gửi nhanh", icon: "square.and.arrow.up", allowFolders: false,
                               actionTitle: { $0 == 0 ? "Chọn tệp để chia sẻ" : "Chia sẻ \($0) tệp" },
                               action: .share))
    }
}
