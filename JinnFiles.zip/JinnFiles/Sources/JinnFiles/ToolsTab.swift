import SwiftUI
import UIKit

struct ToolsTab: View {
    var body: some View {
        NavigationStack {
            ScrollView {
                LazyVGrid(columns: [GridItem(.flexible(), spacing: 14), GridItem(.flexible(), spacing: 14)], spacing: 14) {
                    NavigationLink { QuickSendView() } label: {
                        ToolCard(title: "Gửi nhanh", subtitle: "Chọn tệp và chia sẻ ngay",
                                 symbol: "paperplane.fill", tint: .blue)
                    }
                    .buttonStyle(.plain)
                }
                .padding()
            }
            .background(AppBackground())
            .navigationTitle("Công cụ")
        }
    }
}

struct ToolCard: View {
    let title: String
    let subtitle: String
    let symbol: String
    let tint: Color
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Image(systemName: symbol).font(.system(size: 30)).foregroundStyle(tint)
            Spacer(minLength: 0)
            Text(title).font(.headline)
            Text(subtitle).font(.caption).foregroundStyle(.secondary).multilineTextAlignment(.leading)
        }
        .frame(maxWidth: .infinity, minHeight: 130, alignment: .topLeading)
        .padding(16)
        .glassSurface(cornerRadius: 26, interactive: true)
    }
}

struct ActivityView: UIViewControllerRepresentable {
    let items: [Any]
    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: items, applicationActivities: nil)
    }
    func updateUIViewController(_ vc: UIActivityViewController, context: Context) {}
}

/// Gửi nhanh: liệt kê tệp, chọn nhiều, rồi dùng bảng chia sẻ có sẵn của iOS
struct QuickSendView: View {
    @State private var items: [FileItem] = []
    @State private var selection = Set<URL>()
    @State private var query = ""
    @State private var loading = true
    @State private var showShare = false

    private var filtered: [FileItem] {
        query.isEmpty ? items : items.filter { $0.name.localizedCaseInsensitiveContains(query) }
    }
    private var allSelected: Bool { !filtered.isEmpty && filtered.allSatisfy { selection.contains($0.url) } }

    var body: some View {
        Group {
            if loading { ProgressView() }
            else if filtered.isEmpty {
                ContentUnavailableView(query.isEmpty ? "Chưa có tệp" : "Không tìm thấy", systemImage: "tray",
                                       description: Text(query.isEmpty ? "Nhập tệp vào Tệp của tôi để gửi." : "Thử từ khóa khác."))
            } else {
                List(filtered) { item in
                    Button {
                        if selection.contains(item.url) { selection.remove(item.url) } else { selection.insert(item.url) }
                    } label: {
                        HStack(spacing: 12) {
                            Image(systemName: selection.contains(item.url) ? "checkmark.circle.fill" : "circle")
                                .foregroundStyle(selection.contains(item.url) ? Color.accentColor : .secondary)
                            ThumbView(item: item).frame(width: 44, height: 44)
                                .clipShape(RoundedRectangle(cornerRadius: 10))
                            VStack(alignment: .leading, spacing: 2) {
                                Text(item.name).lineLimit(1)
                                Text("\(Fmt.size(item.size ?? 0)) • \(Fmt.date(item.modified))")
                                    .font(.caption).foregroundStyle(.secondary)
                            }
                            Spacer()
                        }.contentShape(Rectangle())
                    }
                    .buttonStyle(.plain)
                }
                .listStyle(.plain)
            }
        }
        .navigationTitle(selection.isEmpty ? "Gửi nhanh" : "Đã chọn \(selection.count)")
        .navigationBarTitleDisplayMode(.inline)
        .searchable(text: $query, prompt: "Tìm tệp")
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Button(allSelected ? "Bỏ chọn" : "Chọn tất cả") {
                    let urls = Set(filtered.map(\.url))
                    if allSelected { selection.subtract(urls) } else { selection.formUnion(urls) }
                }
                .disabled(filtered.isEmpty)
            }
        }
        .safeAreaInset(edge: .bottom) {
            if !selection.isEmpty {
                Button { showShare = true } label: {
                    Label("Chia sẻ \(selection.count) tệp", systemImage: "square.and.arrow.up").frame(maxWidth: .infinity)
                }
                .glassButtonStyle(prominent: true).controlSize(.large).padding()
            }
        }
        .sheet(isPresented: $showShare) { ActivityView(items: Array(selection)) }
        .task {
            items = await Task.detached { FileOps.allFiles(in: Paths.files) }.value
            loading = false
        }
    }
}
