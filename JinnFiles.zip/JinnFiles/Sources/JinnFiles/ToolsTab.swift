import SwiftUI
import UIKit

struct ToolsTab: View {
    var body: some View {
        NavigationStack {
            ScrollView {
                LazyVGrid(columns: [GridItem(.flexible(), spacing: 14), GridItem(.flexible(), spacing: 14)], spacing: 14) {
                    NavigationLink { QuickSendView() } label: {
                        ToolCard(title: "Gửi nhanh", subtitle: "Chọn tệp và chia sẻ ngay",
                                 symbol: "paperplane.fill", tint: Color.accentColor)
                    }
                    .buttonStyle(.plain)
                }
                .padding()
            }
            .background(AppBackground())
            .navigationTitle("Công cụ")
        }
    }
}

struct ToolCard: View {
    let title: String
    let subtitle: String
    let symbol: String
    let tint: Color
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Image(systemName: symbol).font(.system(size: 30)).foregroundStyle(tint)
            Spacer(minLength: 0)
            Text(title).font(.headline)
            Text(subtitle).font(.caption).foregroundStyle(.secondary).multilineTextAlignment(.leading)
        }
        .frame(maxWidth: .infinity, minHeight: 130, alignment: .topLeading)
        .padding(16)
        .glassSurface(cornerRadius: 26, interactive: true)
    }
}

struct ActivityView: UIViewControllerRepresentable {
    let items: [Any]
    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: items, applicationActivities: nil)
    }
    func updateUIViewController(_ vc: UIActivityViewController, context: Context) {}
}

/// Gửi nhanh: duyệt từng thư mục, chọn tệp ở nhiều nơi rồi dùng bảng chia sẻ có sẵn của iOS
struct QuickSendView: View {
    @StateObject private var sel = PickSelection()

    var body: some View {
        FilePickerLevel(
            url: Paths.files, isRoot: true,
            config: PickConfig(rootTitle: "Gửi nhanh", icon: "square.and.arrow.up", allowFolders: false,
                               actionTitle: { $0 == 0 ? "Chọn tệp để chia sẻ" : "Chia sẻ \($0) tệp" },
                               action: .share))
            .environmentObject(sel)
    }
}
