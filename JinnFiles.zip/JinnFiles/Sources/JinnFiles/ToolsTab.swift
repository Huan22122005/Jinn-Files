import SwiftUI
import UIKit

struct ToolsTab: View {
    var onOpenBrowser: () -> Void = {}
    @EnvironmentObject private var trash: TrashStore
    @EnvironmentObject private var downloads: DownloadManager

    private let columns = [GridItem(.adaptive(minimum: 88, maximum: 120), spacing: 12)]

    var body: some View {
        NavigationStack {
            ScrollView {
                LazyVGrid(columns: columns, spacing: 12) {
                    NavigationLink { QuickSendView() } label: {
                        ToolCard(title: "Gửi nhanh", symbol: "paperplane.fill", tint: Color.accentColor)
                    }
                    NavigationLink { BatchRenameView() } label: {
                        ToolCard(title: "Đổi tên hàng loạt", symbol: "textformat.123", tint: .orange)
                    }
                    Button { onOpenBrowser() } label: {
                        ToolCard(title: "Trình duyệt Web", symbol: "safari", tint: .blue)
                    }
                    NavigationLink { ArchiveToolView() } label: {
                        ToolCard(title: "Nén và giải nén", symbol: "doc.zipper", tint: .purple)
                    }
                    NavigationLink { DownloadManagerView() } label: {
                        ToolCard(title: "Tải xuống", symbol: "arrow.down.circle.fill", tint: .green,
                                 badge: downloads.records.filter { $0.state == .downloading }.count)
                    }
                    NavigationLink { TrashScreen() } label: {
                        ToolCard(title: "Thùng rác", symbol: "trash.fill", tint: .red, badge: trash.entries.count)
                    }
                }
                .buttonStyle(.plain)
                .padding()
            }
            .background(AppBackground())
            .navigationTitle("Công cụ")
        }
    }
}

struct ToolCard: View {
    let title: String
    let symbol: String
    let tint: Color
    var badge: Int = 0

    var body: some View {
        VStack(spacing: 8) {
            ZStack(alignment: .topTrailing) {
                Image(systemName: symbol).font(.system(size: 26)).foregroundStyle(tint).frame(height: 30)
                if badge > 0 {
                    Text("\(badge)").font(.system(size: 10, weight: .bold)).foregroundStyle(.white)
                        .padding(.horizontal, 5).padding(.vertical, 1)
                        .background(Color.red, in: Capsule()).offset(x: 14, y: -6)
                }
            }
            Text(title).font(.caption.weight(.medium)).multilineTextAlignment(.center).lineLimit(2)
                .frame(maxWidth: .infinity, minHeight: 30, alignment: .top)
        }
        .frame(maxWidth: .infinity, minHeight: 92)
        .padding(.vertical, 12).padding(.horizontal, 6)
        .glassSurface(cornerRadius: 22, interactive: true)
    }
}

struct ActivityView: UIViewControllerRepresentable {
    let items: [Any]
    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: items, applicationActivities: nil)
    }
    func updateUIViewController(_ vc: UIActivityViewController, context: Context) {}
}

/// Gửi nhanh: duyệt từng thư mục, chọn tệp ở nhiều nơi rồi dùng bảng chia sẻ có sẵn của iOS
struct QuickSendView: View {
    @StateObject private var sel = PickSelection()

    var body: some View {
        FilePickerLevel(
            url: Paths.files, isRoot: true, sel: sel,
            config: PickConfig(rootTitle: "Gửi nhanh", icon: "square.and.arrow.up", allowFolders: false,
                               actionTitle: { $0 == 0 ? "Chọn tệp để chia sẻ" : "Chia sẻ \($0) tệp" },
                               action: .share))
    }
}
