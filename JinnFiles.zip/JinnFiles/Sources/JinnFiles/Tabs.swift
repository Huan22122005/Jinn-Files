import SwiftUI

struct GalleryTab: View {
    @State private var images: [FileItem] = []
    @State private var pager: PagerItem?
    @State private var loading = true

    var body: some View {
        NavigationStack {
            ScrollView {
                if images.isEmpty && !loading {
                    ContentUnavailableView("Chưa có ảnh", systemImage: "photo",
                                           description: Text("Nhập ảnh vào mục Tệp của tôi."))
                        .padding(.top, 80)
                }
                let urls = images.map(\.url)
                LazyVGrid(columns: [GridItem(.flexible(), spacing: 8), GridItem(.flexible(), spacing: 8)], spacing: 8) {
                    ForEach(Array(images.enumerated()), id: \.element.id) { i, it in
                        GalleryCell(item: it).onTapGesture { pager = PagerItem(urls: urls, index: i) }
                    }
                }.padding(8)
            }
            .navigationTitle("Thư viện ảnh")
            .refreshable { await load() }
            .task { await load() }
            .fullScreenCover(item: $pager) { p in ImagePager(urls: p.urls, start: p.index, onClose: { pager = nil }) }
        }
    }

    private func load() async {
        images = await Task.detached { FileOps.all(of: .image, in: Paths.files) }.value
        loading = false
    }
}

struct TrashView: View {
    @EnvironmentObject var trash: TrashStore
    @State private var selecting = false
    @State private var selection = Set<UUID>()
    @State private var confirmDelete = false
    @State private var confirmEmpty = false
    @State private var pendingDeleteIDs = Set<UUID>()
    @State private var needLocation: [TrashEntry] = []
    @State private var showPicker = false
    @State private var message: String?

    var body: some View {
        NavigationStack {
            Group {
                if trash.entries.isEmpty {
                    ContentUnavailableView("Thùng rác trống", systemImage: "trash",
                                           description: Text("Mục đã xóa được giữ 30 ngày."))
                } else {
                    List(trash.entries.sorted { $0.deletedAt > $1.deletedAt }) { e in
                        Button { if selecting { toggle(e.id) } } label: { row(e) }
                            .buttonStyle(.plain)
                            .swipeActions(edge: .leading) {
                                Button { restore([e]) } label: { Label("Khôi phục", systemImage: "arrow.uturn.backward") }.tint(.green)
                            }
                            .swipeActions(edge: .trailing) {
                                Button(role: .destructive) { pendingDeleteIDs = [e.id]; confirmDelete = true } label: { Label("Xóa", systemImage: "trash") }
                            }
                            .contextMenu {
                                Button { restore([e]) } label: { Label("Khôi phục", systemImage: "arrow.uturn.backward") }
                                Button(role: .destructive) { pendingDeleteIDs = [e.id]; confirmDelete = true } label: { Label("Xóa vĩnh viễn", systemImage: "trash") }
                            }
                    }.listStyle(.plain)
                }
            }
            .navigationTitle("Thùng rác")
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    if !trash.entries.isEmpty {
                        Menu {
                            Button(selecting ? "Xong" : "Chọn nhiều") { selecting.toggle(); selection.removeAll() }
                            Button("Xóa toàn bộ Thùng rác", role: .destructive) { confirmEmpty = true }
                        } label: { Image(systemName: "ellipsis.circle") }
                    }
                }
                ToolbarItemGroup(placement: .bottomBar) {
                    if selecting {
                        Button("Khôi phục") { restore(trash.entries.filter { selection.contains($0.id) }) }
                            .disabled(selection.isEmpty)
                        Spacer()
                        Button("Xóa vĩnh viễn", role: .destructive) { pendingDeleteIDs = selection; confirmDelete = true }
                            .disabled(selection.isEmpty)
                    }
                }
            }
            .onAppear { trash.purgeExpired() }
            .confirmationDialog("Xóa vĩnh viễn \(pendingDeleteIDs.count) mục? Không thể khôi phục.", isPresented: $confirmDelete, titleVisibility: .visible) {
                Button("Xóa vĩnh viễn", role: .destructive) {
                    let f = trash.deleteForever(pendingDeleteIDs)
                    if f > 0 { message = "\(f) mục không xóa được." }
                    selection.removeAll()
                }
                Button("Hủy", role: .cancel) {}
            }
            .confirmationDialog("Xóa toàn bộ Thùng rác? Không thể khôi phục.", isPresented: $confirmEmpty, titleVisibility: .visible) {
                Button("Xóa toàn bộ", role: .destructive) { _ = trash.emptyAll(); selection.removeAll() }
                Button("Hủy", role: .cancel) {}
            }
            .sheet(isPresented: $showPicker) {
                FolderPicker(title: "Khôi phục vào…", exclude: []) { d in
                    for e in needLocation { try? trash.restore(e, into: d) }
                    needLocation = []; selection.removeAll()
                }
            }
            .alert("Thông báo", isPresented: Binding(get: { message != nil }, set: { if !$0 { message = nil } })) {
                Button("OK") { message = nil }
            } message: { Text(message ?? "") }
        }
    }

    private func toggle(_ id: UUID) {
        if selection.contains(id) { selection.remove(id) } else { selection.insert(id) }
    }

    private func restore(_ list: [TrashEntry]) {
        var missing: [TrashEntry] = []
        var failed = 0
        for e in list {
            if let p = trash.originalParent(of: e) {
                do { try trash.restore(e, into: p) } catch { failed += 1 }
            } else { missing.append(e) }
        }
        if failed > 0 { message = "\(failed) mục khôi phục thất bại." }
        if missing.isEmpty { selection.removeAll() } else { needLocation = missing; showPicker = true }
    }

    private func row(_ e: TrashEntry) -> some View {
        HStack(spacing: 12) {
            if selecting {
                Image(systemName: selection.contains(e.id) ? "checkmark.circle.fill" : "circle")
                    .foregroundStyle(selection.contains(e.id) ? Color.accentColor : .secondary)
            }
            Image(systemName: e.kind.symbol).foregroundStyle(e.kind.tint).frame(width: 32)
            VStack(alignment: .leading, spacing: 2) {
                Text(e.name).lineLimit(1)
                Text("\(e.kind.label) • \(Fmt.size(e.size))").font(.caption).foregroundStyle(.secondary)
                Text("Xóa: \(Fmt.date(e.deletedAt)) • Còn \(e.daysLeft) ngày").font(.caption2).foregroundStyle(.secondary)
            }
            Spacer()
        }.contentShape(Rectangle())
    }
}

struct SettingsView: View {
    @EnvironmentObject var trash: TrashStore
    @AppStorage("viewMode") private var viewMode = "list"
    @AppStorage("sortKey") private var sortKey = "name"
    @AppStorage("sortAsc") private var sortAsc = true
    @State private var filesSize: Int64 = 0
    @State private var thumbSize: Int64 = 0

    var body: some View {
        NavigationStack {
            Form {
                Section("Hiển thị mặc định") {
                    Picker("Chế độ xem", selection: $viewMode) {
                        Text("Danh sách").tag("list"); Text("Lưới").tag("grid"); Text("Thư viện ảnh").tag("gallery")
                    }
                    Picker("Sắp xếp theo", selection: $sortKey) {
                        Text("Tên").tag("name"); Text("Dung lượng").tag("size"); Text("Ngày chỉnh sửa").tag("date")
                    }
                    Toggle("Tăng dần", isOn: $sortAsc)
                }
                Section("Lưu trữ") {
                    LabeledContent("Tệp", value: Fmt.size(filesSize))
                    LabeledContent("Thùng rác", value: Fmt.size(trash.entries.reduce(0) { $0 + $1.size }))
                    LabeledContent("Bộ nhớ đệm hình thu nhỏ", value: Fmt.size(thumbSize))
                    Button("Xóa bộ nhớ đệm hình thu nhỏ") { Thumbs.clearDisk(); refresh() }
                }
                Section("Thông tin") {
                    LabeledContent("Phiên bản", value: "1.1")
                    Text("Mục trong Thùng rác được tự động xóa vĩnh viễn sau 30 ngày.").font(.footnote).foregroundStyle(.secondary)
                }
            }
            .navigationTitle("Cài đặt")
            .onAppear { refresh() }
        }
    }

    private func refresh() {
        Task {
            let (f, t) = await Task.detached { (FileOps.size(of: Paths.files), FileOps.size(of: Paths.thumbs)) }.value
            filesSize = f; thumbSize = t
        }
    }
}
