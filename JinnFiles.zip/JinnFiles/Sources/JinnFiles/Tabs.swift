import SwiftUI

/// Màn hình Thùng rác (đặt trong Công cụ và Cài đặt)
struct TrashScreen: View {
    @EnvironmentObject var trash: TrashStore
    @AppStorage("trashViewMode") private var mode = "list"
    @State private var selecting = false
    @State private var selection = Set<UUID>()
    @State private var confirmDelete = false
    @State private var confirmEmpty = false
    @State private var pendingDeleteIDs = Set<UUID>()
    @State private var needLocation: [TrashEntry] = []
    @State private var showPicker = false
    @State private var message: String?

    private var sorted: [TrashEntry] { trash.entries.sorted { $0.deletedAt > $1.deletedAt } }

    /// Dựng thông tin hiển thị mà không đọc ổ đĩa (dùng ngày xóa làm khóa bộ nhớ đệm hình thu nhỏ)
    private func item(_ e: TrashEntry) -> FileItem {
        FileItem(url: e.payload, isDirectory: e.isDirectory, size: e.size, modified: e.deletedAt, created: nil, kind: e.kind)
    }

    var body: some View {
        Group {
                if trash.entries.isEmpty {
                    ContentUnavailableView("Thùng rác trống", systemImage: "trash",
                                           description: Text("Mục đã xóa được giữ 30 ngày."))
                } else if mode == "grid" {
                    gridView
                } else {
                    listView
                }
            }
            .navigationTitle("Thùng rác")
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    if !trash.entries.isEmpty {
                        Menu {
                            Picker("Kiểu hiển thị", selection: $mode) {
                                Label("Danh sách", systemImage: "list.bullet").tag("list")
                                Label("Lưới (hình thu nhỏ)", systemImage: "square.grid.2x2").tag("grid")
                            }
                            Divider()
                            Button(selecting ? "Xong" : "Chọn nhiều") { selecting.toggle(); selection.removeAll() }
                            if selecting {
                                Button(selection.count == trash.entries.count ? "Bỏ chọn tất cả" : "Chọn tất cả") {
                                    if selection.count == trash.entries.count { selection.removeAll() }
                                    else { selection = Set(trash.entries.map(\.id)) }
                                }
                            }
                            Button("Xóa toàn bộ Thùng rác", role: .destructive) { confirmEmpty = true }
                        } label: { Image(systemName: "ellipsis.circle") }
                    }
                }
            }
            .onAppear { trash.purgeExpired() }
            .safeAreaInset(edge: .bottom) {
                if selecting {
                    HStack(spacing: 10) {
                        Button { restore(trash.entries.filter { selection.contains($0.id) }) } label: {
                            Label("Khôi phục", systemImage: "arrow.uturn.backward").frame(maxWidth: .infinity)
                        }
                        .glassButtonStyle(prominent: true)
                        Button(role: .destructive) { pendingDeleteIDs = selection; confirmDelete = true } label: {
                            Label("Xóa vĩnh viễn", systemImage: "trash").frame(maxWidth: .infinity)
                        }
                        .glassButtonStyle()
                    }
                    .controlSize(.large)
                    .disabled(selection.isEmpty)
                    .padding(.horizontal, 16).padding(.bottom, 6)
                }
            }
            .confirmationDialog("Xóa vĩnh viễn \(pendingDeleteIDs.count) mục? Không thể khôi phục.", isPresented: $confirmDelete, titleVisibility: .visible) {
                Button("Xóa vĩnh viễn", role: .destructive) {
                    let f = trash.deleteForever(pendingDeleteIDs)
                    if f > 0 { message = "\(f) mục không xóa được." }
                    selection.removeAll()
                }
                Button("Hủy", role: .cancel) {}
            }
            .confirmationDialog("Xóa toàn bộ Thùng rác? Không thể khôi phục.", isPresented: $confirmEmpty, titleVisibility: .visible) {
                Button("Xóa toàn bộ", role: .destructive) { _ = trash.emptyAll(); selection.removeAll() }
                Button("Hủy", role: .cancel) {}
            }
            .sheet(isPresented: $showPicker) {
                FolderPicker(title: "Khôi phục vào…", exclude: []) { d in
                    for e in needLocation { try? trash.restore(e, into: d) }
                    needLocation = []; selection.removeAll()
                }
            }
            .alert("Thông báo", isPresented: Binding(get: { message != nil }, set: { if !$0 { message = nil } })) {
                Button("OK") { message = nil }
            } message: { Text(message ?? "") }
    }

    // MARK: Danh sách và lưới

    @ViewBuilder private func tappable<C: View>(_ e: TrashEntry, @ViewBuilder _ content: () -> C) -> some View {
        Group {
            if selecting {
                Button { toggle(e.id) } label: { content() }
            } else if !e.isDirectory {
                NavigationLink { PreviewView(item: item(e)) } label: { content() }
            } else {
                content()
            }
        }
        .buttonStyle(.plain)
        .contextMenu {
            Button { restore([e]) } label: { Label("Khôi phục", systemImage: "arrow.uturn.backward") }
            Button(role: .destructive) { pendingDeleteIDs = [e.id]; confirmDelete = true } label: { Label("Xóa vĩnh viễn", systemImage: "trash") }
        }
    }

    private func check(_ e: TrashEntry) -> some View {
        Image(systemName: selection.contains(e.id) ? "checkmark.circle.fill" : "circle")
            .foregroundStyle(selection.contains(e.id) ? Color.accentColor : .secondary)
    }

    private var listView: some View {
        List(sorted) { e in
            tappable(e) {
                HStack(spacing: 12) {
                    if selecting { check(e).font(.title3) }
                    ThumbView(item: item(e)).frame(width: 52, height: 52)
                        .background(Color(.secondarySystemBackground))
                        .clipShape(RoundedRectangle(cornerRadius: 8))
                    VStack(alignment: .leading, spacing: 2) {
                        Text(e.name).lineLimit(1)
                        Text("\(e.kind.label) • \(Fmt.size(e.size))").font(.caption).foregroundStyle(.secondary)
                        Text("Xóa: \(Fmt.date(e.deletedAt)) • Còn \(e.daysLeft) ngày").font(.caption2).foregroundStyle(.secondary)
                    }
                    Spacer()
                }
                .contentShape(Rectangle())
            }
            .swipeActions(edge: .leading) {
                Button { restore([e]) } label: { Label("Khôi phục", systemImage: "arrow.uturn.backward") }.tint(.green)
            }
            .swipeActions(edge: .trailing) {
                Button(role: .destructive) { pendingDeleteIDs = [e.id]; confirmDelete = true } label: { Label("Xóa", systemImage: "trash") }
            }
        }
        .listStyle(.plain)
    }

    private var gridView: some View {
        ScrollView {
            LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 10), count: 3), spacing: 12) {
                ForEach(sorted) { e in
                    tappable(e) {
                        VStack(spacing: 6) {
                            Color.clear.aspectRatio(1, contentMode: .fit)
                                .overlay { ThumbView(item: item(e)) }
                                .background(Color(.secondarySystemBackground))
                                .clipShape(RoundedRectangle(cornerRadius: 12))
                                .overlay(alignment: .topLeading) { if selecting { check(e).font(.title3).padding(6) } }
                            Text(e.name).font(.caption2).lineLimit(2).multilineTextAlignment(.center)
                            Text("\(Fmt.size(e.size)) • còn \(e.daysLeft) ngày").font(.system(size: 10)).foregroundStyle(.secondary)
                        }
                    }
                }
            }
            .padding()
        }
    }

    private func toggle(_ id: UUID) {
        if selection.contains(id) { selection.remove(id) } else { selection.insert(id) }
    }

    private func restore(_ list: [TrashEntry]) {
        var missing: [TrashEntry] = []
        var failed = 0
        for e in list {
            if let p = trash.originalParent(of: e) {
                do { try trash.restore(e, into: p) } catch { failed += 1 }
            } else { missing.append(e) }
        }
        if failed > 0 { message = "\(failed) mục khôi phục thất bại." }
        if missing.isEmpty { selection.removeAll() } else { needLocation = missing; showPicker = true }
    }
}

struct SettingsView: View {
    @EnvironmentObject var trash: TrashStore
    @AppStorage("appearance") private var appearance = AppearanceMode.system.rawValue
    @AppStorage("theme") private var themeID = AppTheme.blue.rawValue
    @AppStorage("viewMode") private var viewMode = "list"
    @AppStorage("sortKey") private var sortKey = "name"
    @AppStorage("sortAsc") private var sortAsc = true
    @State private var filesSize: Int64 = 0
    @State private var thumbSize: Int64 = 0
    @State private var driveCacheSize: Int64 = 0

    var body: some View {
        NavigationStack {
            Form {
                Section("Giao diện") {
                    Picker("Chế độ nền", selection: $appearance) {
                        ForEach(AppearanceMode.allCases) { Text($0.title).tag($0.rawValue) }
                    }
                    .pickerStyle(.segmented)
                }
                Section("Màu sắc ứng dụng") {
                    LazyVGrid(columns: [GridItem(.adaptive(minimum: 76), spacing: 12)], spacing: 14) {
                        ForEach(AppTheme.allCases) { t in swatch(t) }
                    }
                    .padding(.vertical, 6)
                }
                Section("Hiển thị mặc định") {
                    Picker("Chế độ xem", selection: $viewMode) {
                        Text("Danh sách").tag("list"); Text("Lưới").tag("grid"); Text("Thư viện ảnh").tag("gallery")
                    }
                    Picker("Sắp xếp theo", selection: $sortKey) {
                        Text("Tên").tag("name"); Text("Dung lượng").tag("size"); Text("Ngày chỉnh sửa").tag("date")
                    }
                    Toggle("Tăng dần", isOn: $sortAsc)
                }
                Section("Dữ liệu") {
                    NavigationLink { TrashScreen() } label: {
                        HStack {
                            Label("Thùng rác", systemImage: "trash")
                            Spacer()
                            Text("\(trash.entries.count) mục").foregroundStyle(.secondary)
                        }
                    }
                }
                Section("Lưu trữ") {
                    LabeledContent("Tệp", value: Fmt.size(filesSize))
                    LabeledContent("Thùng rác", value: Fmt.size(trash.entries.reduce(0) { $0 + $1.size }))
                    LabeledContent("Bộ nhớ đệm hình thu nhỏ", value: Fmt.size(thumbSize))
                    Button("Xóa bộ nhớ đệm hình thu nhỏ") { Thumbs.clearDisk(); refresh() }
                    LabeledContent("Bộ nhớ đệm Google Drive", value: Fmt.size(driveCacheSize))
                    Button("Xóa bộ nhớ đệm Google Drive") { DriveAPI.clearCache(); refresh() }
                }
                Section("Thông tin") {
                    LabeledContent("Phiên bản", value: "3.2")
                    Text("Mục trong Thùng rác được tự động xóa vĩnh viễn sau 30 ngày.").font(.footnote).foregroundStyle(.secondary)
                }
            }
            .navigationTitle("Cài đặt")
            .onAppear { refresh() }
        }
    }

    private func swatch(_ t: AppTheme) -> some View {
        Button { withAnimation { themeID = t.rawValue } } label: {
            VStack(spacing: 6) {
                ZStack {
                    Circle()
                        .fill(LinearGradient(colors: [t.blobs[0], t.blobs[1]], startPoint: .topLeading, endPoint: .bottomTrailing))
                        .frame(width: 48, height: 48)
                    if themeID == t.rawValue {
                        Image(systemName: "checkmark").font(.headline).foregroundStyle(.white)
                    }
                }
                .overlay(Circle().stroke(themeID == t.rawValue ? t.accent : Color.clear, lineWidth: 3).frame(width: 56, height: 56))
                Text(t.title).font(.caption).foregroundStyle(.primary).lineLimit(1)
            }
            .frame(maxWidth: .infinity)
        }
        .buttonStyle(.plain)
    }

    private func refresh() {
        Task {
            let r: (Int64, Int64, Int64) = await Task.detached {
                (FileOps.size(of: Paths.files), FileOps.size(of: Paths.thumbs), FileOps.size(of: DriveAPI.cacheDir))
            }.value
            filesSize = r.0; thumbSize = r.1; driveCacheSize = r.2
        }
    }
}
