import SwiftUI
import UIKit

struct DocumentPicker: UIViewControllerRepresentable {
    var onPick: ([URL]) -> Void
    func makeUIViewController(context: Context) -> UIDocumentPickerViewController {
        let p = UIDocumentPickerViewController(forOpeningContentTypes: [.item], asCopy: true)
        p.allowsMultipleSelection = true
        p.delegate = context.coordinator
        return p
    }
    func updateUIViewController(_ vc: UIDocumentPickerViewController, context: Context) {}
    func makeCoordinator() -> Coord { Coord(onPick) }
    final class Coord: NSObject, UIDocumentPickerDelegate {
        let onPick: ([URL]) -> Void
        init(_ f: @escaping ([URL]) -> Void) { onPick = f }
        func documentPicker(_ c: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) { onPick(urls) }
    }
}

struct PagerItem: Identifiable { let id = UUID(); let urls: [URL]; let index: Int }

enum Sheet: Identifiable {
    case importer, info(FileItem), copy([URL]), move([URL]), extract(FileItem)
    var id: String {
        switch self {
        case .importer: return "imp"
        case .info(let i): return "info" + i.url.path
        case .copy: return "copy"
        case .move: return "move"
        case .extract(let i): return "ext" + i.url.path
        }
    }
}

struct FolderView: View {
    @StateObject private var model: FolderModel
    @AppStorage("viewMode") private var viewMode = "list"
    @AppStorage("sortKey") private var sortKey = "name"
    @AppStorage("sortAsc") private var sortAsc = true

    @State private var query = ""
    @State private var sheet: Sheet?
    @State private var pager: PagerItem?
    @State private var showNew = false
    @State private var newName = ""
    @State private var showRename = false
    @State private var renameTarget: FileItem?
    @State private var renameText = ""
    @State private var showDelete = false
    @State private var pendingDelete: [URL] = []
    @State private var extractTarget: FileItem?
    @State private var showExtract = false

    init(url: URL) { _model = StateObject(wrappedValue: FolderModel(url: url)) }

    private var isRoot: Bool { model.url.resolvingSymlinksInPath() == Paths.files.resolvingSymlinksInPath() }
    private var searching: Bool { !query.isEmpty }

    private var displayItems: [FileItem] {
        let base = searching ? model.searchResults : model.items
        let cmp: (FileItem, FileItem) -> Bool = { a, b in
            let r: Bool
            switch sortKey {
            case "size":
                let x = a.size ?? 0, y = b.size ?? 0
                r = x == y ? a.name.localizedStandardCompare(b.name) == .orderedAscending : x < y
            case "date": r = a.modified < b.modified
            default: r = a.name.localizedStandardCompare(b.name) == .orderedAscending
            }
            return sortAsc ? r : !r
        }
        let folders = base.filter(\.isDirectory).sorted(by: cmp)
        let files = base.filter { !$0.isDirectory }.sorted(by: cmp)
        return folders + files
    }

    var body: some View {
        let items = displayItems
        Group {
            if items.isEmpty {
                ContentUnavailableView(searching ? "Không tìm thấy" : "Thư mục trống",
                                       systemImage: searching ? "magnifyingglass" : "folder",
                                       description: Text(searching ? "Thử từ khóa khác." : "Nhập tệp hoặc tạo thư mục mới."))
            } else {
                switch viewMode {
                case "grid": gridView(items)
                case "gallery": galleryView(items)
                default: listView(items)
                }
            }
        }
        .navigationTitle(isRoot ? "Tệp của tôi" : model.url.lastPathComponent)
        .navigationBarTitleDisplayMode(.inline)
        .searchable(text: $query, prompt: "Tìm tệp và thư mục")
        .onChange(of: query) { _, q in model.search(q) }
        .refreshable { model.reload() }
        .onAppear { model.reload() }
        .toolbar { toolbar }
        .overlay { busyOverlay }
        .sheet(item: $sheet) { s in sheetContent(s) }
        .fullScreenCover(item: $pager) { p in ImagePager(urls: p.urls, start: p.index, onClose: { pager = nil }) }
        .alert("Thông báo", isPresented: Binding(get: { model.message != nil }, set: { if !$0 { model.message = nil } })) {
            Button("OK") { model.message = nil }
        } message: { Text(model.message ?? "") }
        .alert("Thư mục mới", isPresented: $showNew) {
            TextField("Tên thư mục", text: $newName)
            Button("Hủy", role: .cancel) {}
            Button("Tạo") { model.createFolder(newName) }
        }
        .alert("Đổi tên", isPresented: $showRename) {
            TextField("Tên mới", text: $renameText)
            Button("Hủy", role: .cancel) {}
            Button("Lưu") { if let t = renameTarget { model.rename(t, to: renameText) } }
        }
        .confirmationDialog("Chuyển \(pendingDelete.count) mục vào Thùng rác?", isPresented: $showDelete, titleVisibility: .visible) {
            Button("Chuyển vào Thùng rác", role: .destructive) { model.delete(pendingDelete) }
            Button("Hủy", role: .cancel) {}
        } message: { Text("Có thể khôi phục trong 30 ngày.") }
        .confirmationDialog("Giải nén", isPresented: $showExtract, titleVisibility: .visible) {
            if let t = extractTarget {
                Button("Vào thư mục mới cùng tên") { model.extract(t, mode: .newFolder) }
                Button("Vào thư mục hiện tại") { model.extract(t, mode: .here) }
                Button("Chọn thư mục đích…") { sheet = .extract(t) }
            }
            Button("Hủy", role: .cancel) {}
        } message: { Text("Tệp trùng tên sẽ được đổi tên, không bị ghi đè.") }
    }

    // MARK: Toolbar

    @ToolbarContentBuilder
    private var toolbar: some ToolbarContent {
        ToolbarItem(placement: .topBarTrailing) {
            if model.selecting {
                Button("Xong") { model.endSelecting() }
            } else {
                Menu {
                    Picker("Chế độ xem", selection: $viewMode) {
                        Label("Danh sách", systemImage: "list.bullet").tag("list")
                        Label("Lưới", systemImage: "square.grid.2x2").tag("grid")
                        Label("Thư viện ảnh", systemImage: "photo.on.rectangle").tag("gallery")
                    }
                    Picker("Sắp xếp", selection: $sortKey) {
                        Text("Tên").tag("name")
                        Text("Dung lượng").tag("size")
                        Text("Ngày chỉnh sửa").tag("date")
                    }
                    Picker("Thứ tự", selection: $sortAsc) {
                        Label("Tăng dần", systemImage: "arrow.up").tag(true)
                        Label("Giảm dần", systemImage: "arrow.down").tag(false)
                    }
                    Divider()
                    Button { newName = ""; showNew = true } label: { Label("Thư mục mới", systemImage: "folder.badge.plus") }
                    Button { sheet = .importer } label: { Label("Nhập tệp", systemImage: "square.and.arrow.down") }
                    Button { model.selecting = true } label: { Label("Chọn nhiều", systemImage: "checkmark.circle") }
                } label: { Image(systemName: "ellipsis.circle") }
            }
        }
        ToolbarItemGroup(placement: .bottomBar) {
            if model.selecting {
                let urls = Array(model.selection)
                Button { sheet = .move(urls) } label: { Image(systemName: "folder") }.disabled(urls.isEmpty)
                Spacer()
                Button { sheet = .copy(urls) } label: { Image(systemName: "doc.on.doc") }.disabled(urls.isEmpty)
                Spacer()
                Button { model.zipSelected(urls) } label: { Image(systemName: "doc.zipper") }.disabled(urls.isEmpty)
                Spacer()
                if urls.isEmpty {
                    Image(systemName: "square.and.arrow.up").foregroundStyle(.secondary)
                } else {
                    ShareLink(items: urls) { Image(systemName: "square.and.arrow.up") }
                }
                Spacer()
                Button(role: .destructive) { pendingDelete = urls; showDelete = true } label: { Image(systemName: "trash") }
                    .disabled(urls.isEmpty)
            }
        }
    }

    @ViewBuilder private var busyOverlay: some View {
        if let b = model.busy {
            ZStack {
                Color.black.opacity(0.3).ignoresSafeArea()
                VStack(spacing: 12) {
                    if let f = b.fraction { ProgressView(value: f) } else { ProgressView() }
                    Text(b.title).font(.footnote)
                }
                .padding(20).frame(width: 240)
                .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 16))
            }
        }
    }

    @ViewBuilder private func sheetContent(_ s: Sheet) -> some View {
        switch s {
        case .importer:
            DocumentPicker { urls in sheet = nil; model.importFiles(urls) }
        case .info(let i):
            InfoView(item: i)
        case .copy(let urls):
            FolderPicker(title: "Sao chép vào…", exclude: []) { d in model.copy(urls, to: d) }
        case .move(let urls):
            FolderPicker(title: "Di chuyển vào…", exclude: urls) { d in model.move(urls, to: d) }
        case .extract(let item):
            FolderPicker(title: "Giải nén vào…", exclude: []) { d in model.extract(item, mode: .into(d)) }
        }
    }

    // MARK: Hàng / ô

    @ViewBuilder private func tappable<C: View>(_ item: FileItem, @ViewBuilder _ content: () -> C) -> some View {
        Group {
            if model.selecting {
                Button { model.toggle(item) } label: { content() }
            } else {
                NavigationLink(value: item) { content() }
            }
        }
        .buttonStyle(.plain)
        .contextMenu { menu(item) }
    }

    @ViewBuilder private func menu(_ item: FileItem) -> some View {
        Button { renameTarget = item; renameText = item.name; showRename = true } label: { Label("Đổi tên", systemImage: "pencil") }
        Button { sheet = .copy([item.url]) } label: { Label("Sao chép vào…", systemImage: "doc.on.doc") }
        Button { sheet = .move([item.url]) } label: { Label("Di chuyển vào…", systemImage: "folder") }
        if item.kind == .archive {
            Button { extractTarget = item; showExtract = true } label: { Label("Giải nén", systemImage: "arrow.down.doc") }
        }
        Button { model.zipSelected([item.url]) } label: { Label("Nén ZIP", systemImage: "doc.zipper") }
        if !item.isDirectory { ShareLink(item: item.url) { Label("Chia sẻ", systemImage: "square.and.arrow.up") } }
        Button { sheet = .info(item) } label: { Label("Thông tin", systemImage: "info.circle") }
        Button(role: .destructive) { pendingDelete = [item.url]; showDelete = true } label: { Label("Xóa", systemImage: "trash") }
    }

    private func check(_ item: FileItem) -> some View {
        Image(systemName: model.selection.contains(item.url) ? "checkmark.circle.fill" : "circle")
            .foregroundStyle(model.selection.contains(item.url) ? Color.accentColor : .secondary)
    }

    private func listView(_ items: [FileItem]) -> some View {
        List(items) { item in
            tappable(item) {
                HStack(spacing: 12) {
                    if model.selecting { check(item) }
                    ThumbView(item: item)
                        .frame(width: 44, height: 44)
                        .clipShape(RoundedRectangle(cornerRadius: 8))
                    VStack(alignment: .leading, spacing: 2) {
                        Text(item.name).lineLimit(1)
                        Text(subtitle(item)).font(.caption).foregroundStyle(.secondary).lineLimit(1)
                    }
                    Spacer()
                }
                .contentShape(Rectangle())
            }
            .swipeActions {
                Button(role: .destructive) { pendingDelete = [item.url]; showDelete = true } label: { Label("Xóa", systemImage: "trash") }
            }
        }
        .listStyle(.plain)
    }

    private func subtitle(_ item: FileItem) -> String {
        var parts: [String] = []
        if searching { parts.append(FileOps.relative(item.url)) }
        if let s = item.size { parts.append(Fmt.size(s)) }
        parts.append(Fmt.date(item.modified))
        return parts.joined(separator: " • ")
    }

    private func gridView(_ items: [FileItem]) -> some View {
        ScrollView {
            LazyVGrid(columns: [GridItem(.adaptive(minimum: 100), spacing: 12)], spacing: 14) {
                ForEach(items) { item in
                    tappable(item) {
                        VStack(spacing: 6) {
                            ZStack(alignment: .topLeading) {
                                ThumbView(item: item)
                                    .frame(maxWidth: .infinity).frame(height: 96)
                                    .background(Color(.secondarySystemBackground))
                                    .clipShape(RoundedRectangle(cornerRadius: 10))
                                if model.selecting { check(item).padding(6) }
                            }
                            Text(item.name).font(.caption).lineLimit(3).multilineTextAlignment(.center)
                        }
                    }
                }
            }
            .padding()
        }
    }

    private func galleryView(_ items: [FileItem]) -> some View {
        let folders = items.filter(\.isDirectory)
        let images = items.filter { $0.kind == .image }
        let urls = images.map(\.url)
        return ScrollView {
            LazyVStack(alignment: .leading, spacing: 8) {
                ForEach(folders) { f in
                    tappable(f) {
                        HStack { Image(systemName: "folder.fill").foregroundStyle(.blue); Text(f.name); Spacer() }
                            .padding(.horizontal).padding(.vertical, 6)
                    }
                }
                LazyVGrid(columns: [GridItem(.flexible(), spacing: 8), GridItem(.flexible(), spacing: 8)], spacing: 8) {
                    ForEach(Array(images.enumerated()), id: \.element.id) { idx, img in
                        GalleryCell(item: img)
                            .onTapGesture { pager = PagerItem(urls: urls, index: idx) }
                            .contextMenu { menu(img) }
                    }
                }
                .padding(.horizontal, 8)
                if images.isEmpty {
                    Text("Không có ảnh trong thư mục này.").foregroundStyle(.secondary).padding()
                }
            }
        }
    }
}

/// Ô ảnh: giữ đúng tỷ lệ, không cắt (scaledToFit)
struct GalleryCell: View {
    let item: FileItem
    @State private var image: UIImage?
    var body: some View {
        ZStack {
            if let image {
                Image(uiImage: image).resizable().scaledToFit().frame(maxWidth: .infinity)
            } else {
                ProgressView().frame(maxWidth: .infinity, minHeight: 140)
            }
        }
        .background(Color(.secondarySystemBackground))
        .clipShape(RoundedRectangle(cornerRadius: 8))
        .task(id: item.url) { image = await Thumbs.thumbnail(for: item, maxPixel: 900) }
    }
}

struct FolderPicker: View {
    let title: String
    let exclude: [URL]
    let onPick: (URL) -> Void
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            FolderPickerLevel(url: Paths.files, title: title, exclude: exclude, onPick: { onPick($0); dismiss() }, onCancel: { dismiss() })
        }
    }
}

struct FolderPickerLevel: View {
    let url: URL
    let title: String
    let exclude: [URL]
    let onPick: (URL) -> Void
    let onCancel: () -> Void

    var body: some View {
        let folders = FileOps.list(url).filter { f in
            f.isDirectory && !exclude.contains { $0.resolvingSymlinksInPath() == f.url.resolvingSymlinksInPath() }
        }.sorted { $0.name.localizedStandardCompare($1.name) == .orderedAscending }
        List {
            ForEach(folders) { f in
                NavigationLink {
                    FolderPickerLevel(url: f.url, title: title, exclude: exclude, onPick: onPick, onCancel: onCancel)
                } label: { Label(f.name, systemImage: "folder.fill") }
            }
            if folders.isEmpty { Text("Không có thư mục con").foregroundStyle(.secondary) }
        }
        .navigationTitle(url == Paths.files ? title : url.lastPathComponent)
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .topBarLeading) { Button("Hủy", action: onCancel) }
            ToolbarItem(placement: .bottomBar) {
                Button("Chọn thư mục này") { onPick(url) }.fontWeight(.semibold)
            }
        }
    }
}

struct InfoView: View {
    let item: FileItem
    @State private var size: Int64?
    @Environment(\.dismiss) private var dismiss
    var body: some View {
        NavigationStack {
            Form {
                row("Tên", item.name)
                row("Định dạng", item.isDirectory ? "Thư mục" : (item.url.pathExtension.isEmpty ? item.kind.label : item.url.pathExtension.uppercased()))
                row("Dung lượng", size.map(Fmt.size) ?? "Đang tính…")
                if let c = item.created { row("Ngày tạo", Fmt.date(c)) }
                row("Chỉnh sửa gần nhất", Fmt.date(item.modified))
                row("Vị trí", "Files/" + FileOps.relative(item.url.deletingLastPathComponent()))
            }
            .navigationTitle("Thông tin")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .topBarTrailing) { Button("Đóng") { dismiss() } } }
            .task {
                let u = item.url
                size = await Task.detached { FileOps.size(of: u) }.value
            }
        }
        .presentationDetents([.medium])
    }
    private func row(_ k: String, _ v: String) -> some View {
        LabeledContent(k) { Text(v).multilineTextAlignment(.trailing) }
    }
}
