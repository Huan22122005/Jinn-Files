import SwiftUI
import WebKit
import Network

// MARK: - Mô hình cấu hình Proxy / VPN trình duyệt

enum ProxyProtocol: String, Codable, CaseIterable, Identifiable {
    case http = "HTTP"
    case socks5 = "SOCKS5"

    var id: String { rawValue }

    var label: String {
        switch self {
        case .http: return "HTTP / HTTPS"
        case .socks5: return "SOCKS5"
        }
    }
}

struct VPNProfile: Codable, Identifiable, Hashable {
    var id = UUID()
    var name: String
    var protocolType: ProxyProtocol = .http
    var host: String
    var port: UInt16
    var username: String = ""
    var password: String = ""

    var summary: String {
        "\(protocolType.rawValue) • \(host):\(port)"
    }
}

private struct VPNSettingsData: Codable {
    var isEnabled: Bool = false
    var profiles: [VPNProfile] = []
    var selectedProfileID: UUID?
}

// MARK: - Quản lý VPN / Proxy tích hợp cho WKWebView (iOS 17+)

@MainActor
final class BrowserVPNManager: ObservableObject {
    static let shared = BrowserVPNManager()

    @Published var isEnabled: Bool = false {
        didSet { guard !isLoadingSettings else { return }; save(); applyToBrowser() }
    }
    @Published var profiles: [VPNProfile] = [] {
        didSet { guard !isLoadingSettings else { return }; save(); applyToBrowser() }
    }
    @Published var selectedProfileID: UUID? {
        didSet { guard !isLoadingSettings else { return }; save(); applyToBrowser() }
    }

    @Published var isCheckingIP = false
    @Published var detectedIP: String?
    @Published var statusMessage: String?
    @Published var errorMessage: String?

    private var isLoadingSettings = false
    private var settingsFile: URL { Paths.meta.appendingPathComponent("browser-vpn.json") }

    var activeProfile: VPNProfile? {
        if let id = selectedProfileID, let p = profiles.first(where: { $0.id == id }) {
            return p
        }
        return profiles.first
    }

    var isActive: Bool {
        isEnabled && activeProfile != nil
    }

    private init() {
        Paths.bootstrap()
        load()
    }

    // MARK: - Tạo ProxyConfiguration cho iOS 17+

    func makeProxyConfiguration(for profile: VPNProfile? = nil) -> ProxyConfiguration? {
        guard let p = profile ?? activeProfile else { return nil }
        let cleanHost = p.host.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !cleanHost.isEmpty, let nwPort = NWEndpoint.Port(rawValue: p.port) else { return nil }
        let endpoint = NWEndpoint.hostPort(host: NWEndpoint.Host(cleanHost), port: nwPort)

        var cfg: ProxyConfiguration
        switch p.protocolType {
        case .http:
            cfg = ProxyConfiguration(httpCONNECTProxy: endpoint)
        case .socks5:
            cfg = ProxyConfiguration(socksv5Proxy: endpoint)
        }

        let u = p.username.trimmingCharacters(in: .whitespacesAndNewlines)
        if !u.isEmpty {
            cfg.applyCredential(username: u, password: p.password)
        }
        return cfg
    }

    func apply(to dataStore: WKWebsiteDataStore) {
        if isEnabled, let cfg = makeProxyConfiguration() {
            dataStore.proxyConfigurations = [cfg]
        } else {
            dataStore.proxyConfigurations = []
        }
    }

    func applyToBrowser() {
        BrowserStore.shared.applyProxySettings()
    }

    // MARK: - Quản lý máy chủ

    func addProfile(_ profile: VPNProfile, select: Bool = true) {
        profiles.insert(profile, at: 0)
        if select || selectedProfileID == nil {
            selectedProfileID = profile.id
        }
    }

    func removeProfiles(at offsets: IndexSet) {
        let removedIDs = Set(offsets.map { profiles[$0].id })
        profiles.remove(atOffsets: offsets)
        if let cur = selectedProfileID, removedIDs.contains(cur) {
            selectedProfileID = profiles.first?.id
        }
        if profiles.isEmpty {
            isEnabled = false
        }
    }

    func select(_ profile: VPNProfile) {
        selectedProfileID = profile.id
        detectedIP = nil
        statusMessage = nil
        errorMessage = nil
    }

    /// Phân tích nhanh chuỗi dạng "host:port" hoặc "host:port:user:pass"
    static func parseQuickString(_ raw: String, protocolType: ProxyProtocol = .http) -> VPNProfile? {
        var s = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        if s.isEmpty { return nil }
        var proto = protocolType
        if s.lowercased().hasPrefix("socks5://") {
            proto = .socks5
            s = String(s.dropFirst("socks5://".count))
        } else if s.lowercased().hasPrefix("http://") {
            proto = .http
            s = String(s.dropFirst("http://".count))
        } else if s.lowercased().hasPrefix("https://") {
            proto = .http
            s = String(s.dropFirst("https://".count))
        }

        let parts = s.split(separator: ":").map(String.init)
        guard parts.count >= 2, let port = UInt16(parts[1]), !parts[0].isEmpty else { return nil }
        let user = parts.count >= 3 ? parts[2] : ""
        let pass = parts.count >= 4 ? parts[3] : ""
        return VPNProfile(name: parts[0], protocolType: proto, host: parts[0], port: port, username: user, password: pass)
    }

    // MARK: - Kiểm tra kết nối & IP thực tế qua Proxy

    func testConnection() async {
        isCheckingIP = true
        statusMessage = nil
        errorMessage = nil
        detectedIP = nil
        defer { isCheckingIP = false }

        let config = URLSessionConfiguration.ephemeral
        config.timeoutIntervalForRequest = 12
        config.timeoutIntervalForResource = 15

        if isEnabled, let proxyCfg = makeProxyConfiguration() {
            config.proxyConfigurations = [proxyCfg]
        }

        let session = URLSession(configuration: config)
        defer { session.invalidateAndCancel() }

        do {
            let url = URL(string: "https://api.ipify.org?format=json")!
            let (data, resp) = try await session.data(from: url)
            let code = (resp as? HTTPURLResponse)?.statusCode ?? 0
            guard (200..<300).contains(code),
                  let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
                  let ip = obj["ip"] as? String else {
                errorMessage = "Máy chủ Proxy không phản hồi hợp lệ (mã \(code))."
                return
            }
            detectedIP = ip
            statusMessage = isActive
                ? "Kết nối Proxy thành công! IP hiện tại: \(ip)"
                : "Đang dùng mạng trực tiếp (VPN tắt). IP: \(ip)"
        } catch {
            errorMessage = "Không thể kết nối qua Proxy: \(error.localizedDescription)"
        }
    }

    // MARK: - Lưu / đọc cấu hình

    private func load() {
        guard let data = try? Data(contentsOf: settingsFile),
              let s = try? JSONDecoder().decode(VPNSettingsData.self, from: data) else { return }
        isLoadingSettings = true
        defer { isLoadingSettings = false }
        profiles = s.profiles
        selectedProfileID = s.selectedProfileID ?? s.profiles.first?.id
        isEnabled = s.isEnabled && !s.profiles.isEmpty
    }

    private func save() {
        let s = VPNSettingsData(isEnabled: isEnabled, profiles: profiles, selectedProfileID: selectedProfileID)
        guard let data = try? JSONEncoder().encode(s) else { return }
        let url = settingsFile
        DispatchQueue.global(qos: .utility).async { try? data.write(to: url, options: .atomic) }
    }
}

// MARK: - Giao diện VPN Trình duyệt

struct BrowserVPNSheet: View {
    @ObservedObject private var vpn = BrowserVPNManager.shared
    @Environment(\.dismiss) private var dismiss

    @State private var showAdd = false

    var body: some View {
        NavigationStack {
            List {
                // Thẻ trạng thái & nút bật/tắt lớn
                Section {
                    VStack(spacing: 12) {
                        ZStack {
                            Circle()
                                .fill((vpn.isActive ? Color.blue : Color.secondary).opacity(0.15))
                                .frame(width: 68, height: 68)
                            Image(systemName: vpn.isActive ? "network.badge.shield.half.filled" : "network.slash")
                                .font(.system(size: 32))
                                .foregroundStyle(vpn.isActive ? .blue : .secondary)
                        }
                        Text(vpn.isActive ? "VPN Trình duyệt đang bật" : "VPN Trình duyệt đang tắt")
                            .font(.title3.bold())
                        if let p = vpn.activeProfile {
                            Text(p.name + " (" + p.summary + ")")
                                .font(.footnote)
                                .foregroundStyle(.secondary)
                        } else {
                            Text("Thêm ít nhất 1 máy chủ Proxy (HTTP/SOCKS5) để bật.")
                                .font(.footnote)
                                .foregroundStyle(.secondary)
                                .multilineTextAlignment(.center)
                        }
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 10)

                    Toggle(isOn: $vpn.isEnabled) {
                        Label("Bật VPN cho trình duyệt", systemImage: "power")
                    }
                    .tint(.blue)
                    .disabled(vpn.activeProfile == nil)

                    Button {
                        Task { await vpn.testConnection() }
                    } label: {
                        HStack {
                            Label("Kiểm tra kết nối & Xem IP", systemImage: "antenna.radiowaves.left.and.right")
                            Spacer()
                            if vpn.isCheckingIP {
                                ProgressView()
                            } else if let ip = vpn.detectedIP {
                                Text(ip).font(.caption.monospaced()).foregroundStyle(.secondary)
                            }
                        }
                    }
                    .disabled(vpn.isCheckingIP)
                }

                if let msg = vpn.statusMessage {
                    Section {
                        Label(msg, systemImage: "checkmark.circle.fill")
                            .foregroundStyle(.green)
                            .font(.subheadline)
                    }
                }
                if let err = vpn.errorMessage {
                    Section {
                        Label(err, systemImage: "exclamationmark.triangle.fill")
                            .foregroundStyle(.red)
                            .font(.subheadline)
                    }
                }

                // Danh sách máy chủ Proxy
                Section {
                    if vpn.profiles.isEmpty {
                        Button { showAdd = true } label: {
                            Label("Thêm máy chủ Proxy đầu tiên", systemImage: "plus.circle.fill")
                        }
                    } else {
                        ForEach(vpn.profiles) { p in
                            Button {
                                vpn.select(p)
                            } label: {
                                HStack(spacing: 12) {
                                    Image(systemName: vpn.activeProfile?.id == p.id ? "checkmark.circle.fill" : "circle")
                                        .foregroundStyle(vpn.activeProfile?.id == p.id ? Color.blue : .secondary)
                                        .font(.title3)
                                    VStack(alignment: .leading, spacing: 2) {
                                        Text(p.name).font(.headline).foregroundStyle(.primary)
                                        Text(p.summary).font(.caption).foregroundStyle(.secondary)
                                    }
                                    Spacer()
                                    if !p.username.isEmpty {
                                        Image(systemName: "lock.fill").font(.caption).foregroundStyle(.secondary)
                                    }
                                }
                            }
                            .buttonStyle(.plain)
                        }
                        .onDelete { vpn.removeProfiles(at: $0) }
                    }
                } header: {
                    HStack {
                        Text("Máy chủ Proxy")
                        Spacer()
                        Button { showAdd = true } label: {
                            Label("Thêm", systemImage: "plus").font(.caption.weight(.semibold))
                        }
                    }
                } footer: {
                    Text("Proxy chỉ áp dụng riêng cho trình duyệt trong Jinn Files, không cần quyền VPN hệ thống và hoạt động bình thường khi cài IPA sideload.")
                }
            }
            .listStyle(.insetGrouped)
            .navigationTitle("VPN Trình duyệt")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button { showAdd = true } label: { Image(systemName: "plus") }
                }
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Xong") { dismiss() }
                }
            }
            .sheet(isPresented: $showAdd) { AddVPNProfileSheet() }
        }
    }
}

struct AddVPNProfileSheet: View {
    @ObservedObject private var vpn = BrowserVPNManager.shared
    @Environment(\.dismiss) private var dismiss

    @State private var quickText = ""
    @State private var name = ""
    @State private var protocolType: ProxyProtocol = .http
    @State private var host = ""
    @State private var portText = "8080"
    @State private var username = ""
    @State private var password = ""

    private var isValid: Bool {
        !host.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty && UInt16(portText.trimmingCharacters(in: .whitespaces)) != nil
    }

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    HStack {
                        TextField("Dán nhanh: ip:port hoặc ip:port:user:pass", text: $quickText)
                            .textInputAutocapitalization(.never)
                            .autocorrectionDisabled()
                        Button("Điền") {
                            if let p = BrowserVPNManager.parseQuickString(quickText, protocolType: protocolType) {
                                name = p.name
                                protocolType = p.protocolType
                                host = p.host
                                portText = String(p.port)
                                username = p.username
                                password = p.password
                            }
                        }
                        .disabled(quickText.trimmingCharacters(in: .whitespaces).isEmpty)
                    }
                } header: {
                    Text("Nhập nhanh")
                }

                Section("Thông tin máy chủ") {
                    TextField("Tên gợi nhớ (vd: Singapore 1)", text: $name)
                    Picker("Giao thức", selection: $protocolType) {
                        ForEach(ProxyProtocol.allCases) { p in
                            Text(p.label).tag(p)
                        }
                    }
                    TextField("Địa chỉ máy chủ (IP hoặc tên miền)", text: $host)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                        .keyboardType(.URL)
                    TextField("Cổng (Port, vd: 8080, 1080)", text: $portText)
                        .keyboardType(.numberPad)
                }

                Section("Xác thực (để trống nếu không cần)") {
                    TextField("Tên đăng nhập", text: $username)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                    SecureField("Mật khẩu", text: $password)
                }
            }
            .navigationTitle("Thêm máy chủ Proxy")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button("Hủy") { dismiss() }
                }
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Lưu") {
                        let cleanHost = host.trimmingCharacters(in: .whitespacesAndNewlines)
                        let port = UInt16(portText.trimmingCharacters(in: .whitespaces)) ?? 8080
                        let cleanName = name.trimmingCharacters(in: .whitespacesAndNewlines)
                        let profile = VPNProfile(
                            name: cleanName.isEmpty ? cleanHost : cleanName,
                            protocolType: protocolType,
                            host: cleanHost,
                            port: port,
                            username: username.trimmingCharacters(in: .whitespacesAndNewlines),
                            password: password
                        )
                        vpn.addProfile(profile, select: true)
                        dismiss()
                    }
                    .fontWeight(.semibold)
                    .disabled(!isValid)
                }
            }
        }
    }
}
