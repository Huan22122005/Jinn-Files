import Foundation

extension FileOps {
    /// Toàn bộ tệp (không gồm thư mục) bên dưới một thư mục
    static func allFiles(in root: URL) -> [FileItem] {
        var out: [FileItem] = []
        guard let e = fm.enumerator(at: root, includingPropertiesForKeys: keys, options: [.skipsHiddenFiles]) else { return [] }
        while let u = e.nextObject() as? URL {
            let it = item(from: u)
            if !it.isDirectory && !Paths.isGoogleDrive(u.deletingLastPathComponent()) { out.append(it) }
        }
        return out.sorted { $0.modified > $1.modified }
    }
}
