import SwiftUI
import UniformTypeIdentifiers

extension FileOps {
    static func allMedia(in root: URL) -> [FileItem] {
        var out: [FileItem] = []
        guard let e = fm.enumerator(at: root, includingPropertiesForKeys: keys, options: [.skipsHiddenFiles]) else { return [] }
        while let u = e.nextObject() as? URL {
            let it = item(from: u)
            if it.kind == .image || it.kind == .video { out.append(it) }
        }
        return out.sorted { $0.modified > $1.modified }
    }

    static func allFiles(in root: URL) -> [FileItem] {
        var out: [FileItem] = []
        guard let e = fm.enumerator(at: root, includingPropertiesForKeys: keys, options: [.skipsHiddenFiles]) else { return [] }
        while let u = e.nextObject() as? URL {
            let it = item(from: u)
            if !it.isDirectory { out.append(it) }
        }
        return out.sorted { $0.modified > $1.modified }
    }
}

struct UploadJob: Identifiable, Equatable {
    enum State: Equatable { case waiting, uploading(Double), done, failed(String) }
    let id = UUID()
    let url: URL
    var state: State = .waiting
    var name: String { url.lastPathComponent }
}

final class UploadProgressDelegate: NSObject, URLSessionTaskDelegate, @unchecked Sendable {
    let onProgress: @Sendable (Double) -> Void
    init(_ f: @escaping @Sendable (Double) -> Void) { onProgress = f }
    func urlSession(_ s: URLSession, task: URLSessionTask, didSendBodyData b: Int64,
                    totalBytesSent t: Int64, totalBytesExpectedToSend e: Int64) {
        if e > 0 { onProgress(Double(t) / Double(e)) }
    }
}

/// Tải ảnh/video lên Google Photos (Library API, quyền photoslibrary.appendonly).
@MainActor
final class GooglePhotosUploader: ObservableObject {
    static let shared = GooglePhotosUploader()

    @Published private(set) var jobs: [UploadJob] = []
    @Published private(set) var running = false
    private var uploaded: Set<String>

    private let session: URLSession = {
        let c = URLSessionConfiguration.default
        c.timeoutIntervalForRequest = 600
        c.timeoutIntervalForResource = 7200
        c.waitsForConnectivity = true
        return URLSession(configuration: c)
    }()

    init() {
        uploaded = Set(UserDefaults.standard.stringArray(forKey: "gphotosUploaded") ?? [])
    }

    // MARK: Hàng đợi

    static func key(_ url: URL) -> String {
        let v = try? url.resourceValues(forKeys: [.contentModificationDateKey, .fileSizeKey])
        return "\(url.path)|\(Int(v?.contentModificationDate?.timeIntervalSince1970 ?? 0))|\(v?.fileSize ?? 0)"
    }

    func isUploaded(_ item: FileItem) -> Bool { uploaded.contains(Self.key(item.url)) }

    func enqueue(_ urls: [URL]) {
        for u in urls where !jobs.contains(where: { $0.url == u && ($0.state == .waiting || isUploading($0)) }) {
            jobs.append(UploadJob(url: u))
        }
        start()
    }

    func retryFailed() {
        for i in jobs.indices { if case .failed = jobs[i].state { jobs[i].state = .waiting } }
        start()
    }

    func clearFinished() {
        jobs.removeAll { j in
            if case .done = j.state { return true }
            if case .failed = j.state { return true }
            return false
        }
    }

    private func isUploading(_ j: UploadJob) -> Bool {
        if case .uploading = j.state { return true }
        return false
    }

    private func start() {
        guard !running else { return }
        running = true
        Task {
            while let i = jobs.firstIndex(where: { $0.state == .waiting }) {
                let id = jobs[i].id
                let url = jobs[i].url
                jobs[i].state = .uploading(0)
                do {
                    try await upload(url) { p in
                        Task { @MainActor in self.setState(id, .uploading(p)) }
                    }
                    setState(id, .done)
                    uploaded.insert(Self.key(url))
                    UserDefaults.standard.set(Array(uploaded), forKey: "gphotosUploaded")
                } catch {
                    setState(id, .failed(error.localizedDescription))
                }
            }
            running = false
        }
    }

    private func setState(_ id: UUID, _ s: UploadJob.State) {
        if let i = jobs.firstIndex(where: { $0.id == id }) { jobs[i].state = s }
    }

    // MARK: Gọi API

    private static func mime(_ url: URL) -> String {
        UTType(filenameExtension: url.pathExtension.lowercased())?.preferredMIMEType ?? "application/octet-stream"
    }

    private static func apiError(_ data: Data, _ code: Int) -> AppError {
        let o = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any]
        let msg = ((o?["error"] as? [String: Any])?["message"] as? String) ?? "Mã lỗi \(code)"
        var text = "Google Photos: \(msg)"
        if code == 403 { text += "\n(Kiểm tra đã bật Photos Library API và tài khoản nằm trong danh sách người dùng thử.)" }
        return AppError(text)
    }

    private func upload(_ url: URL, progress: @escaping @Sendable (Double) -> Void) async throws {
        let auth = GoogleAuth.shared
        guard FileManager.default.fileExists(atPath: url.path) else { throw AppError("Tệp không còn tồn tại.") }
        var forceRefresh = false
        for attempt in 0..<2 {
            let token = try await auth.accessToken(forceRefresh: forceRefresh)

            // Bước 1: tải dữ liệu thô từ tệp (không nạp vào RAM)
            var req = URLRequest(url: URL(string: "https://photoslibrary.googleapis.com/v1/uploads")!)
            req.httpMethod = "POST"
            req.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
            req.setValue("application/octet-stream", forHTTPHeaderField: "Content-type")
            req.setValue(Self.mime(url), forHTTPHeaderField: "X-Goog-Upload-Content-Type")
            req.setValue("raw", forHTTPHeaderField: "X-Goog-Upload-Protocol")
            let (data, resp) = try await session.upload(for: req, fromFile: url, delegate: UploadProgressDelegate(progress))
            let code = (resp as? HTTPURLResponse)?.statusCode ?? 0
            if code == 401 && attempt == 0 { forceRefresh = true; continue }
            guard code == 200, let uploadToken = String(data: data, encoding: .utf8), !uploadToken.isEmpty else {
                throw Self.apiError(data, code)
            }

            // Bước 2: tạo mục ảnh/video trong thư viện
            var req2 = URLRequest(url: URL(string: "https://photoslibrary.googleapis.com/v1/mediaItems:batchCreate")!)
            req2.httpMethod = "POST"
            req2.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
            req2.setValue("application/json", forHTTPHeaderField: "Content-Type")
            let body: [String: Any] = ["newMediaItems": [[
                "description": "",
                "simpleMediaItem": ["fileName": url.lastPathComponent, "uploadToken": uploadToken]
            ]]]
            req2.httpBody = try JSONSerialization.data(withJSONObject: body)
            let (d2, r2) = try await session.data(for: req2)
            let c2 = (r2 as? HTTPURLResponse)?.statusCode ?? 0
            guard c2 == 200 else { throw Self.apiError(d2, c2) }
            let o = (try? JSONSerialization.jsonObject(with: d2)) as? [String: Any]
            let first = (o?["newMediaItemResults"] as? [[String: Any]])?.first
            if first?["mediaItem"] == nil {
                let m = (first?["status"] as? [String: Any])?["message"] as? String ?? "Không tạo được mục trong thư viện."
                throw AppError("Google Photos: \(m)")
            }
            return
        }
        throw AppError("Phiên đăng nhập bị từ chối, hãy đăng nhập lại.")
    }
}
