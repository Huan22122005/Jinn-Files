import SwiftUI

@main
struct JinnFilesApp: App {
    @StateObject private var trash = TrashStore.shared
    @StateObject private var auth = GoogleAuth.shared
    @StateObject private var uploader = GooglePhotosUploader.shared
    @AppStorage("appearance") private var appearance = AppearanceMode.system.rawValue
    @Environment(\.scenePhase) private var phase

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(trash)
                .environmentObject(auth)
                .environmentObject(uploader)
                .preferredColorScheme(AppearanceMode(rawValue: appearance)?.scheme)
                .onAppear { trash.purgeExpired() }
                .onChange(of: phase) { _, p in
                    if p == .active { trash.purgeExpired() }
                }
        }
    }
}

struct RootView: View {
    var body: some View {
        TabView {
            FilesTab()
                .tabItem { Label("Tệp của tôi", systemImage: "folder") }
            ToolsTab()
                .tabItem { Label("Công cụ", systemImage: "square.grid.2x2.fill") }
            AccountTab()
                .tabItem { Label("Tài khoản", systemImage: "person.crop.circle") }
            TrashView()
                .tabItem { Label("Thùng rác", systemImage: "trash") }
            SettingsView()
                .tabItem { Label("Cài đặt", systemImage: "gearshape") }
        }
    }
}

struct FilesTab: View {
    var body: some View {
        NavigationStack {
            FolderView(url: Paths.files)
                .navigationDestination(for: FileItem.self) { item in
                    if item.isDirectory {
                        FolderView(url: item.url)
                    } else {
                        PreviewView(item: item)
                    }
                }
        }
    }
}
