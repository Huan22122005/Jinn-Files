import SwiftUI

@main
struct JinnFilesApp: App {
    @StateObject private var trash = TrashStore.shared
    @Environment(\.scenePhase) private var phase

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(trash)
                .onAppear { trash.purgeExpired() }
                .onChange(of: phase) { _, p in
                    if p == .active { trash.purgeExpired() }
                }
        }
    }
}

struct RootView: View {
    var body: some View {
        TabView {
            FilesTab()
                .tabItem { Label("Tệp của tôi", systemImage: "folder") }
            ExternalTab()
                .tabItem { Label("Trực tiếp", systemImage: "externaldrive") }
            GalleryTab()
                .tabItem { Label("Thư viện ảnh", systemImage: "photo.on.rectangle") }
            TrashView()
                .tabItem { Label("Thùng rác", systemImage: "trash") }
            SettingsView()
                .tabItem { Label("Cài đặt", systemImage: "gearshape") }
        }
    }
}

struct FilesTab: View {
    var body: some View {
        NavigationStack {
            FolderView(url: Paths.files)
                .navigationDestination(for: FileItem.self) { item in
                    if item.isDirectory {
                        FolderView(url: item.url)
                    } else {
                        PreviewView(item: item)
                    }
                }
        }
    }
}
