import SwiftUI

@main
struct JinnFilesApp: App {
    @UIApplicationDelegateAdaptor(AppDelegate.self) private var appDelegate
    @StateObject private var trash = TrashStore.shared
    @StateObject private var auth = GoogleAuth.shared
    @StateObject private var uploader = DriveUploader.shared
    @StateObject private var browser = BrowserStore.shared
    @StateObject private var downloads = DownloadManager.shared
    @StateObject private var clipboard = AppClipboard.shared
    @AppStorage("appearance") private var appearance = AppearanceMode.system.rawValue
    @AppStorage("theme") private var themeID = AppTheme.blue.rawValue
    @Environment(\.scenePhase) private var phase

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(trash)
                .environmentObject(auth)
                .environmentObject(uploader)
                .environmentObject(browser)
                .environmentObject(downloads)
                .environmentObject(clipboard)
                .preferredColorScheme(AppearanceMode(rawValue: appearance)?.scheme)
                .environment(\.locale, Locale(identifier: "vi_VN"))
                .tint((AppTheme(rawValue: themeID) ?? .blue).accent)
                .onAppear { trash.purgeExpired() }
                .onChange(of: phase) { _, p in
                    if p == .active { trash.purgeExpired() }
                }
        }
    }
}

struct RootView: View {
    @State private var selected = 0

    var body: some View {
        TabView(selection: $selected) {
            FilesTab()
                .tabItem { Label("Tệp của tôi", systemImage: "folder") }
                .tag(0)
            ToolsTab(onOpenBrowser: { selected = 3 })
                .tabItem { Label("Công cụ", systemImage: "square.grid.2x2.fill") }
                .tag(1)
            AccountTab()
                .tabItem { Label("Tài khoản", systemImage: "person.crop.circle") }
                .tag(2)
            BrowserView()
                .tabItem { Label("Trình duyệt", systemImage: "safari") }
                .tag(3)
            SettingsView()
                .tabItem { Label("Cài đặt", systemImage: "gearshape") }
                .tag(4)
        }
    }
}

struct FilesTab: View {
    var body: some View {
        NavigationStack {
            FolderView(url: Paths.files)
                .navigationDestination(for: DriveFolderRef.self) { DriveFolderView(folder: $0) }
                .navigationDestination(for: DriveFile.self) { DriveFilePreview(file: $0) }
                .navigationDestination(for: FileItem.self) { item in
                    if item.isDirectory {
                        if Paths.isGoogleDrive(item.url) { GoogleDriveBrowser() }
                        else { FolderView(url: item.url) }
                    } else {
                        PreviewView(item: item)
                    }
                }
        }
    }
}
