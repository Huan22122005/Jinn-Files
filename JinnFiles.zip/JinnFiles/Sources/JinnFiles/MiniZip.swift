import Foundation
import Compression

/// Đường dẫn đích an toàn cho một mục trong tệp nén (chặn "..", đường dẫn tuyệt đối).
/// Không dùng resolvingSymlinksInPath vì với tệp chưa tồn tại nó trả về "/private/var/..." khác với thư mục gốc "/var/...".
func safeExtractTarget(dest: URL, name: String) -> URL? {
    let comps = name.replacingOccurrences(of: "\\", with: "/").split(separator: "/").map(String.init).filter { $0 != "." }
    if name.hasPrefix("/") || comps.isEmpty || comps.contains("..") { return nil }
    return comps.reduce(dest) { $0.appendingPathComponent($1) }
}

// MARK: - Lỗi

enum ZipError: LocalizedError {
    case passwordRequired
    case wrongPassword
    case unsupported(String)
    case corrupt(String)
    case tooLarge

    var errorDescription: String? {
        switch self {
        case .passwordRequired: return "Tệp nén có mật khẩu. Hãy nhập mật khẩu."
        case .wrongPassword: return "Sai mật khẩu hoặc dữ liệu bị lỗi."
        case .unsupported(let s): return s
        case .corrupt(let s): return "Tệp nén bị lỗi: \(s)"
        case .tooLarge: return "Tệp lớn hơn 4 GB chưa được hỗ trợ khi nén có mật khẩu."
        }
    }
}

// MARK: - CRC32 và mã hóa ZipCrypto

enum Crc32 {
    static let table: [UInt32] = (0..<256).map { i -> UInt32 in
        var c = UInt32(i)
        for _ in 0..<8 { c = (c & 1) != 0 ? (0xEDB88320 ^ (c >> 1)) : (c >> 1) }
        return c
    }
    @inline(__always) static func step(_ crc: UInt32, _ b: UInt8) -> UInt32 {
        table[Int((crc ^ UInt32(b)) & 0xff)] ^ (crc >> 8)
    }
}

/// Bộ tính CRC32 chuẩn của tệp ZIP
struct FileCrc {
    private var value: UInt32 = 0xFFFFFFFF
    mutating func update(_ data: Data) { for b in data { value = Crc32.step(value, b) } }
    var checksum: UInt32 { value ^ 0xFFFFFFFF }
}

/// Mã hóa truyền thống của ZIP (PKWARE). Tương thích rộng nhưng không mạnh bằng AES.
final class ZipCrypto {
    private var k0: UInt32 = 305419896
    private var k1: UInt32 = 591751049
    private var k2: UInt32 = 878082192

    init(password: [UInt8]) { for b in password { update(b) } }

    private func update(_ c: UInt8) {
        k0 = Crc32.step(k0, c)
        k1 = (k1 &+ (k0 & 0xff)) &* 134775813 &+ 1
        k2 = Crc32.step(k2, UInt8(truncatingIfNeeded: k1 >> 24))
    }
    private func streamByte() -> UInt8 {
        let t = (k2 | 2) & 0xffff
        return UInt8(truncatingIfNeeded: (t &* (t ^ 1)) >> 8)
    }
    func encrypt(_ data: Data) -> Data {
        var out = Data(capacity: data.count)
        for p in data { let c = p ^ streamByte(); update(p); out.append(c) }
        return out
    }
    func decrypt(_ data: Data) -> Data {
        var out = Data(capacity: data.count)
        for c in data { let p = c ^ streamByte(); update(p); out.append(p) }
        return out
    }
}

// MARK: - Nén/giải nén deflate dạng luồng (Compression framework, deflate thô như ZIP)

final class StreamCodec {
    private var stream = compression_stream(dst_ptr: UnsafeMutablePointer<UInt8>(bitPattern: 1)!, dst_size: 0,
                                            src_ptr: UnsafePointer<UInt8>(bitPattern: 1)!, src_size: 0, state: nil)
    private var outBuffer = [UInt8](repeating: 0, count: 64 * 1024)

    init(encode: Bool) throws {
        let op = encode ? COMPRESSION_STREAM_ENCODE : COMPRESSION_STREAM_DECODE
        guard compression_stream_init(&stream, op, COMPRESSION_ZLIB) == COMPRESSION_STATUS_OK else {
            throw ZipError.unsupported("Không khởi tạo được bộ nén dữ liệu.")
        }
    }
    deinit { compression_stream_destroy(&stream) }

    /// Đưa một khối dữ liệu vào, gọi `out` cho mỗi phần dữ liệu đầu ra
    func process(_ input: Data, isFinal: Bool, out: (Data) throws -> Void) throws {
        let flags: Int32 = isFinal ? Int32(COMPRESSION_STREAM_FINALIZE.rawValue) : 0
        var failure: Error?
        input.withUnsafeBytes { (raw: UnsafeRawBufferPointer) in
            let base = raw.bindMemory(to: UInt8.self).baseAddress
            stream.src_ptr = base ?? UnsafePointer<UInt8>(bitPattern: 1)!
            stream.src_size = input.count
            var status = COMPRESSION_STATUS_OK
            repeat {
                outBuffer.withUnsafeMutableBufferPointer { ob in
                    stream.dst_ptr = ob.baseAddress!
                    stream.dst_size = ob.count
                    status = compression_stream_process(&stream, flags)
                    if status == COMPRESSION_STATUS_ERROR { return }
                    let produced = ob.count - stream.dst_size
                    if produced > 0 {
                        do { try out(Data(bytes: ob.baseAddress!, count: produced)) } catch { failure = error; status = COMPRESSION_STATUS_ERROR }
                    }
                }
            } while status == COMPRESSION_STATUS_OK && (isFinal || stream.src_size > 0 || stream.dst_size == 0)
            if status == COMPRESSION_STATUS_ERROR && failure == nil { failure = ZipError.corrupt("dữ liệu nén không hợp lệ") }
        }
        if let failure { throw failure }
    }
}

// MARK: - Ghi tệp ZIP (có thể đặt mật khẩu)

private extension Data {
    mutating func le16(_ v: UInt16) { append(UInt8(v & 0xff)); append(UInt8(v >> 8)) }
    mutating func le32(_ v: UInt32) { for i in 0..<4 { append(UInt8((v >> (8 * UInt32(i))) & 0xff)) } }
}

final class MiniZipWriter {
    private struct Entry {
        var name: [UInt8]; var flags: UInt16; var method: UInt16; var time: UInt16; var date: UInt16
        var crc: UInt32; var csize: UInt32; var usize: UInt32; var offset: UInt32; var isDir: Bool
    }

    private let handle: FileHandle
    private let password: [UInt8]?
    private var offset: UInt64 = 0
    private var entries: [Entry] = []

    /// Các định dạng vốn đã nén sẵn: lưu nguyên để nhanh hơn
    private static let storedExt: Set<String> = ["jpg", "jpeg", "png", "heic", "gif", "webp", "mp4", "mov", "m4v", "mkv",
                                                 "mp3", "m4a", "aac", "zip", "7z", "rar", "gz", "docx", "xlsx", "pptx", "pdf"]

    init(url: URL, password: String?) throws {
        guard FileManager.default.createFile(atPath: url.path, contents: nil) else {
            throw ZipError.unsupported("Không tạo được tệp nén.")
        }
        handle = try FileHandle(forWritingTo: url)
        if let p = password, !p.isEmpty { self.password = Array(p.utf8) } else { self.password = nil }
    }

    private func write(_ d: Data) throws {
        try handle.write(contentsOf: d)
        offset += UInt64(d.count)
    }

    private func dos(_ d: Date) -> (UInt16, UInt16) {
        let c = Calendar.current.dateComponents([.year, .month, .day, .hour, .minute, .second], from: d)
        let y = max(1980, c.year ?? 1980) - 1980
        let time = UInt16(((c.hour ?? 0) << 11) | ((c.minute ?? 0) << 5) | ((c.second ?? 0) / 2))
        let date = UInt16((y << 9) | ((c.month ?? 1) << 5) | (c.day ?? 1))
        return (time, date)
    }

    func addDirectory(name: String, modified: Date) throws {
        let nameBytes = Array((name.hasSuffix("/") ? name : name + "/").utf8)
        let (t, d) = dos(modified)
        guard offset < 0xFFFF_0000 else { throw ZipError.tooLarge }
        let off = UInt32(offset)
        var h = Data()
        h.le32(0x04034b50); h.le16(20); h.le16(0x0800); h.le16(0); h.le16(t); h.le16(d)
        h.le32(0); h.le32(0); h.le32(0); h.le16(UInt16(nameBytes.count)); h.le16(0)
        h.append(contentsOf: nameBytes)
        try write(h)
        entries.append(Entry(name: nameBytes, flags: 0x0800, method: 0, time: t, date: d, crc: 0, csize: 0, usize: 0, offset: off, isDir: true))
    }

    func addFile(name: String, source: URL, modified: Date, progress: (Int64) -> Void) throws {
        let size = Int64((try? source.resourceValues(forKeys: [.fileSizeKey]))?.fileSize ?? 0)
        guard size < 0xFFFF_0000, offset < 0xFFFF_0000 else { throw ZipError.tooLarge }
        let nameBytes = Array(name.utf8)
        let (t, d) = dos(modified)
        let encrypted = password != nil
        let stored = size == 0 || Self.storedExt.contains(source.pathExtension.lowercased())
        let method: UInt16 = stored ? 0 : 8
        let flags: UInt16 = 0x0800 | 0x0008 | (encrypted ? 1 : 0)
        let off = UInt32(offset)

        var h = Data()
        h.le32(0x04034b50); h.le16(20); h.le16(flags); h.le16(method); h.le16(t); h.le16(d)
        h.le32(0); h.le32(0); h.le32(0); h.le16(UInt16(nameBytes.count)); h.le16(0)
        h.append(contentsOf: nameBytes)
        try write(h)

        var csize: UInt64 = 0
        let cipher: ZipCrypto? = password.map { ZipCrypto(password: $0) }
        if let cipher {
            var hdr = [UInt8](repeating: 0, count: 12)
            _ = SecRandomCopyBytes(kSecRandomDefault, 11, &hdr)
            hdr[11] = UInt8(truncatingIfNeeded: t >> 8)     // khi có data descriptor, byte kiểm tra là byte cao của giờ
            let enc = cipher.encrypt(Data(hdr))
            try write(enc)
            csize += UInt64(enc.count)
        }

        let emit: (Data) throws -> Void = { [self] piece in
            let out = cipher?.encrypt(piece) ?? piece
            try write(out)
            csize += UInt64(out.count)
        }

        var crc = FileCrc()
        var usize: Int64 = 0
        let codec: StreamCodec? = stored ? nil : try StreamCodec(encode: true)
        if size > 0 {
            let reader = try FileHandle(forReadingFrom: source)
            defer { try? reader.close() }
            while let chunk = try reader.read(upToCount: 256 * 1024), !chunk.isEmpty {
                crc.update(chunk)
                usize += Int64(chunk.count)
                if let codec { try codec.process(chunk, isFinal: false, out: emit) } else { try emit(chunk) }
                progress(Int64(chunk.count))
            }
        }
        if let codec { try codec.process(Data(), isFinal: true, out: emit) }

        guard csize < 0xFFFF_FFFF else { throw ZipError.tooLarge }
        let c = crc.checksum
        var dd = Data()
        dd.le32(0x08074b50); dd.le32(c); dd.le32(UInt32(csize)); dd.le32(UInt32(usize))
        try write(dd)
        entries.append(Entry(name: nameBytes, flags: flags, method: method, time: t, date: d, crc: c,
                             csize: UInt32(csize), usize: UInt32(usize), offset: off, isDir: false))
    }

    func finish() throws {
        guard entries.count < 0xFFFF, offset < 0xFFFF_0000 else { throw ZipError.tooLarge }
        let cdStart = offset
        for e in entries {
            var r = Data()
            let attrs: UInt32 = e.isDir ? ((0o40755 << 16) | 0x10) : (0o100644 << 16)
            r.le32(0x02014b50); r.le16(0x0314); r.le16(20); r.le16(e.flags); r.le16(e.method)
            r.le16(e.time); r.le16(e.date); r.le32(e.crc); r.le32(e.csize); r.le32(e.usize)
            r.le16(UInt16(e.name.count)); r.le16(0); r.le16(0); r.le16(0); r.le16(0)
            r.le32(attrs); r.le32(e.offset)
            r.append(contentsOf: e.name)
            try write(r)
        }
        let cdSize = offset - cdStart
        var end = Data()
        end.le32(0x06054b50); end.le16(0); end.le16(0)
        end.le16(UInt16(entries.count)); end.le16(UInt16(entries.count))
        end.le32(UInt32(cdSize)); end.le32(UInt32(cdStart)); end.le16(0)
        try write(end)
        try handle.close()
    }

    func abort() { try? handle.close() }
}

// MARK: - Đọc/giải nén ZIP (cho tệp có mật khẩu)

struct ZipEntryInfo {
    var name: String
    var flags: UInt16
    var method: UInt16
    var time: UInt16
    var crc: UInt32
    var csize: UInt64
    var usize: UInt64
    var offset: UInt64
    var isEncrypted: Bool { flags & 1 != 0 }
}

enum MiniZipReader {
    private static func u16(_ b: [UInt8], _ o: Int) -> UInt16 { UInt16(b[o]) | (UInt16(b[o + 1]) << 8) }
    private static func u32(_ b: [UInt8], _ o: Int) -> UInt32 {
        UInt32(b[o]) | (UInt32(b[o + 1]) << 8) | (UInt32(b[o + 2]) << 16) | (UInt32(b[o + 3]) << 24)
    }

    static func entries(of url: URL) throws -> [ZipEntryInfo] {
        let h = try FileHandle(forReadingFrom: url)
        defer { try? h.close() }
        let end = try h.seekToEnd()
        let tailLen = min(end, 66_000)
        try h.seek(toOffset: end - tailLen)
        let tail = [UInt8](try h.read(upToCount: Int(tailLen)) ?? Data())
        guard tail.count >= 22 else { throw ZipError.corrupt("tệp quá nhỏ") }
        var eocd = -1
        var i = tail.count - 22
        while i >= 0 {
            if tail[i] == 0x50, tail[i + 1] == 0x4b, tail[i + 2] == 0x05, tail[i + 3] == 0x06 { eocd = i; break }
            i -= 1
        }
        guard eocd >= 0 else { throw ZipError.corrupt("không tìm thấy danh mục tệp") }
        let total = Int(u16(tail, eocd + 10))
        let cdSize = u32(tail, eocd + 12)
        let cdOffset = u32(tail, eocd + 16)
        if total == 0xFFFF || cdSize == 0xFFFF_FFFF || cdOffset == 0xFFFF_FFFF {
            throw ZipError.unsupported("Tệp ZIP64 có mật khẩu chưa được hỗ trợ.")
        }
        try h.seek(toOffset: UInt64(cdOffset))
        let cd = [UInt8](try h.read(upToCount: Int(cdSize)) ?? Data())
        var list: [ZipEntryInfo] = []
        var p = 0
        while p + 46 <= cd.count, u32(cd, p) == 0x02014b50 {
            let nameLen = Int(u16(cd, p + 28)), extraLen = Int(u16(cd, p + 30)), commentLen = Int(u16(cd, p + 32))
            guard p + 46 + nameLen <= cd.count else { break }
            let nameBytes = Array(cd[(p + 46)..<(p + 46 + nameLen)])
            let flags = u16(cd, p + 8)
            let name = String(decoding: nameBytes, as: UTF8.self)
            list.append(ZipEntryInfo(name: name, flags: flags, method: u16(cd, p + 10), time: u16(cd, p + 12),
                                     crc: u32(cd, p + 16), csize: UInt64(u32(cd, p + 20)), usize: UInt64(u32(cd, p + 24)),
                                     offset: UInt64(u32(cd, p + 42))))
            p += 46 + nameLen + extraLen + commentLen
        }
        return list
    }

    static func needsPassword(_ url: URL) -> Bool {
        guard let list = try? entries(of: url) else { return false }
        return list.contains { $0.isEncrypted }
    }

    static func extract(url: URL, to dest: URL, password: String?, progress: @escaping (Double) -> Void) throws {
        let fm = FileManager.default
        let list = try entries(of: url)
        let pw: [UInt8]? = (password?.isEmpty == false) ? Array(password!.utf8) : nil
        let src = try FileHandle(forReadingFrom: url)
        defer { try? src.close() }
        let totalBytes = max(1, list.reduce(UInt64(0)) { $0 + $1.csize })
        var doneBytes: UInt64 = 0

        for e in list {
            guard let target = safeExtractTarget(dest: dest, name: e.name) else { continue }   // chặn path traversal

            if e.name.hasSuffix("/") { try fm.createDirectory(at: target, withIntermediateDirectories: true); continue }
            if e.method == 99 { throw ZipError.unsupported("ZIP mã hóa AES chưa được hỗ trợ. Hãy dùng tệp ZIP mã hóa truyền thống.") }
            guard e.method == 0 || e.method == 8 else { throw ZipError.unsupported("Phương pháp nén của ZIP chưa được hỗ trợ.") }
            if e.isEncrypted && pw == nil { throw ZipError.passwordRequired }

            try fm.createDirectory(at: target.deletingLastPathComponent(), withIntermediateDirectories: true)
            guard fm.createFile(atPath: target.path, contents: nil) else { throw ZipError.corrupt("không ghi được tệp") }
            let out = try FileHandle(forWritingTo: target)
            var ok = false
            defer { try? out.close(); if !ok { try? fm.removeItem(at: target) } }

            // đọc tiêu đề cục bộ để biết vị trí dữ liệu
            try src.seek(toOffset: e.offset)
            let lh = [UInt8](try src.read(upToCount: 30) ?? Data())
            guard lh.count == 30, u32(lh, 0) == 0x04034b50 else { throw ZipError.corrupt("tiêu đề tệp không hợp lệ") }
            let skip = UInt64(u16(lh, 26)) + UInt64(u16(lh, 28))
            try src.seek(toOffset: e.offset + 30 + skip)

            var remaining = e.csize
            let cipher: ZipCrypto? = e.isEncrypted ? ZipCrypto(password: pw ?? []) : nil
            if let cipher {
                guard remaining >= 12 else { throw ZipError.corrupt("thiếu tiêu đề mã hóa") }
                let hdr = cipher.decrypt(try src.read(upToCount: 12) ?? Data())
                remaining -= 12
                let check = hdr.last ?? 0
                let c1 = UInt8(truncatingIfNeeded: e.crc >> 24), c2 = UInt8(truncatingIfNeeded: e.time >> 8)
                if check != c1 && check != c2 { throw ZipError.wrongPassword }
            }

            var crc = FileCrc()
            var written: UInt64 = 0
            let codec: StreamCodec? = e.method == 8 ? try StreamCodec(encode: false) : nil
            let emit: (Data) throws -> Void = { piece in
                crc.update(piece)
                written += UInt64(piece.count)
                try out.write(contentsOf: piece)
            }
            while remaining > 0 {
                let n = Int(min(remaining, 256 * 1024))
                guard var chunk = try src.read(upToCount: n), !chunk.isEmpty else { throw ZipError.corrupt("dữ liệu bị cắt ngắn") }
                remaining -= UInt64(chunk.count)
                doneBytes += UInt64(chunk.count)
                if let cipher { chunk = cipher.decrypt(chunk) }
                if let codec { try codec.process(chunk, isFinal: false, out: emit) } else { try emit(chunk) }
                progress(min(1, Double(doneBytes) / Double(totalBytes)))
            }
            if let codec { try codec.process(Data(), isFinal: true, out: emit) }

            if crc.checksum != e.crc || written != e.usize {
                throw e.isEncrypted ? ZipError.wrongPassword : ZipError.corrupt("sai tổng kiểm tra dữ liệu")
            }
            ok = true
        }
        progress(1)
    }
}
