import SwiftUI

/// Công cụ Nén và giải nén
struct ArchiveToolView: View {
    @State private var mode = 0
    // --- nén
    @State private var sources: [URL] = []
    @State private var archiveName = "Archive"
    @State private var usePassword = false
    @State private var password = ""
    @State private var confirm = ""
    @State private var saveDir: URL = Paths.files.appendingPathComponent("Archives", isDirectory: true)
    @State private var showSourcePicker = false
    @State private var showSaveFolder = false
    // --- giải nén
    @State private var archives: [URL] = []
    @State private var extractPassword = ""
    @State private var intoNewFolder = true
    @State private var extractDir: URL?
    @State private var showArchivePicker = false
    @State private var showExtractFolder = false
    // --- chung
    @State private var busy: String?
    @State private var fraction: Double?
    @State private var message: String?

    var body: some View {
        Form {
            Picker("Chế độ", selection: $mode) {
                Text("Nén").tag(0)
                Text("Giải nén").tag(1)
            }
            .pickerStyle(.segmented)
            .listRowBackground(Color.clear)

            if mode == 0 { compressSections } else { extractSections }
        }
        .navigationTitle("Nén và giải nén")
        .navigationBarTitleDisplayMode(.inline)
        .overlay { busyOverlay }
        .sheet(isPresented: $showSourcePicker) {
            LocalFilePickerSheet(rootTitle: "Chọn tệp để nén", icon: "checkmark", allowFolders: true,
                                 actionTitle: { "Chọn \($0) mục" }) { urls in sources = urls }
        }
        .sheet(isPresented: $showArchivePicker) {
            LocalFilePickerSheet(rootTitle: "Chọn tệp nén", icon: "checkmark", allowFolders: false,
                                 actionTitle: { "Chọn \($0) tệp" }) { urls in
                archives = urls.filter { ["zip", "7z"].contains($0.pathExtension.lowercased()) }
                if archives.count != urls.count { message = "Chỉ nhận tệp .zip và .7z." }
            }
        }
        .sheet(isPresented: $showSaveFolder) {
            FolderPicker(title: "Lưu tệp nén vào…", exclude: []) { saveDir = $0 }
        }
        .sheet(isPresented: $showExtractFolder) {
            FolderPicker(title: "Giải nén vào…", exclude: []) { extractDir = $0; intoNewFolder = false }
        }
        .alert("Thông báo", isPresented: Binding(get: { message != nil }, set: { if !$0 { message = nil } })) {
            Button("OK") { message = nil }
        } message: { Text(message ?? "") }
    }

    // MARK: Nén

    @ViewBuilder private var compressSections: some View {
        Section("Tệp cần nén") {
            Button { showSourcePicker = true } label: {
                Label(sources.isEmpty ? "Chọn tệp hoặc thư mục" : "Đã chọn \(sources.count) mục (bấm để đổi)",
                      systemImage: "plus.circle")
            }
            ForEach(sources.prefix(8), id: \.self) { u in
                Label(u.lastPathComponent, systemImage: "doc").lineLimit(1).font(.footnote)
            }
            if sources.count > 8 { Text("…và \(sources.count - 8) mục khác").font(.footnote).foregroundStyle(.secondary) }
        }
        Section("Tùy chọn") {
            TextField("Tên tệp nén", text: $archiveName)
            Toggle("Đặt mật khẩu", isOn: $usePassword)
            if usePassword {
                SecureField("Mật khẩu", text: $password)
                SecureField("Nhập lại mật khẩu", text: $confirm)
                Text("Dùng mã hóa ZIP truyền thống (tương thích 7-Zip, WinRAR, Keka, Windows). Độ bảo mật ở mức cơ bản, không nên dùng cho dữ liệu cực kỳ nhạy cảm. Ứng dụng Tệp của iPhone không mở được ZIP có mật khẩu, hãy dùng chính Jinn Files để giải nén.")
                    .font(.footnote).foregroundStyle(.secondary)
            }
            Button { showSaveFolder = true } label: {
                LabeledContent("Lưu vào") { Text("Files/" + FileOps.relative(saveDir)).foregroundStyle(.secondary).lineLimit(1) }
            }
            .buttonStyle(.plain)
        }
        Section {
            Button { compress() } label: {
                Label("Nén thành ZIP", systemImage: "doc.zipper").frame(maxWidth: .infinity)
            }
            .glassButtonStyle(prominent: true).controlSize(.large)
            .disabled(sources.isEmpty)
        } footer: {
            Text("Nén hỗ trợ định dạng ZIP. Định dạng 7Z chỉ hỗ trợ giải nén.")
        }
    }

    // MARK: Giải nén

    @ViewBuilder private var extractSections: some View {
        Section("Tệp nén") {
            Button { showArchivePicker = true } label: {
                Label(archives.isEmpty ? "Chọn tệp ZIP hoặc 7Z" : "Đã chọn \(archives.count) tệp (bấm để đổi)",
                      systemImage: "plus.circle")
            }
            ForEach(archives, id: \.self) { u in
                HStack {
                    Image(systemName: "doc.zipper")
                    Text(u.lastPathComponent).lineLimit(1)
                    Spacer()
                    Text(Fmt.size(FileOps.size(of: u))).font(.caption).foregroundStyle(.secondary)
                }.font(.footnote)
            }
        }
        Section("Tùy chọn") {
            Toggle("Giải nén vào thư mục mới cùng tên", isOn: $intoNewFolder)
            if !intoNewFolder {
                Button { showExtractFolder = true } label: {
                    LabeledContent("Giải nén vào") {
                        Text(extractDir.map { "Files/" + FileOps.relative($0) } ?? "Chọn thư mục…").foregroundStyle(.secondary).lineLimit(1)
                    }
                }
                .buttonStyle(.plain)
            }
            SecureField("Mật khẩu (nếu tệp có mật khẩu)", text: $extractPassword)
        }
        Section {
            Button { extract() } label: {
                Label("Giải nén", systemImage: "arrow.down.doc").frame(maxWidth: .infinity)
            }
            .glassButtonStyle(prominent: true).controlSize(.large)
            .disabled(archives.isEmpty || (!intoNewFolder && extractDir == nil))
        } footer: {
            Text("Hỗ trợ ZIP (kể cả có mật khẩu) và 7Z (chưa hỗ trợ 7Z có mật khẩu). Tệp trùng tên sẽ được đổi tên, không bị ghi đè.")
        }
    }

    // MARK: Thực thi

    @ViewBuilder private var busyOverlay: some View {
        if let busy {
            ZStack {
                Color.black.opacity(0.3).ignoresSafeArea()
                VStack(spacing: 12) {
                    if let fraction { ProgressView(value: fraction) } else { ProgressView() }
                    Text(busy).font(.footnote)
                }
                .padding(20).frame(width: 250).glassSurface(cornerRadius: 22)
            }
        }
    }

    private func compress() {
        if usePassword {
            guard !password.isEmpty else { message = "Hãy nhập mật khẩu."; return }
            guard password == confirm else { message = "Hai mật khẩu không khớp."; return }
        }
        let srcs = sources, dir = saveDir, name = archiveName, pw = usePassword ? password : nil
        run("Đang nén…") { progress in
            try FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
            var need: Int64 = 0
            for u in srcs { need += FileOps.size(of: u) }
            try FileOps.checkSpace(needed: need)
            try ArchiveOps.zip(srcs, in: dir, name: name, password: pw, progress: progress)
            return "Đã nén xong vào Files/\(FileOps.relative(dir))."
        }
    }

    private func extract() {
        let list = archives, pw = extractPassword
        let newFolder = intoNewFolder, chosen = extractDir
        run("Đang giải nén…") { progress in
            var ok = 0
            var failed: [String] = []
            for (i, a) in list.enumerated() {
                do {
                    let here = a.deletingLastPathComponent()
                    let mode: ExtractMode = newFolder ? .newFolder : .into(chosen ?? here)
                    try FileOps.checkSpace(needed: FileOps.size(of: a) * 3)
                    try ArchiveOps.extract(archive: a, mode: mode, currentDir: here, password: pw) { f in
                        progress((Double(i) + f) / Double(list.count))
                    }
                    ok += 1
                } catch {
                    failed.append("• \(a.lastPathComponent): \(error.localizedDescription)")
                }
            }
            var m = "Đã giải nén \(ok)/\(list.count) tệp."
            if !failed.isEmpty { m += "\nLỗi:\n" + failed.prefix(4).joined(separator: "\n") }
            return m
        }
    }

    private func run(_ title: String, _ work: @escaping @Sendable (@escaping @Sendable (Double) -> Void) throws -> String) {
        busy = title
        fraction = nil
        let cb: @Sendable (Double) -> Void = { f in Task { @MainActor in fraction = f } }
        Task {
            do { message = try await Task.detached { try work(cb) }.value }
            catch { message = error.localizedDescription }
            busy = nil
        }
    }
}
