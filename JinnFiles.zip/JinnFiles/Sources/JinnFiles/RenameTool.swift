import SwiftUI

/// Công cụ Đổi tên hàng loạt: tiền tố, hậu tố, tìm và thay, đánh số tự động
struct BatchRenameView: View {
    @State private var items: [URL] = []
    @State private var showPicker = false
    @State private var sortByDate = false

    @State private var useNewBase = false
    @State private var baseName = ""
    @State private var find = ""
    @State private var replace = ""
    @State private var prefix = ""
    @State private var suffix = ""
    @State private var numbering = false
    @State private var start = 1
    @State private var step = 1
    @State private var digits = 2
    @State private var numberAtEnd = true
    @State private var separator = " "

    @State private var busy = false
    @State private var message: String?

    private struct Row: Identifiable {
        let id: URL
        let oldName: String
        let newName: String
        let problem: String?
    }

    private var ordered: [URL] {
        if sortByDate {
            return items.sorted {
                let a = (try? $0.resourceValues(forKeys: [.contentModificationDateKey]))?.contentModificationDate ?? .distantPast
                let b = (try? $1.resourceValues(forKeys: [.contentModificationDateKey]))?.contentModificationDate ?? .distantPast
                return a < b
            }
        }
        return items.sorted { $0.lastPathComponent.localizedStandardCompare($1.lastPathComponent) == .orderedAscending }
    }

    private func newName(_ u: URL, index: Int) -> String {
        let isDir = (try? u.resourceValues(forKeys: [.isDirectoryKey]))?.isDirectory ?? false
        let ext = isDir ? "" : u.pathExtension
        var base = isDir ? u.lastPathComponent : u.deletingPathExtension().lastPathComponent
        if useNewBase && !baseName.isEmpty { base = baseName }
        if !find.isEmpty { base = base.replacingOccurrences(of: find, with: replace) }
        base = prefix + base + suffix
        if numbering {
            let raw = String(start + index * step)
            let n = String(repeating: "0", count: max(0, digits - raw.count)) + raw
            base = numberAtEnd ? base + separator + n : n + separator + base
        }
        return ext.isEmpty ? base : base + "." + ext
    }

    private var rows: [Row] {
        let list = ordered
        let names = list.enumerated().map { newName($1, index: $0) }
        var counts: [String: Int] = [:]
        for (u, n) in zip(list, names) {
            counts[u.deletingLastPathComponent().path + "/" + n.lowercased(), default: 0] += 1
        }
        let selected = Set(list.map { $0.standardizedFileURL.path.lowercased() })
        return zip(list, names).map { u, n in
            var problem: String?
            let dir = u.deletingLastPathComponent()
            if FileOps.validName(n) == nil { problem = "Tên không hợp lệ" }
            else if counts[dir.path + "/" + n.lowercased()] ?? 0 > 1 { problem = "Trùng tên với mục khác trong danh sách" }
            else if n != u.lastPathComponent {
                let target = dir.appendingPathComponent(n)
                if FileManager.default.fileExists(atPath: target.path), !selected.contains(target.standardizedFileURL.path.lowercased()) {
                    problem = "Đã có tệp trùng tên trong thư mục"
                }
            }
            return Row(id: u, oldName: u.lastPathComponent, newName: n, problem: problem)
        }
    }

    var body: some View {
        let preview = rows
        let hasProblem = preview.contains { $0.problem != nil }
        let changes = preview.filter { $0.oldName != $0.newName }.count
        Form {
            Section("Tệp cần đổi tên") {
                Button { showPicker = true } label: {
                    Label(items.isEmpty ? "Chọn tệp hoặc thư mục" : "Đã chọn \(items.count) mục (bấm để đổi)", systemImage: "plus.circle")
                }
                Picker("Thứ tự", selection: $sortByDate) {
                    Text("Theo tên").tag(false)
                    Text("Theo ngày sửa").tag(true)
                }
                .pickerStyle(.segmented)
            }
            Section("Tên") {
                Toggle("Đặt tên mới hoàn toàn", isOn: $useNewBase)
                if useNewBase { TextField("Tên mới (đuôi tệp được giữ nguyên)", text: $baseName) }
                TextField("Tìm", text: $find)
                TextField("Thay bằng", text: $replace)
                TextField("Tiền tố", text: $prefix)
                TextField("Hậu tố (trước đuôi tệp)", text: $suffix)
            }
            Section("Đánh số tự động") {
                Toggle("Thêm số thứ tự", isOn: $numbering)
                if numbering {
                    Stepper("Bắt đầu từ: \(start)", value: $start, in: 0...99999)
                    Stepper("Bước nhảy: \(step)", value: $step, in: 1...100)
                    Stepper("Số chữ số: \(digits)", value: $digits, in: 1...6)
                    Picker("Vị trí số", selection: $numberAtEnd) {
                        Text("Cuối tên").tag(true)
                        Text("Đầu tên").tag(false)
                    }
                    .pickerStyle(.segmented)
                    Picker("Ký tự ngăn cách", selection: $separator) {
                        Text("Dấu cách").tag(" ")
                        Text("_").tag("_")
                        Text("-").tag("-")
                        Text("Không").tag("")
                    }
                    .pickerStyle(.segmented)
                }
            }
            if !items.isEmpty {
                Section("Xem trước (\(changes) mục sẽ đổi)") {
                    ForEach(preview.prefix(100)) { r in
                        VStack(alignment: .leading, spacing: 2) {
                            Text(r.oldName).font(.caption).foregroundStyle(.secondary).lineLimit(1)
                            HStack(spacing: 4) {
                                Image(systemName: "arrow.right").font(.caption2)
                                Text(r.newName).lineLimit(1).foregroundStyle(r.problem == nil ? Color.primary : Color.red)
                            }
                            if let p = r.problem { Text(p).font(.caption2).foregroundStyle(.red) }
                        }
                    }
                    if preview.count > 100 { Text("…và \(preview.count - 100) mục khác").font(.footnote).foregroundStyle(.secondary) }
                }
            }
        }
        .navigationTitle("Đổi tên hàng loạt")
        .navigationBarTitleDisplayMode(.inline)
        .safeAreaInset(edge: .bottom) {
            Button { apply(preview) } label: {
                HStack {
                    if busy { ProgressView() }
                    Label(changes == 0 ? "Chưa có thay đổi" : "Đổi tên \(changes) mục", systemImage: "pencil")
                }
                .frame(maxWidth: .infinity)
            }
            .glassButtonStyle(prominent: true).controlSize(.large)
            .disabled(items.isEmpty || changes == 0 || hasProblem || busy)
            .padding()
        }
        .sheet(isPresented: $showPicker) {
            LocalFilePickerSheet(rootTitle: "Chọn tệp để đổi tên", icon: "checkmark", allowFolders: true,
                                 actionTitle: { "Chọn \($0) mục" }) { urls in items = urls }
        }
        .alert("Thông báo", isPresented: Binding(get: { message != nil }, set: { if !$0 { message = nil } })) {
            Button("OK") { message = nil }
        } message: { Text(message ?? "") }
    }

    /// Đổi tên theo hai bước (qua tên tạm) để tránh va chạm khi hoán đổi; nếu lỗi sẽ hoàn tác toàn bộ.
    private func apply(_ plan: [Row]) {
        let jobs = plan.filter { $0.oldName != $0.newName }.map { ($0.id, $0.newName) }
        busy = true
        Task {
            let result: String = await Task.detached {
                let fm = FileManager.default
                var stage: [(tmp: URL, original: URL, target: URL)] = []
                var moved = 0
                do {
                    for (url, name) in jobs {
                        let dir = url.deletingLastPathComponent()
                        let tmp = dir.appendingPathComponent(".jinn-rn-\(UUID().uuidString)")
                        try fm.moveItem(at: url, to: tmp)
                        stage.append((tmp, url, dir.appendingPathComponent(name)))
                    }
                    for s in stage {
                        try fm.moveItem(at: s.tmp, to: s.target)
                        moved += 1
                    }
                    return "Đã đổi tên \(moved) mục."
                } catch {
                    // hoàn tác
                    for (i, s) in stage.enumerated() {
                        if i < moved { try? fm.moveItem(at: s.target, to: s.original) }
                        else { try? fm.moveItem(at: s.tmp, to: s.original) }
                    }
                    return "Lỗi: \(error.localizedDescription). Mọi thay đổi đã được hoàn tác."
                }
            }.value
            busy = false
            message = result
            if result.hasPrefix("Đã đổi tên") { items = [] }
        }
    }
}
