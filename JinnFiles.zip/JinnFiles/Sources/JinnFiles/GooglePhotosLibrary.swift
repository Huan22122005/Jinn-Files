import SwiftUI
import AVKit

struct GPItem: Identifiable, Hashable {
    let id: String
    let filename: String
    let baseUrl: String
    let mime: String
    let created: Date
    let productUrl: String
    let isVideo: Bool
    var thumb: URL? { URL(string: baseUrl + "=w400-h400-c") }
}

struct GPAlbum: Identifiable, Hashable {
    let id: String
    let title: String
}

/// Đọc danh sách ảnh/video mà ứng dụng này đã tải lên Google Photos
/// (Google chỉ cho phép ứng dụng xem các mục do chính nó tạo).
@MainActor
final class GooglePhotosLibrary: ObservableObject {
    @Published private(set) var items: [GPItem] = []
    @Published private(set) var loading = false
    @Published private(set) var finished = false
    @Published var error: String?
    @Published private(set) var albums: [GPAlbum] = []
    @Published private(set) var currentAlbum: GPAlbum?
    private var nextToken: String?

    private struct LibError: LocalizedError { let code: Int; let message: String
        var errorDescription: String? { message } }

    func reload() async {
        items = []; nextToken = nil; finished = false; error = nil
        await loadMore()
    }

    func loadMore() async {
        guard !loading, !finished else { return }
        loading = true
        defer { loading = false }
        do {
            let data: Data
            if let album = currentAlbum {
                var body: [String: Any] = ["albumId": album.id, "pageSize": 100]
                if let t = nextToken { body["pageToken"] = t }
                data = try await send(URL(string: "https://photoslibrary.googleapis.com/v1/mediaItems:search")!, method: "POST", json: body)
            } else {
                var c = URLComponents(string: "https://photoslibrary.googleapis.com/v1/mediaItems")!
                var q = [URLQueryItem(name: "pageSize", value: "100")]
                if let t = nextToken { q.append(URLQueryItem(name: "pageToken", value: t)) }
                c.queryItems = q
                data = try await send(c.url!)
            }
            let o = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any] ?? [:]
            let new = (o["mediaItems"] as? [[String: Any]] ?? []).compactMap(Self.parse)
            let known = Set(items.map(\.id))
            items = (items + new.filter { !known.contains($0.id) }).sorted { $0.created > $1.created }
            nextToken = o["nextPageToken"] as? String
            if nextToken == nil { finished = true }
        } catch let e as LibError where e.code == 403 {
            error = "Chưa được cấp quyền xem ảnh đã tải lên. Hãy đăng nhập lại để cấp quyền."
            finished = true
        } catch {
            self.error = error.localizedDescription
            finished = true
        }
    }

    /// baseUrl chỉ có hiệu lực khoảng 60 phút, nên lấy lại bản mới trước khi xem hoặc tải
    func fresh(_ id: String) async -> GPItem? {
        guard let u = URL(string: "https://photoslibrary.googleapis.com/v1/mediaItems/\(id)"),
              let d = try? await send(u),
              let o = (try? JSONSerialization.jsonObject(with: d)) as? [String: Any] else { return nil }
        return Self.parse(o)
    }

    func download(_ item: GPItem) async throws -> URL {
        let f = await fresh(item.id) ?? item
        guard let url = URL(string: f.baseUrl + (item.isVideo ? "=dv" : "=d")) else { throw AppError("Địa chỉ tải về không hợp lệ.") }
        let (tmp, resp) = try await URLSession.shared.download(from: url)
        let code = (resp as? HTTPURLResponse)?.statusCode ?? 0
        guard code == 200 else {
            try? FileManager.default.removeItem(at: tmp)
            throw AppError(item.isVideo && code == 404 ? "Video đang được Google xử lý, thử lại sau ít phút." : "Tải về thất bại (mã \(code)).")
        }
        try FileSpace.check(for: tmp)
        let dir = Paths.category(for: item.isVideo ? .video : .image)
        try FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        let dest = FileOps.uniqueURL(dir: dir, name: item.filename)
        try FileManager.default.moveItem(at: tmp, to: dest)
        return dest
    }

    // MARK: Hỗ trợ

    private func send(_ url: URL, method: String = "GET", json: [String: Any]? = nil) async throws -> Data {
        for attempt in 0..<2 {
            let token = try await GoogleAuth.shared.accessToken(forceRefresh: attempt == 1)
            var r = URLRequest(url: url)
            r.httpMethod = method
            r.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
            if let json {
                r.setValue("application/json", forHTTPHeaderField: "Content-Type")
                r.httpBody = try JSONSerialization.data(withJSONObject: json)
            }
            let (d, resp) = try await URLSession.shared.data(for: r)
            let code = (resp as? HTTPURLResponse)?.statusCode ?? 0
            if code == 401 && attempt == 0 { continue }
            guard code == 200 else {
                let o = (try? JSONSerialization.jsonObject(with: d)) as? [String: Any]
                let m = ((o?["error"] as? [String: Any])?["message"] as? String) ?? "Mã lỗi \(code)"
                throw LibError(code: code, message: "Google Photos: \(m)")
            }
            return d
        }
        throw AppError("Phiên đăng nhập bị từ chối, hãy đăng nhập lại.")
    }

    // MARK: Album

    func loadAlbums() async {
        var all: [GPAlbum] = []
        var token: String?
        do {
            repeat {
                var c = URLComponents(string: "https://photoslibrary.googleapis.com/v1/albums")!
                var q = [URLQueryItem(name: "pageSize", value: "50")]
                if let token { q.append(URLQueryItem(name: "pageToken", value: token)) }
                c.queryItems = q
                let d = try await send(c.url!)
                let o = (try? JSONSerialization.jsonObject(with: d)) as? [String: Any] ?? [:]
                for a in (o["albums"] as? [[String: Any]] ?? []) {
                    if let id = a["id"] as? String { all.append(GPAlbum(id: id, title: a["title"] as? String ?? "Album")) }
                }
                token = o["nextPageToken"] as? String
            } while token != nil
            albums = all.sorted { $0.title.localizedStandardCompare($1.title) == .orderedAscending }
        } catch {
            // Không có quyền đọc hoặc mất mạng: giữ danh sách cũ, lỗi chi tiết hiện ở màn hình ảnh
        }
    }

    func createAlbum(_ title: String) async throws -> GPAlbum {
        let name = title.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !name.isEmpty else { throw AppError("Tên album không được để trống.") }
        let d = try await send(URL(string: "https://photoslibrary.googleapis.com/v1/albums")!,
                               method: "POST", json: ["album": ["title": name]])
        let o = (try? JSONSerialization.jsonObject(with: d)) as? [String: Any] ?? [:]
        guard let id = o["id"] as? String else { throw AppError("Không tạo được album.") }
        let a = GPAlbum(id: id, title: o["title"] as? String ?? name)
        albums = (albums + [a]).sorted { $0.title.localizedStandardCompare($1.title) == .orderedAscending }
        return a
    }

    func select(_ album: GPAlbum?) async {
        currentAlbum = album
        await reload()
    }

    // MARK: Phát video: tải về tệp tạm rồi phát, ổn định hơn phát trực tiếp từ địa chỉ của Google

    func videoFile(_ item: GPItem) async throws -> URL {
        let safe = String(item.id.filter { $0.isLetter || $0.isNumber }.prefix(24))
        let ext = (item.filename as NSString).pathExtension
        let dest = FileManager.default.temporaryDirectory
            .appendingPathComponent("gpv-\(safe).\(ext.isEmpty ? "mp4" : ext)")
        if FileManager.default.fileExists(atPath: dest.path) { return dest }
        let f = await fresh(item.id) ?? item
        guard let url = URL(string: f.baseUrl + "=dv") else { throw AppError("Địa chỉ video không hợp lệ.") }
        let (tmp, resp) = try await URLSession.shared.download(from: url)
        let code = (resp as? HTTPURLResponse)?.statusCode ?? 0
        guard code == 200 else {
            try? FileManager.default.removeItem(at: tmp)
            throw AppError(code == 404 ? "Google vẫn đang xử lý video này, hãy thử lại sau ít phút." : "Không tải được video (mã \(code)).")
        }
        try FileManager.default.moveItem(at: tmp, to: dest)
        return dest
    }

    private static func parse(_ o: [String: Any]) -> GPItem? {
        guard let id = o["id"] as? String, let base = o["baseUrl"] as? String else { return nil }
        let meta = o["mediaMetadata"] as? [String: Any]
        var date = Date()
        if let s = meta?["creationTime"] as? String {
            let f1 = ISO8601DateFormatter()
            let f2 = ISO8601DateFormatter(); f2.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
            date = f1.date(from: s) ?? f2.date(from: s) ?? date
        }
        return GPItem(id: id, filename: o["filename"] as? String ?? id, baseUrl: base,
                      mime: o["mimeType"] as? String ?? "", created: date,
                      productUrl: o["productUrl"] as? String ?? "",
                      isVideo: meta?["video"] != nil)
    }
}

enum FileSpace {
    static func check(for url: URL) throws {
        // Tệp đã nằm trên máy; chỉ cần chắc chắn không còn trống bộ nhớ quá thấp khi lưu thêm
        try FileOps.checkSpace(needed: 0)
    }
}

// MARK: - Giao diện

struct GPViewerState: Identifiable { let id = UUID(); let index: Int }

struct GooglePhotosBrowser: View {
    @EnvironmentObject private var auth: GoogleAuth
    @StateObject private var lib = GooglePhotosLibrary()
    @State private var viewer: GPViewerState?
    @State private var selecting = false
    @State private var selection = Set<String>()
    @State private var message: String?
    @State private var downloading = false
    @State private var showNewAlbum = false
    @State private var newAlbumName = ""

    var body: some View {
        Group {
            if !auth.isSignedIn {
                ContentUnavailableView("Chưa đăng nhập", systemImage: "person.crop.circle.badge.exclamationmark",
                                       description: Text("Đăng nhập Google ở tab Tài khoản để xem ảnh đã tải lên."))
            } else if !auth.canReadLibrary {
                VStack(spacing: 14) {
                    ContentUnavailableView("Cần cấp thêm quyền", systemImage: "lock.open",
                                           description: Text("Để xem ảnh đã tải lên, hãy đăng nhập lại và đồng ý cấp quyền xem ảnh do Jinn Files tạo."))
                    Button("Đăng nhập lại") { Task { await auth.signIn() } }
                        .glassButtonStyle(prominent: true).controlSize(.large)
                }
            } else {
                content
            }
        }
        .navigationTitle("Google Photos")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                if auth.isSignedIn && auth.canReadLibrary {
                    if selecting {
                        Button("Xong") { selecting = false; selection.removeAll() }
                    } else {
                        Menu {
                            Button { selecting = true } label: { Label("Chọn nhiều", systemImage: "checkmark.circle") }
                            Button { newAlbumName = ""; showNewAlbum = true } label: { Label("Tạo album mới", systemImage: "rectangle.stack.badge.plus") }
                            Button { Task { await lib.reload() } } label: { Label("Làm mới", systemImage: "arrow.clockwise") }
                        } label: { Image(systemName: "ellipsis.circle") }
                    }
                }
            }
            ToolbarItem(placement: .topBarLeading) {
                if selecting {
                    Button(selection.count == lib.items.count ? "Bỏ chọn" : "Chọn tất cả") {
                        if selection.count == lib.items.count { selection.removeAll() }
                        else { selection = Set(lib.items.map(\.id)) }
                    }
                }
            }
        }
        .task {
            if auth.isSignedIn && auth.canReadLibrary {
                await lib.loadAlbums()
                if lib.items.isEmpty && !lib.finished { await lib.reload() }
            }
        }
        .alert("Album mới", isPresented: $showNewAlbum) {
            TextField("Tên album", text: $newAlbumName)
            Button("Hủy", role: .cancel) {}
            Button("Tạo") {
                let name = newAlbumName
                Task {
                    do { let a = try await lib.createAlbum(name); await lib.select(a) }
                    catch { message = error.localizedDescription }
                }
            }
        }
        .fullScreenCover(item: $viewer) { v in
            GPViewer(items: lib.items, start: v.index, lib: lib, onClose: { viewer = nil })
        }
        .alert("Thông báo", isPresented: Binding(get: { message != nil }, set: { if !$0 { message = nil } })) {
            Button("OK") { message = nil }
        } message: { Text(message ?? "") }
        .alert("Lỗi", isPresented: Binding(get: { lib.error != nil }, set: { if !$0 { lib.error = nil } })) {
            Button("OK") { lib.error = nil }
        } message: { Text(lib.error ?? "") }
        .safeAreaInset(edge: .bottom) {
            if selecting && !selection.isEmpty {
                Button { downloadSelected() } label: {
                    HStack {
                        if downloading { ProgressView() }
                        Label("Tải về \(selection.count) mục", systemImage: "arrow.down.circle")
                    }.frame(maxWidth: .infinity)
                }
                .glassButtonStyle(prominent: true).controlSize(.large).disabled(downloading).padding()
            }
        }
    }

    private var content: some View {
        ScrollView {
            VStack(spacing: 10) {
                Text("Chỉ hiện ảnh, video và album do Jinn Files tạo (Google không cho ứng dụng xem toàn bộ thư viện). Google cũng không cho ứng dụng bên ngoài xóa ảnh hay album, hãy xóa trong ứng dụng Google Photos.")
                    .font(.footnote).foregroundStyle(.secondary)
                    .padding(12).frame(maxWidth: .infinity, alignment: .leading).glassSurface(cornerRadius: 18)
                    .padding(.horizontal, 8)

                albumChips

                if lib.items.isEmpty && !lib.loading {
                    ContentUnavailableView("Chưa có ảnh nào", systemImage: "photo",
                                           description: Text("Ảnh tải lên từ Jinn Files sẽ hiện ở đây, có thể mất vài giây."))
                        .padding(.top, 30)
                }
                LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 3), count: 3), spacing: 3) {
                    ForEach(Array(lib.items.enumerated()), id: \.element.id) { i, item in
                        cell(item, index: i)
                            .onAppear { if i == lib.items.count - 6 { Task { await lib.loadMore() } } }
                    }
                }
                .padding(.horizontal, 3)
                if lib.loading { ProgressView().padding() }
            }
        }
        .refreshable { await lib.reload() }
    }

    private var albumChips: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                chip("Tất cả", selected: lib.currentAlbum == nil) { Task { await lib.select(nil) } }
                ForEach(lib.albums) { a in
                    chip(a.title, selected: lib.currentAlbum == a) { Task { await lib.select(a) } }
                }
                Button { newAlbumName = ""; showNewAlbum = true } label: {
                    Label("Album mới", systemImage: "plus").font(.subheadline)
                        .padding(.horizontal, 14).padding(.vertical, 8)
                        .glassSurface(cornerRadius: 18, interactive: true)
                }
                .buttonStyle(.plain)
            }
            .padding(.horizontal, 8)
        }
    }

    private func chip(_ title: String, selected: Bool, _ action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Text(title).font(.subheadline).lineLimit(1)
                .padding(.horizontal, 14).padding(.vertical, 8)
                .foregroundStyle(selected ? Color.white : Color.primary)
                .glassSurface(cornerRadius: 18, tint: selected ? .blue : nil, interactive: true)
        }
        .buttonStyle(.plain)
    }

    private func cell(_ item: GPItem, index: Int) -> some View {
        Button {
            if selecting {
                if selection.contains(item.id) { selection.remove(item.id) } else { selection.insert(item.id) }
            } else { viewer = GPViewerState(index: index) }
        } label: {
            Color.clear.aspectRatio(1, contentMode: .fit)
                .overlay {
                    AsyncImage(url: item.thumb) { phase in
                        switch phase {
                        case .success(let img): img.resizable().scaledToFill()
                        case .failure: Image(systemName: "photo").foregroundStyle(.secondary)
                        default: ProgressView()
                        }
                    }
                }
                .clipped()
                .overlay(alignment: .bottomLeading) {
                    if item.isVideo { Image(systemName: "video.fill").font(.caption2).foregroundStyle(.white).shadow(radius: 2).padding(5) }
                }
                .overlay(alignment: .topTrailing) {
                    if selecting {
                        Image(systemName: selection.contains(item.id) ? "checkmark.circle.fill" : "circle")
                            .foregroundStyle(selection.contains(item.id) ? Color.accentColor : .white)
                            .shadow(radius: 2).padding(6)
                    }
                }
        }
        .buttonStyle(.plain)
    }

    private func downloadSelected() {
        let chosen = lib.items.filter { selection.contains($0.id) }
        downloading = true
        Task {
            var ok = 0
            var failed: [String] = []
            for it in chosen {
                do { _ = try await lib.download(it); ok += 1 }
                catch { failed.append("• \(it.filename): \(error.localizedDescription)") }
            }
            downloading = false
            selecting = false; selection.removeAll()
            var m = "Đã tải về \(ok)/\(chosen.count) mục vào Jinn Files (thư mục Images/Videos)."
            if !failed.isEmpty { m += "\nLỗi:\n" + failed.prefix(4).joined(separator: "\n") }
            message = m
        }
    }
}

struct GPViewer: View {
    let items: [GPItem]
    @State var index: Int
    let lib: GooglePhotosLibrary
    let onClose: () -> Void
    @State private var message: String?

    init(items: [GPItem], start: Int, lib: GooglePhotosLibrary, onClose: @escaping () -> Void) {
        self.items = items; self._index = State(initialValue: start); self.lib = lib; self.onClose = onClose
    }

    var body: some View {
        ZStack(alignment: .top) {
            Color.black.ignoresSafeArea()
            TabView(selection: $index) {
                ForEach(Array(items.enumerated()), id: \.offset) { i, it in
                    GPPage(item: it, lib: lib).tag(i)
                }
            }
            .tabViewStyle(.page(indexDisplayMode: .never))
            .ignoresSafeArea()

            HStack {
                Button { onClose() } label: {
                    Image(systemName: "xmark").font(.headline).foregroundStyle(.white).glassCircle(size: 40)
                }
                Spacer()
                Text("\(index + 1)/\(items.count)").foregroundStyle(.white).font(.footnote)
                Spacer()
                Menu {
                    Button {
                        guard items.indices.contains(index) else { return }
                        let it = items[index]
                        Task {
                            do { let u = try await lib.download(it); message = "Đã tải về: \(u.lastPathComponent)" }
                            catch { message = error.localizedDescription }
                        }
                    } label: { Label("Tải về Jinn Files", systemImage: "arrow.down.circle") }
                    if items.indices.contains(index), let u = URL(string: items[index].productUrl) {
                        Link(destination: u) { Label("Mở trong Google Photos", systemImage: "arrow.up.right.square") }
                    }
                } label: {
                    Image(systemName: "ellipsis").font(.headline).foregroundStyle(.white).glassCircle(size: 40)
                }
            }
            .padding()
        }
        .alert("Thông báo", isPresented: Binding(get: { message != nil }, set: { if !$0 { message = nil } })) {
            Button("OK") { message = nil }
        } message: { Text(message ?? "") }
    }
}

struct GPPage: View {
    let item: GPItem
    let lib: GooglePhotosLibrary
    @State private var fresh: GPItem?
    @State private var player: AVPlayer?
    @State private var errorText: String?
    @State private var loadingVideo = false

    var body: some View {
        ZStack {
            if item.isVideo {
                if let player {
                    VideoPlayer(player: player)
                } else if let errorText {
                    VStack(spacing: 14) {
                        Image(systemName: "exclamationmark.triangle").font(.largeTitle).foregroundStyle(.white)
                        Text(errorText).foregroundStyle(.white).multilineTextAlignment(.center).padding(.horizontal, 30)
                        Button("Thử lại") { Task { await loadVideo() } }.glassButtonStyle(prominent: true)
                    }
                } else {
                    VStack(spacing: 10) {
                        ProgressView().tint(.white)
                        Text("Đang tải video…").font(.footnote).foregroundStyle(.white.opacity(0.8))
                    }
                }
            } else if let f = fresh {
                AsyncImage(url: URL(string: f.baseUrl + "=w2048-h2048")) { phase in
                    switch phase {
                    case .success(let img): img.resizable().scaledToFit()
                    case .failure: Image(systemName: "exclamationmark.triangle").foregroundStyle(.white)
                    default: ProgressView().tint(.white)
                    }
                }
            } else {
                ProgressView().tint(.white)
            }
        }
        .task {
            if item.isVideo { await loadVideo() }
            else { fresh = await lib.fresh(item.id) ?? item }
        }
        .onDisappear { player?.pause() }
    }

    private func loadVideo() async {
        guard !loadingVideo else { return }
        loadingVideo = true
        errorText = nil
        defer { loadingVideo = false }
        do {
            let url = try await lib.videoFile(item)
            let p = AVPlayer(url: url)
            player = p
            p.play()
        } catch {
            errorText = error.localizedDescription
        }
    }
}
