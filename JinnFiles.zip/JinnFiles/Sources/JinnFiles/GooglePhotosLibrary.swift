import SwiftUI
import AVKit

struct GPItem: Identifiable, Hashable {
    let id: String
    let filename: String
    let baseUrl: String
    let mime: String
    let created: Date
    let productUrl: String
    let isVideo: Bool
    var thumb: URL? { URL(string: baseUrl + "=w400-h400-c") }
}

/// Đọc danh sách ảnh/video mà ứng dụng này đã tải lên Google Photos
/// (Google chỉ cho phép ứng dụng xem các mục do chính nó tạo).
@MainActor
final class GooglePhotosLibrary: ObservableObject {
    @Published private(set) var items: [GPItem] = []
    @Published private(set) var loading = false
    @Published private(set) var finished = false
    @Published var error: String?
    private var nextToken: String?

    private struct LibError: LocalizedError { let code: Int; let message: String
        var errorDescription: String? { message } }

    func reload() async {
        items = []; nextToken = nil; finished = false; error = nil
        await loadMore()
    }

    func loadMore() async {
        guard !loading, !finished else { return }
        loading = true
        defer { loading = false }
        do {
            var c = URLComponents(string: "https://photoslibrary.googleapis.com/v1/mediaItems")!
            var q = [URLQueryItem(name: "pageSize", value: "100")]
            if let t = nextToken { q.append(URLQueryItem(name: "pageToken", value: t)) }
            c.queryItems = q
            let data = try await get(c.url!)
            let o = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any] ?? [:]
            let new = (o["mediaItems"] as? [[String: Any]] ?? []).compactMap(Self.parse)
            let known = Set(items.map(\.id))
            items = (items + new.filter { !known.contains($0.id) }).sorted { $0.created > $1.created }
            nextToken = o["nextPageToken"] as? String
            if nextToken == nil { finished = true }
        } catch let e as LibError where e.code == 403 {
            error = "Chưa được cấp quyền xem ảnh đã tải lên. Hãy đăng nhập lại để cấp quyền."
            finished = true
        } catch {
            self.error = error.localizedDescription
            finished = true
        }
    }

    /// baseUrl chỉ có hiệu lực khoảng 60 phút, nên lấy lại bản mới trước khi xem hoặc tải
    func fresh(_ id: String) async -> GPItem? {
        guard let u = URL(string: "https://photoslibrary.googleapis.com/v1/mediaItems/\(id)"),
              let d = try? await get(u),
              let o = (try? JSONSerialization.jsonObject(with: d)) as? [String: Any] else { return nil }
        return Self.parse(o)
    }

    func download(_ item: GPItem) async throws -> URL {
        let f = await fresh(item.id) ?? item
        guard let url = URL(string: f.baseUrl + (item.isVideo ? "=dv" : "=d")) else { throw AppError("Địa chỉ tải về không hợp lệ.") }
        let (tmp, resp) = try await URLSession.shared.download(from: url)
        let code = (resp as? HTTPURLResponse)?.statusCode ?? 0
        guard code == 200 else {
            try? FileManager.default.removeItem(at: tmp)
            throw AppError(item.isVideo && code == 404 ? "Video đang được Google xử lý, thử lại sau ít phút." : "Tải về thất bại (mã \(code)).")
        }
        try FileSpace.check(for: tmp)
        let dir = Paths.category(for: item.isVideo ? .video : .image)
        try FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        let dest = FileOps.uniqueURL(dir: dir, name: item.filename)
        try FileManager.default.moveItem(at: tmp, to: dest)
        return dest
    }

    // MARK: Hỗ trợ

    private func get(_ url: URL) async throws -> Data {
        for attempt in 0..<2 {
            let token = try await GoogleAuth.shared.accessToken(forceRefresh: attempt == 1)
            var r = URLRequest(url: url)
            r.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
            let (d, resp) = try await URLSession.shared.data(for: r)
            let code = (resp as? HTTPURLResponse)?.statusCode ?? 0
            if code == 401 && attempt == 0 { continue }
            guard code == 200 else {
                let o = (try? JSONSerialization.jsonObject(with: d)) as? [String: Any]
                let m = ((o?["error"] as? [String: Any])?["message"] as? String) ?? "Mã lỗi \(code)"
                throw LibError(code: code, message: "Google Photos: \(m)")
            }
            return d
        }
        throw AppError("Phiên đăng nhập bị từ chối, hãy đăng nhập lại.")
    }

    private static func parse(_ o: [String: Any]) -> GPItem? {
        guard let id = o["id"] as? String, let base = o["baseUrl"] as? String else { return nil }
        let meta = o["mediaMetadata"] as? [String: Any]
        var date = Date()
        if let s = meta?["creationTime"] as? String {
            let f1 = ISO8601DateFormatter()
            let f2 = ISO8601DateFormatter(); f2.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
            date = f1.date(from: s) ?? f2.date(from: s) ?? date
        }
        return GPItem(id: id, filename: o["filename"] as? String ?? id, baseUrl: base,
                      mime: o["mimeType"] as? String ?? "", created: date,
                      productUrl: o["productUrl"] as? String ?? "",
                      isVideo: meta?["video"] != nil)
    }
}

enum FileSpace {
    static func check(for url: URL) throws {
        // Tệp đã nằm trên máy; chỉ cần chắc chắn không còn trống bộ nhớ quá thấp khi lưu thêm
        try FileOps.checkSpace(needed: 0)
    }
}

// MARK: - Giao diện

struct GPViewerState: Identifiable { let id = UUID(); let index: Int }

struct GooglePhotosBrowser: View {
    @EnvironmentObject private var auth: GoogleAuth
    @StateObject private var lib = GooglePhotosLibrary()
    @State private var viewer: GPViewerState?
    @State private var selecting = false
    @State private var selection = Set<String>()
    @State private var message: String?
    @State private var downloading = false

    var body: some View {
        Group {
            if !auth.isSignedIn {
                ContentUnavailableView("Chưa đăng nhập", systemImage: "person.crop.circle.badge.exclamationmark",
                                       description: Text("Đăng nhập Google ở tab Tài khoản để xem ảnh đã tải lên."))
            } else if !auth.canReadLibrary {
                VStack(spacing: 14) {
                    ContentUnavailableView("Cần cấp thêm quyền", systemImage: "lock.open",
                                           description: Text("Để xem ảnh đã tải lên, hãy đăng nhập lại và đồng ý cấp quyền xem ảnh do Jinn Files tạo."))
                    Button("Đăng nhập lại") { Task { await auth.signIn() } }
                        .glassButtonStyle(prominent: true).controlSize(.large)
                }
            } else {
                content
            }
        }
        .navigationTitle("Google Photos")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                if auth.isSignedIn && auth.canReadLibrary {
                    if selecting {
                        Button("Xong") { selecting = false; selection.removeAll() }
                    } else {
                        Menu {
                            Button { selecting = true } label: { Label("Chọn nhiều", systemImage: "checkmark.circle") }
                            Button { Task { await lib.reload() } } label: { Label("Làm mới", systemImage: "arrow.clockwise") }
                        } label: { Image(systemName: "ellipsis.circle") }
                    }
                }
            }
            ToolbarItem(placement: .topBarLeading) {
                if selecting {
                    Button(selection.count == lib.items.count ? "Bỏ chọn" : "Chọn tất cả") {
                        if selection.count == lib.items.count { selection.removeAll() }
                        else { selection = Set(lib.items.map(\.id)) }
                    }
                }
            }
        }
        .task { if auth.isSignedIn && auth.canReadLibrary && lib.items.isEmpty && !lib.finished { await lib.reload() } }
        .fullScreenCover(item: $viewer) { v in
            GPViewer(items: lib.items, start: v.index, lib: lib, onClose: { viewer = nil })
        }
        .alert("Thông báo", isPresented: Binding(get: { message != nil }, set: { if !$0 { message = nil } })) {
            Button("OK") { message = nil }
        } message: { Text(message ?? "") }
        .alert("Lỗi", isPresented: Binding(get: { lib.error != nil }, set: { if !$0 { lib.error = nil } })) {
            Button("OK") { lib.error = nil }
        } message: { Text(lib.error ?? "") }
        .safeAreaInset(edge: .bottom) {
            if selecting && !selection.isEmpty {
                Button { downloadSelected() } label: {
                    HStack {
                        if downloading { ProgressView() }
                        Label("Tải về \(selection.count) mục", systemImage: "arrow.down.circle")
                    }.frame(maxWidth: .infinity)
                }
                .glassButtonStyle(prominent: true).controlSize(.large).disabled(downloading).padding()
            }
        }
    }

    private var content: some View {
        ScrollView {
            VStack(spacing: 10) {
                Text("Chỉ hiện ảnh và video đã tải lên từ Jinn Files (Google không cho ứng dụng xem toàn bộ thư viện). Muốn xóa ảnh, hãy xóa trong ứng dụng Google Photos.")
                    .font(.footnote).foregroundStyle(.secondary)
                    .padding(12).frame(maxWidth: .infinity, alignment: .leading).glassSurface(cornerRadius: 18)
                    .padding(.horizontal, 8)

                if lib.items.isEmpty && !lib.loading {
                    ContentUnavailableView("Chưa có ảnh nào", systemImage: "photo",
                                           description: Text("Ảnh tải lên từ Jinn Files sẽ hiện ở đây, có thể mất vài giây."))
                        .padding(.top, 30)
                }
                LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 3), count: 3), spacing: 3) {
                    ForEach(Array(lib.items.enumerated()), id: \.element.id) { i, item in
                        cell(item, index: i)
                            .onAppear { if i == lib.items.count - 6 { Task { await lib.loadMore() } } }
                    }
                }
                .padding(.horizontal, 3)
                if lib.loading { ProgressView().padding() }
            }
        }
        .refreshable { await lib.reload() }
    }

    private func cell(_ item: GPItem, index: Int) -> some View {
        Button {
            if selecting {
                if selection.contains(item.id) { selection.remove(item.id) } else { selection.insert(item.id) }
            } else { viewer = GPViewerState(index: index) }
        } label: {
            Color.clear.aspectRatio(1, contentMode: .fit)
                .overlay {
                    AsyncImage(url: item.thumb) { phase in
                        switch phase {
                        case .success(let img): img.resizable().scaledToFill()
                        case .failure: Image(systemName: "photo").foregroundStyle(.secondary)
                        default: ProgressView()
                        }
                    }
                }
                .clipped()
                .overlay(alignment: .bottomLeading) {
                    if item.isVideo { Image(systemName: "video.fill").font(.caption2).foregroundStyle(.white).shadow(radius: 2).padding(5) }
                }
                .overlay(alignment: .topTrailing) {
                    if selecting {
                        Image(systemName: selection.contains(item.id) ? "checkmark.circle.fill" : "circle")
                            .foregroundStyle(selection.contains(item.id) ? Color.accentColor : .white)
                            .shadow(radius: 2).padding(6)
                    }
                }
        }
        .buttonStyle(.plain)
    }

    private func downloadSelected() {
        let chosen = lib.items.filter { selection.contains($0.id) }
        downloading = true
        Task {
            var ok = 0
            var failed: [String] = []
            for it in chosen {
                do { _ = try await lib.download(it); ok += 1 }
                catch { failed.append("• \(it.filename): \(error.localizedDescription)") }
            }
            downloading = false
            selecting = false; selection.removeAll()
            var m = "Đã tải về \(ok)/\(chosen.count) mục vào Jinn Files (thư mục Images/Videos)."
            if !failed.isEmpty { m += "\nLỗi:\n" + failed.prefix(4).joined(separator: "\n") }
            message = m
        }
    }
}

struct GPViewer: View {
    let items: [GPItem]
    @State var index: Int
    let lib: GooglePhotosLibrary
    let onClose: () -> Void
    @State private var message: String?

    init(items: [GPItem], start: Int, lib: GooglePhotosLibrary, onClose: @escaping () -> Void) {
        self.items = items; self._index = State(initialValue: start); self.lib = lib; self.onClose = onClose
    }

    var body: some View {
        ZStack(alignment: .top) {
            Color.black.ignoresSafeArea()
            TabView(selection: $index) {
                ForEach(Array(items.enumerated()), id: \.offset) { i, it in
                    GPPage(item: it, lib: lib).tag(i)
                }
            }
            .tabViewStyle(.page(indexDisplayMode: .never))
            .ignoresSafeArea()

            HStack {
                Button { onClose() } label: {
                    Image(systemName: "xmark").font(.headline).foregroundStyle(.white).glassCircle(size: 40)
                }
                Spacer()
                Text("\(index + 1)/\(items.count)").foregroundStyle(.white).font(.footnote)
                Spacer()
                Menu {
                    Button {
                        guard items.indices.contains(index) else { return }
                        let it = items[index]
                        Task {
                            do { let u = try await lib.download(it); message = "Đã tải về: \(u.lastPathComponent)" }
                            catch { message = error.localizedDescription }
                        }
                    } label: { Label("Tải về Jinn Files", systemImage: "arrow.down.circle") }
                    if items.indices.contains(index), let u = URL(string: items[index].productUrl) {
                        Link(destination: u) { Label("Mở trong Google Photos", systemImage: "arrow.up.right.square") }
                    }
                } label: {
                    Image(systemName: "ellipsis").font(.headline).foregroundStyle(.white).glassCircle(size: 40)
                }
            }
            .padding()
        }
        .alert("Thông báo", isPresented: Binding(get: { message != nil }, set: { if !$0 { message = nil } })) {
            Button("OK") { message = nil }
        } message: { Text(message ?? "") }
    }
}

struct GPPage: View {
    let item: GPItem
    let lib: GooglePhotosLibrary
    @State private var fresh: GPItem?
    @State private var player: AVPlayer?

    var body: some View {
        ZStack {
            if let f = fresh {
                if item.isVideo {
                    if let player { VideoPlayer(player: player) } else { ProgressView().tint(.white) }
                } else {
                    AsyncImage(url: URL(string: f.baseUrl + "=w2048-h2048")) { phase in
                        switch phase {
                        case .success(let img): img.resizable().scaledToFit()
                        case .failure: Image(systemName: "exclamationmark.triangle").foregroundStyle(.white)
                        default: ProgressView().tint(.white)
                        }
                    }
                }
            } else {
                ProgressView().tint(.white)
            }
        }
        .task {
            let f = await lib.fresh(item.id) ?? item
            fresh = f
            if item.isVideo, let u = URL(string: f.baseUrl + "=dv") { player = AVPlayer(url: u) }
        }
        .onDisappear { player?.pause() }
    }
}
