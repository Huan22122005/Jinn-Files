import SwiftUI
import WebKit
import UIKit
import PhotosUI
import ImageIO

// MARK: - Dữ liệu

struct Bookmark: Codable, Identifiable, Hashable {
    var id = UUID()
    var title: String
    var url: String
    var date = Date()
}

struct HistoryEntry: Codable, Identifiable, Hashable {
    var id = UUID()
    var title: String
    var url: String
    var date: Date
}

struct PendingDownload: Identifiable {
    let id = UUID()
    let url: URL
    var fileName: String
    let size: Int64
    let headers: [String: String]
}

extension UIApplication {
    static func topViewController() -> UIViewController? {
        let scenes = shared.connectedScenes.compactMap { $0 as? UIWindowScene }
        let scene = scenes.first(where: { $0.activationState == .foregroundActive }) ?? scenes.first
        var top = scene?.windows.first(where: \.isKeyWindow)?.rootViewController
        while let p = top?.presentedViewController { top = p }
        return top
    }
}

// MARK: - Một tab trình duyệt

@MainActor
final class BrowserTab: NSObject, ObservableObject, Identifiable, WKNavigationDelegate, WKUIDelegate {
    let id = UUID()
    let isPrivate: Bool
    let webView: WKWebView
    weak var store: BrowserStore?

    @Published var title = "Tab mới"
    @Published var urlString = ""
    @Published var progress = 0.0
    @Published var isLoading = false
    @Published var canGoBack = false
    @Published var canGoForward = false
    @Published var hasContent = false
    @Published var snapshot: UIImage?
    @Published var errorText: String?
    @Published var desktopMode = false

    private var observers: [NSKeyValueObservation] = []

    init(isPrivate: Bool, store: BrowserStore, dataStore: WKWebsiteDataStore) {
        self.isPrivate = isPrivate
        self.store = store
        let cfg = WKWebViewConfiguration()
        cfg.websiteDataStore = dataStore
        cfg.allowsInlineMediaPlayback = true
        webView = WKWebView(frame: .zero, configuration: cfg)
        super.init()
        webView.navigationDelegate = self
        webView.uiDelegate = self
        webView.allowsBackForwardNavigationGestures = true
        observe()
    }

    private func observe() {
        let h: (WKWebView) -> Void = { [weak self] _ in Task { @MainActor in self?.refresh() } }
        observers = [
            webView.observe(\.title) { wv, _ in h(wv) },
            webView.observe(\.url) { wv, _ in h(wv) },
            webView.observe(\.estimatedProgress) { wv, _ in h(wv) },
            webView.observe(\.isLoading) { wv, _ in h(wv) },
            webView.observe(\.canGoBack) { wv, _ in h(wv) },
            webView.observe(\.canGoForward) { wv, _ in h(wv) }
        ]
    }

    private func refresh() {
        if let t = webView.title, !t.isEmpty { title = t }
        if let u = webView.url, u.absoluteString != "about:blank" {
            urlString = u.absoluteString
            hasContent = true
        }
        progress = webView.estimatedProgress
        isLoading = webView.isLoading
        canGoBack = webView.canGoBack
        canGoForward = webView.canGoForward
    }

    var displayHost: String {
        guard let u = URL(string: urlString), let h = u.host else { return urlString }
        return h.hasPrefix("www.") ? String(h.dropFirst(4)) : h
    }

    var isSecure: Bool { urlString.hasPrefix("https://") }

    // MARK: Điều hướng

    static func resolve(_ input: String) -> URL? {
        let t = input.trimmingCharacters(in: .whitespacesAndNewlines)
        if t.isEmpty { return nil }
        if let u = URL(string: t), let s = u.scheme?.lowercased(), ["http", "https", "file"].contains(s), u.host != nil || s == "file" { return u }
        if !t.contains(" "), t.contains("."), let u = URL(string: "https://" + t), u.host?.contains(".") == true { return u }
        if t.lowercased().hasPrefix("localhost"), let u = URL(string: "http://" + t) { return u }
        var c = URLComponents(string: "https://www.google.com/search")!
        c.queryItems = [URLQueryItem(name: "q", value: t)]
        return c.url
    }

    func load(_ input: String) {
        guard let u = Self.resolve(input) else { return }
        errorText = nil
        hasContent = true
        webView.load(URLRequest(url: u))
    }

    func reload() { errorText = nil; webView.reload() }
    func stop() { webView.stopLoading() }
    func goBack() { webView.goBack() }
    func goForward() { webView.goForward() }

    func toggleDesktop() {
        desktopMode.toggle()
        webView.configuration.defaultWebpagePreferences.preferredContentMode = desktopMode ? .desktop : .mobile
        webView.customUserAgent = desktopMode
            ? "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Safari/605.1.15"
            : nil
        webView.reload()
    }

    func takeSnapshot() async {
        let cfg = WKSnapshotConfiguration()
        cfg.snapshotWidth = 320
        if let img = try? await webView.takeSnapshot(configuration: cfg) { snapshot = img }
    }

    // MARK: WKNavigationDelegate

    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction,
                 decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        if let url = navigationAction.request.url, let scheme = url.scheme?.lowercased(),
           !["http", "https", "about", "file", "data", "blob"].contains(scheme) {
            UIApplication.shared.open(url)
            decisionHandler(.cancel)
            return
        }
        decisionHandler(.allow)
    }

    func webView(_ webView: WKWebView, decidePolicyFor navigationResponse: WKNavigationResponse,
                 decisionHandler: @escaping (WKNavigationResponsePolicy) -> Void) {
        guard navigationResponse.isForMainFrame else { decisionHandler(.allow); return }
        let resp = navigationResponse.response
        var attachment = false
        if let http = resp as? HTTPURLResponse,
           let cd = http.value(forHTTPHeaderField: "Content-Disposition")?.lowercased(), cd.contains("attachment") {
            attachment = true
        }
        if (attachment || !navigationResponse.canShowMIMEType), let url = resp.url {
            decisionHandler(.cancel)
            store?.requestDownload(url: url, suggested: resp.suggestedFilename, size: resp.expectedContentLength, from: self)
        } else {
            decisionHandler(.allow)
        }
    }

    func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) { errorText = nil }

    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        refresh()
        store?.recordVisit(title: webView.title ?? "", url: webView.url, isPrivate: isPrivate)
    }

    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) { handle(error) }
    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) { handle(error) }

    private func handle(_ error: Error) {
        let ns = error as NSError
        if ns.code == NSURLErrorCancelled || ns.code == 102 { return }   // 102: đã chuyển sang tải xuống
        errorText = error.localizedDescription
    }

    // MARK: WKUIDelegate

    func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration,
                 for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
        if let url = navigationAction.request.url { store?.openTab(url: url, isPrivate: isPrivate, select: true) }
        return nil
    }

    func webView(_ webView: WKWebView, runJavaScriptAlertPanelWithMessage message: String,
                 initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping () -> Void) {
        guard let top = UIApplication.topViewController() else { completionHandler(); return }
        let a = UIAlertController(title: webView.url?.host, message: message, preferredStyle: .alert)
        a.addAction(UIAlertAction(title: "OK", style: .default) { _ in completionHandler() })
        top.present(a, animated: true)
    }

    func webView(_ webView: WKWebView, runJavaScriptConfirmPanelWithMessage message: String,
                 initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping (Bool) -> Void) {
        guard let top = UIApplication.topViewController() else { completionHandler(false); return }
        let a = UIAlertController(title: webView.url?.host, message: message, preferredStyle: .alert)
        a.addAction(UIAlertAction(title: "Hủy", style: .cancel) { _ in completionHandler(false) })
        a.addAction(UIAlertAction(title: "OK", style: .default) { _ in completionHandler(true) })
        top.present(a, animated: true)
    }

    func webView(_ webView: WKWebView, contextMenuConfigurationForElement elementInfo: WKContextMenuElementInfo,
                 completionHandler: @escaping (UIContextMenuConfiguration?) -> Void) {
        guard let url = elementInfo.linkURL else { completionHandler(nil); return }
        let priv = isPrivate
        let cfg = UIContextMenuConfiguration(identifier: nil, previewProvider: nil) { [weak self] _ in
            UIMenu(children: [
                UIAction(title: "Mở", image: UIImage(systemName: "safari")) { _ in webView.load(URLRequest(url: url)) },
                UIAction(title: "Mở trong tab mới", image: UIImage(systemName: "plus.square.on.square")) { _ in
                    Task { @MainActor in self?.store?.openTab(url: url, isPrivate: priv, select: false) }
                },
                UIAction(title: "Tải xuống vào Jinn Files", image: UIImage(systemName: "arrow.down.circle")) { _ in
                    Task { @MainActor in
                        if let s = self { s.store?.requestDownload(url: url, suggested: nil, size: -1, from: s) }
                    }
                },
                UIAction(title: "Sao chép liên kết", image: UIImage(systemName: "doc.on.doc")) { _ in
                    UIPasteboard.general.string = url.absoluteString
                }
            ])
        }
        completionHandler(cfg)
    }
}

// MARK: - Kho dữ liệu trình duyệt (tab, dấu trang, lịch sử)

@MainActor
final class BrowserStore: ObservableObject {
    static let shared = BrowserStore()

    @Published var tabs: [BrowserTab] = []
    @Published var currentID: UUID?
    @Published var bookmarks: [Bookmark] = []
    @Published var history: [HistoryEntry] = []
    @Published var pendingDownload: PendingDownload?
    @Published var backgroundImage: UIImage?

    private var backgroundFile: URL { Paths.meta.appendingPathComponent("browser-background.jpg") }
    private var privateDataStore: WKWebsiteDataStore?
    private var bookmarksFile: URL { Paths.meta.appendingPathComponent("bookmarks.json") }
    private var historyFile: URL { Paths.meta.appendingPathComponent("history.json") }

    var current: BrowserTab? { tabs.first { $0.id == currentID } ?? tabs.first }

    init() {
        Paths.bootstrap()
        let dec = JSONDecoder(); dec.dateDecodingStrategy = .iso8601
        if let d = try? Data(contentsOf: bookmarksFile) { bookmarks = (try? dec.decode([Bookmark].self, from: d)) ?? [] }
        if let d = try? Data(contentsOf: historyFile) { history = (try? dec.decode([HistoryEntry].self, from: d)) ?? [] }
        if let d = try? Data(contentsOf: backgroundFile) { backgroundImage = UIImage(data: d) }
        let saved = UserDefaults.standard.stringArray(forKey: "browserTabs") ?? []
        for s in saved { openTab(url: URL(string: s), isPrivate: false, select: true) }
        if tabs.isEmpty { openTab(url: nil, isPrivate: false, select: true) }
    }

    // MARK: Hình nền trang bắt đầu

    /// Lưu ảnh nền (thu nhỏ còn tối đa 2200 px để nhẹ bộ nhớ)
    func setBackground(_ data: Data) {
        guard let src = CGImageSourceCreateWithData(data as CFData, nil) else { return }
        let o: [CFString: Any] = [
            kCGImageSourceCreateThumbnailFromImageAlways: true,
            kCGImageSourceCreateThumbnailWithTransform: true,
            kCGImageSourceThumbnailMaxPixelSize: 2200
        ]
        guard let cg = CGImageSourceCreateThumbnailAtIndex(src, 0, o as CFDictionary) else { return }
        let img = UIImage(cgImage: cg)
        if let jpg = img.jpegData(compressionQuality: 0.85) { try? jpg.write(to: backgroundFile, options: .atomic) }
        backgroundImage = img
    }

    func clearBackground() {
        try? FileManager.default.removeItem(at: backgroundFile)
        backgroundImage = nil
    }

    // MARK: Tab

    private func dataStore(private priv: Bool) -> WKWebsiteDataStore {
        if !priv { return .default() }
        if privateDataStore == nil { privateDataStore = .nonPersistent() }
        return privateDataStore!
    }

    @discardableResult
    func openTab(url: URL? = nil, isPrivate: Bool = false, select: Bool = true) -> BrowserTab {
        let t = BrowserTab(isPrivate: isPrivate, store: self, dataStore: dataStore(private: isPrivate))
        tabs.append(t)
        if select || currentID == nil { currentID = t.id }
        if let url { t.load(url.absoluteString) }
        saveTabs()
        return t
    }

    func select(_ t: BrowserTab) { currentID = t.id }

    func close(_ t: BrowserTab) {
        tabs.removeAll { $0.id == t.id }
        if !tabs.contains(where: { $0.isPrivate }) { privateDataStore = nil }   // hết tab riêng tư: bỏ toàn bộ dữ liệu tạm
        if tabs.isEmpty { openTab(url: nil, isPrivate: false, select: true) }
        else if currentID == t.id { currentID = tabs.last?.id }
        saveTabs()
    }

    func saveTabs() {
        let urls = tabs.filter { !$0.isPrivate }.compactMap { $0.webView.url?.absoluteString }
        UserDefaults.standard.set(urls, forKey: "browserTabs")
    }

    // MARK: Dấu trang

    func isBookmarked(_ url: String) -> Bool { bookmarks.contains { $0.url == url } }

    func toggleBookmark(title: String, url: String) {
        if let i = bookmarks.firstIndex(where: { $0.url == url }) { bookmarks.remove(at: i) }
        else { bookmarks.insert(Bookmark(title: title.isEmpty ? url : title, url: url), at: 0) }
        persist(bookmarks, to: bookmarksFile)
    }

    func removeBookmarks(at offsets: IndexSet) {
        bookmarks.remove(atOffsets: offsets)
        persist(bookmarks, to: bookmarksFile)
    }

    // MARK: Lịch sử

    func recordVisit(title: String, url: URL?, isPrivate: Bool) {
        guard !isPrivate, let url, ["http", "https"].contains(url.scheme?.lowercased() ?? "") else { return }
        if let first = history.first, first.url == url.absoluteString, Date().timeIntervalSince(first.date) < 5 { return }
        history.insert(HistoryEntry(title: title.isEmpty ? url.host ?? url.absoluteString : title, url: url.absoluteString, date: Date()), at: 0)
        if history.count > 3000 { history.removeLast(history.count - 3000) }
        persist(history, to: historyFile)
    }

    func removeHistory(_ e: HistoryEntry) {
        history.removeAll { $0.id == e.id }
        persist(history, to: historyFile)
    }

    func clearHistory() {
        history = []
        persist(history, to: historyFile)
    }

    /// Xóa lịch sử, cookie, bộ nhớ đệm và mọi dữ liệu trang web
    func clearAllBrowsingData() async {
        clearHistory()
        let types = WKWebsiteDataStore.allWebsiteDataTypes()
        await WKWebsiteDataStore.default().removeData(ofTypes: types, modifiedSince: Date(timeIntervalSince1970: 0))
    }

    private func persist<T: Encodable>(_ value: T, to url: URL) {
        let enc = JSONEncoder(); enc.dateEncodingStrategy = .iso8601
        guard let d = try? enc.encode(value) else { return }
        DispatchQueue.global(qos: .utility).async { try? d.write(to: url, options: .atomic) }
    }

    // MARK: Tải xuống từ trình duyệt

    func requestDownload(url: URL, suggested: String?, size: Int64, from tab: BrowserTab) {
        Task {
            let cookies = await tab.webView.configuration.websiteDataStore.httpCookieStore.allCookies()
            let host = url.host ?? ""
            let matching = cookies.filter { c in
                let d = c.domain.hasPrefix(".") ? String(c.domain.dropFirst()) : c.domain
                return host == d || host.hasSuffix("." + d)
            }
            var headers = HTTPCookie.requestHeaderFields(with: matching)
            if !tab.urlString.isEmpty { headers["Referer"] = tab.urlString }
            var name = (suggested ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
            if name.isEmpty { name = url.lastPathComponent }
            if name.isEmpty { name = "tai-xuong" }
            pendingDownload = PendingDownload(url: url, fileName: name, size: size, headers: headers)
        }
    }
}

// MARK: - Giao diện

struct WebViewRepresentable: UIViewRepresentable {
    let webView: WKWebView
    func makeUIView(context: Context) -> WKWebView { webView }
    func updateUIView(_ uiView: WKWebView, context: Context) {}
}

/// Màn hình trình duyệt. Mọi hộp thoại/cửa sổ trượt nằm ở đây (không bị dựng lại khi đổi tab).
struct BrowserView: View {
    @EnvironmentObject private var store: BrowserStore
    @State private var showTabs = false
    @State private var showBookmarks = false
    @State private var showHistory = false
    @State private var showDownloads = false
    @State private var showShare = false
    @State private var confirmClear = false
    @State private var toast: String?
    @State private var showPhotoPicker = false
    @State private var showLocalBackground = false
    @State private var pickedPhoto: PhotosPickerItem?

    var body: some View {
        NavigationStack {
            Group {
                if let tab = store.current {
                    BrowserPage(tab: tab, showTabs: $showTabs, showBookmarks: $showBookmarks, showHistory: $showHistory,
                                showDownloads: $showDownloads, showShare: $showShare, confirmClear: $confirmClear, toast: $toast,
                                showPhotoPicker: $showPhotoPicker, showLocalBackground: $showLocalBackground)
                        .id(tab.id)
                } else {
                    ProgressView()
                }
            }
            .toolbar(.hidden, for: .navigationBar)
        }
        .fullScreenCover(isPresented: $showTabs) { TabSwitcher(toast: $toast) }
        .sheet(isPresented: $showBookmarks) { if let t = store.current { BookmarksView(tab: t) } }
        .sheet(isPresented: $showHistory) { if let t = store.current { HistoryView(tab: t) } }
        .sheet(isPresented: $showDownloads) { NavigationStack { DownloadManagerView() } }
        .sheet(isPresented: $showShare) {
            if let t = store.current, let u = URL(string: t.urlString) { ActivityView(items: [u]) }
        }
        .sheet(item: $store.pendingDownload) { p in DownloadPromptView(pending: p) }
        .photosPicker(isPresented: $showPhotoPicker, selection: $pickedPhoto, matching: .images)
        .onChange(of: pickedPhoto) { _, item in
            guard let item else { return }
            Task {
                if let d = try? await item.loadTransferable(type: Data.self) {
                    store.setBackground(d)
                    toast = "Đã đổi hình nền trình duyệt"
                }
                pickedPhoto = nil
            }
        }
        .sheet(isPresented: $showLocalBackground) {
            LocalFilePickerSheet(rootTitle: "Chọn ảnh nền", icon: "photo", allowFolders: false,
                                 actionTitle: { $0 == 0 ? "Chọn một ảnh" : "Dùng ảnh đã chọn" }) { urls in
                if let u = urls.first(where: { Kind.detect($0, isDirectory: false) == .image }),
                   let d = try? Data(contentsOf: u) {
                    store.setBackground(d)
                    toast = "Đã đổi hình nền trình duyệt"
                } else {
                    toast = "Hãy chọn một tệp ảnh"
                }
            }
        }
        .confirmationDialog("Xóa lịch sử và dữ liệu duyệt web?", isPresented: $confirmClear, titleVisibility: .visible) {
            Button("Xóa lịch sử, cookie và bộ nhớ đệm", role: .destructive) {
                Task { await store.clearAllBrowsingData(); toast = "Đã xóa lịch sử và dữ liệu duyệt web" }
            }
            Button("Hủy", role: .cancel) {}
        } message: { Text("Dấu trang được giữ lại. Các trang đang đăng nhập sẽ bị đăng xuất.") }
        .toast($toast)
    }
}

struct BrowserPage: View {
    @ObservedObject var tab: BrowserTab
    @EnvironmentObject private var store: BrowserStore
    @Binding var showTabs: Bool
    @Binding var showBookmarks: Bool
    @Binding var showHistory: Bool
    @Binding var showDownloads: Bool
    @Binding var showShare: Bool
    @Binding var confirmClear: Bool
    @Binding var toast: String?
    @Binding var showPhotoPicker: Bool
    @Binding var showLocalBackground: Bool
    @FocusState private var focused: Bool
    @State private var text = ""

    private var bookmarked: Bool { store.isBookmarked(tab.urlString) }
    private var accent: Color { tab.isPrivate ? .purple : Color.accentColor }

    var body: some View {
        VStack(spacing: 0) {
            topBar
                .zIndex(10)
            ProgressView(value: tab.progress)
                .tint(accent)
                .opacity(tab.isLoading ? 1 : 0)
                .frame(height: 2)
            ZStack {
                WebViewRepresentable(webView: tab.webView)
                if !tab.hasContent {
                    StartPage(tab: tab, showBookmarks: $showBookmarks)
                    backgroundButton
                }
                if let e = tab.errorText { errorView(e) }
            }
            .clipped()
            bottomBar
        }
        .background(Color(.systemBackground))
        .tint(accent)
    }

    // MARK: Thanh địa chỉ (trên)

    private var topBar: some View {
        HStack(spacing: 8) {
            addressField
            menu
        }
        .padding(.horizontal, 12).padding(.vertical, 6)
        .background(tab.isPrivate ? Color.purple.opacity(0.14) : Color.clear)
    }

    private var addressField: some View {
        HStack(spacing: 6) {
            Image(systemName: tab.isPrivate ? "hand.raised.fill" : (tab.isSecure ? "lock.fill" : "magnifyingglass"))
                .font(.footnote).foregroundStyle(tab.isPrivate ? Color.purple : Color.secondary)
            TextField("Tìm Google hoặc nhập địa chỉ", text: Binding(
                get: { focused ? text : tab.displayHost },
                set: { text = $0 }))
                .focused($focused)
                .keyboardType(.webSearch)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
                .submitLabel(.go)
                .onSubmit { tab.load(text); focused = false }
                .onChange(of: focused) { _, f in if f { text = tab.urlString } }
            if tab.isPrivate && !focused {
                Text("Riêng tư").font(.system(size: 10, weight: .semibold)).foregroundStyle(.white)
                    .padding(.horizontal, 7).padding(.vertical, 2).background(Color.purple, in: Capsule())
            }
            if focused && !text.isEmpty {
                Button { text = "" } label: { Image(systemName: "xmark.circle.fill").foregroundStyle(.secondary) }
            } else if tab.isLoading {
                Button { tab.stop() } label: { Image(systemName: "xmark").font(.footnote) }
            } else if tab.hasContent {
                Button { tab.reload() } label: { Image(systemName: "arrow.clockwise").font(.footnote) }
            }
        }
        .padding(.horizontal, 12).padding(.vertical, 9)
        .glassSurface(cornerRadius: 20)
    }

    private var menu: some View {
        Menu {
            Button { store.openTab(isPrivate: false, select: true) } label: { Label("Tab mới", systemImage: "plus.square") }
            Button { store.openTab(isPrivate: true, select: true) } label: { Label("Tab riêng tư mới", systemImage: "hand.raised") }
            Button(role: .destructive) { store.close(tab) } label: { Label("Đóng tab này", systemImage: "xmark.square") }
            Divider()
            Button {
                store.toggleBookmark(title: tab.title, url: tab.urlString)
                toast = bookmarked ? "Đã bỏ dấu trang" : "Đã thêm dấu trang"
            } label: {
                Label(bookmarked ? "Bỏ dấu trang" : "Thêm dấu trang", systemImage: bookmarked ? "bookmark.slash" : "bookmark")
            }
            .disabled(!tab.hasContent)
            Button { showBookmarks = true } label: { Label("Dấu trang", systemImage: "book") }
            Button { showHistory = true } label: { Label("Lịch sử", systemImage: "clock") }
            Button { showDownloads = true } label: { Label("Tải xuống", systemImage: "arrow.down.circle") }
            Menu {
                Button { showPhotoPicker = true } label: { Label("Chọn từ thư viện ảnh", systemImage: "photo.on.rectangle") }
                Button { showLocalBackground = true } label: { Label("Chọn từ Jinn Files", systemImage: "folder") }
                if store.backgroundImage != nil {
                    Button(role: .destructive) { store.clearBackground() } label: { Label("Xóa hình nền", systemImage: "trash") }
                }
            } label: { Label("Hình nền trang bắt đầu", systemImage: "paintbrush") }
            Divider()
            Button { showShare = true } label: { Label("Chia sẻ trang", systemImage: "square.and.arrow.up") }
                .disabled(!tab.hasContent)
            Button { tab.toggleDesktop() } label: {
                Label(tab.desktopMode ? "Trang cho di động" : "Trang cho máy tính", systemImage: tab.desktopMode ? "iphone" : "desktopcomputer")
            }
            Divider()
            Button(role: .destructive) { confirmClear = true } label: { Label("Xóa lịch sử và dữ liệu", systemImage: "trash") }
        } label: {
            Image(systemName: "ellipsis.circle").font(.title3).frame(width: 36, height: 38)
        }
    }

    /// Nút đổi hình nền ở góc dưới bên phải của trang bắt đầu
    private var backgroundButton: some View {
        VStack {
            Spacer()
            HStack {
                Spacer()
                Menu {
                    Button { showPhotoPicker = true } label: { Label("Chọn từ thư viện ảnh", systemImage: "photo.on.rectangle") }
                    Button { showLocalBackground = true } label: { Label("Chọn từ Jinn Files", systemImage: "folder") }
                    if store.backgroundImage != nil {
                        Button(role: .destructive) { store.clearBackground() } label: { Label("Xóa hình nền", systemImage: "trash") }
                    }
                } label: {
                    Image(systemName: "paintbrush.pointed.fill").font(.headline).foregroundStyle(accent).glassCircle(size: 44)
                }
                .padding(16)
            }
        }
    }

    // MARK: Thanh điều hướng (dưới)

    private func navButton(_ symbol: String, disabled: Bool = false, _ action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Image(systemName: symbol).font(.title3).frame(maxWidth: .infinity, minHeight: 40)
        }
        .buttonStyle(.plain)
        .disabled(disabled)
        .opacity(disabled ? 0.35 : 1)
    }

    private var bottomBar: some View {
        HStack(spacing: 0) {
            navButton("chevron.left", disabled: !tab.canGoBack) { tab.goBack() }
            navButton("chevron.right", disabled: !tab.canGoForward) { tab.goForward() }
            navButton("plus.square") {
                store.openTab(isPrivate: tab.isPrivate, select: true)
                toast = tab.isPrivate ? "Đã mở tab riêng tư mới" : nil
            }
            navButton("book") { showBookmarks = true }
            Button {
                Task { await tab.takeSnapshot(); showTabs = true }
            } label: {
                ZStack {
                    RoundedRectangle(cornerRadius: 6).stroke(lineWidth: 2).frame(width: 22, height: 22)
                    Text("\(store.tabs.count)").font(.system(size: 11, weight: .bold))
                }
                .frame(maxWidth: .infinity, minHeight: 40)
            }
            .buttonStyle(.plain)
        }
        .foregroundStyle(accent)
        .padding(.horizontal, 8).padding(.vertical, 4)
        .glassSurface(cornerRadius: 26)
        .padding(.horizontal, 16).padding(.bottom, 4).padding(.top, 2)
    }

    private func errorView(_ e: String) -> some View {
        VStack(spacing: 12) {
            Image(systemName: "wifi.exclamationmark").font(.largeTitle).foregroundStyle(.secondary)
            Text("Không mở được trang").font(.headline)
            Text(e).font(.footnote).foregroundStyle(.secondary).multilineTextAlignment(.center)
            Button("Thử lại") { tab.reload() }.glassButtonStyle(prominent: true)
        }
        .padding(24)
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Color(.systemBackground))
    }
}

// MARK: - Biểu tượng trang web

struct FaviconView: View {
    let url: String
    let title: String
    var color: Color = .accentColor
    var size: CGFloat = 58

    private var faviconURL: URL? {
        guard let host = URL(string: url)?.host else { return nil }
        return URL(string: "https://www.google.com/s2/favicons?sz=128&domain=\(host)")
    }

    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: size * 0.26, style: .continuous).fill(Color.white)
            AsyncImage(url: faviconURL) { phase in
                switch phase {
                case .success(let img):
                    img.resizable().scaledToFit().padding(size * 0.2)
                default:
                    Text(String(title.prefix(1)).uppercased())
                        .font(.system(size: size * 0.42, weight: .bold)).foregroundStyle(color)
                }
            }
        }
        .frame(width: size, height: size)
        .shadow(color: .black.opacity(0.12), radius: 3, y: 1)
    }
}

// MARK: - Trang bắt đầu (kiểu Safari): web đề xuất ở trên, dấu trang ở dưới

struct StartPage: View {
    @ObservedObject var tab: BrowserTab
    @Binding var showBookmarks: Bool
    @EnvironmentObject private var store: BrowserStore

    private struct Site: Identifiable { let id = UUID(); let title: String; let url: String; let color: Color }
    private let suggested: [Site] = [
        Site(title: "Google", url: "https://www.google.com", color: .blue),
        Site(title: "Apple", url: "https://www.apple.com", color: .gray),
        Site(title: "GitHub", url: "https://github.com", color: .indigo),
        Site(title: "Bing", url: "https://www.bing.com", color: .teal)
    ]

    private var hasWallpaper: Bool { store.backgroundImage != nil }
    private var useDark: Bool { tab.isPrivate || hasWallpaper }

    var body: some View {
        Group {
            if useDark { content.environment(\.colorScheme, .dark) } else { content }
        }
    }

    private var content: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 26) {
                if tab.isPrivate {
                    HStack(spacing: 12) {
                        Image(systemName: "hand.raised.fill").font(.title2).foregroundStyle(.purple)
                        VStack(alignment: .leading, spacing: 2) {
                            Text("Chế độ duyệt riêng tư").font(.headline)
                            Text("Lịch sử và cookie của tab riêng tư không được lưu. Tệp tải xuống vẫn nằm trong Jinn Files.")
                                .font(.caption).foregroundStyle(.secondary)
                        }
                    }
                    .padding(14).frame(maxWidth: .infinity, alignment: .leading).glassSurface(cornerRadius: 20)
                }

                section("Mục ưa thích", trailing: nil) {
                    LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 10), count: 4), spacing: 18) {
                        ForEach(suggested) { s in tile(title: s.title, url: s.url, color: s.color) }
                    }
                }

                section("Dấu trang", trailing: ("Hiển thị tất cả", { showBookmarks = true })) {
                    if store.bookmarks.isEmpty {
                        Text("Chưa có dấu trang. Mở một trang web rồi chọn ⋯ → Thêm dấu trang.")
                            .font(.footnote).foregroundStyle(.secondary)
                            .padding(14).frame(maxWidth: .infinity, alignment: .leading).glassSurface(cornerRadius: 18)
                    } else {
                        LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 10), count: 4), spacing: 18) {
                            ForEach(store.bookmarks.prefix(12)) { b in tile(title: b.title, url: b.url, color: Color.accentColor) }
                        }
                    }
                }
            }
            .padding(.horizontal, 18).padding(.top, 14).padding(.bottom, 80)
        }
        .background {
            Color.clear.overlay {
                if let img = store.backgroundImage {
                    Image(uiImage: img).resizable().scaledToFill().overlay(Color.black.opacity(0.3))
                } else if tab.isPrivate {
                    LinearGradient(colors: [Color(red: 0.12, green: 0.08, blue: 0.22), Color(red: 0.05, green: 0.04, blue: 0.10)],
                                   startPoint: .top, endPoint: .bottom)
                } else {
                    Color(.systemBackground)
                }
            }
            .clipped()
            .ignoresSafeArea()
            .allowsHitTesting(false)
        }
    }

    private func tile(title: String, url: String, color: Color) -> some View {
        Button { tab.load(url) } label: {
            VStack(spacing: 7) {
                FaviconView(url: url, title: title, color: color, size: 62)
                Text(title).font(.caption2).lineLimit(2).multilineTextAlignment(.center).foregroundStyle(.primary)
                    .frame(maxWidth: .infinity)
            }
        }
        .buttonStyle(.plain)
    }

    private func section<C: View>(_ title: String, trailing: (String, () -> Void)?, @ViewBuilder _ body: () -> C) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Text(title).font(.title3.bold())
                Spacer()
                if let trailing {
                    Button { trailing.1() } label: {
                        HStack(spacing: 2) { Text(trailing.0); Image(systemName: "chevron.right") }.font(.footnote.weight(.medium))
                    }
                }
            }
            body()
        }
    }
}

// MARK: - Chuyển tab

struct TabSwitcher: View {
    @EnvironmentObject private var store: BrowserStore
    @Environment(\.dismiss) private var dismiss
    @Binding var toast: String?
    @State private var showPrivate = false
    @State private var didInit = false

    private var shown: [BrowserTab] { store.tabs.filter { $0.isPrivate == showPrivate } }

    var body: some View {
        NavigationStack {
            ScrollView {
                Picker("Loại tab", selection: $showPrivate) {
                    Label("Thường", systemImage: "square.on.square").tag(false)
                    Label("Riêng tư", systemImage: "hand.raised.fill").tag(true)
                }
                .pickerStyle(.segmented).padding()

                if shown.isEmpty {
                    ContentUnavailableView(showPrivate ? "Chưa có tab riêng tư" : "Chưa có tab", systemImage: showPrivate ? "hand.raised" : "square.on.square",
                                           description: Text(showPrivate ? "Tab riêng tư không lưu lịch sử và cookie." : "Bấm nút bên dưới để mở tab mới."))
                        .padding(.top, 20)
                }
                LazyVGrid(columns: [GridItem(.flexible(), spacing: 12), GridItem(.flexible(), spacing: 12)], spacing: 14) {
                    ForEach(shown) { t in card(t) }
                }
                .padding(.horizontal, 12).padding(.bottom, 90)
            }
            .navigationTitle(showPrivate ? "Tab riêng tư" : "Các tab")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Menu {
                        Button(role: .destructive) { closeAll() } label: {
                            Label(showPrivate ? "Đóng tất cả tab riêng tư" : "Đóng tất cả tab thường", systemImage: "xmark.square")
                        }
                        .disabled(shown.isEmpty)
                    } label: { Image(systemName: "ellipsis.circle") }
                }
                ToolbarItem(placement: .topBarTrailing) { Button("Xong") { dismiss() } }
            }
            .safeAreaInset(edge: .bottom) {
                Button { newTab() } label: {
                    Label(showPrivate ? "Tab riêng tư mới" : "Tab mới", systemImage: "plus").frame(maxWidth: .infinity)
                }
                .glassButtonStyle(prominent: true).controlSize(.large)
                .tint(showPrivate ? .purple : Color.accentColor)
                .padding()
            }
            .onAppear {
                if !didInit { showPrivate = store.current?.isPrivate ?? false; didInit = true }
            }
        }
    }

    private func newTab() {
        store.openTab(isPrivate: showPrivate, select: true)
        toast = showPrivate ? "Đã mở tab riêng tư" : nil
        dismiss()
    }

    private func closeAll() {
        for t in shown { store.close(t) }
    }

    private func card(_ t: BrowserTab) -> some View {
        ZStack(alignment: .topTrailing) {
            VStack(spacing: 0) {
                Group {
                    if let img = t.snapshot {
                        Image(uiImage: img).resizable().scaledToFill()
                    } else {
                        ZStack {
                            Color(.tertiarySystemBackground)
                            Image(systemName: t.isPrivate ? "hand.raised.fill" : "globe").font(.largeTitle)
                                .foregroundStyle(t.isPrivate ? Color.purple : Color.secondary)
                        }
                    }
                }
                .frame(height: 150).frame(maxWidth: .infinity).clipped()
                HStack(spacing: 6) {
                    Image(systemName: t.isPrivate ? "hand.raised.fill" : "globe").font(.caption2)
                        .foregroundStyle(t.isPrivate ? Color.purple : Color.secondary)
                    Text(t.title).font(.caption.weight(.semibold)).lineLimit(1)
                    Spacer(minLength: 0)
                }
                .padding(.horizontal, 10).padding(.vertical, 8)
            }
            .background(Color(.secondarySystemBackground))
            .clipShape(RoundedRectangle(cornerRadius: 16))
            .overlay(RoundedRectangle(cornerRadius: 16)
                .stroke(t.id == store.current?.id ? (t.isPrivate ? Color.purple : Color.accentColor) : Color.clear, lineWidth: 2.5))
            .contentShape(RoundedRectangle(cornerRadius: 16))
            .onTapGesture { store.select(t); dismiss() }

            // Nút đóng nằm tách riêng, không nằm bên trong nút chọn tab
            Button {
                withAnimation { store.close(t) }
            } label: {
                Image(systemName: "xmark.circle.fill")
                    .font(.title2)
                    .symbolRenderingMode(.palette)
                    .foregroundStyle(.white, Color.black.opacity(0.6))
                    .padding(6)
            }
            .buttonStyle(.plain)
        }
    }
}

// MARK: - Dấu trang và lịch sử

struct BookmarksView: View {
    @ObservedObject var tab: BrowserTab
    @EnvironmentObject private var store: BrowserStore
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            List {
                if store.bookmarks.isEmpty {
                    ContentUnavailableView("Chưa có dấu trang", systemImage: "bookmark",
                                           description: Text("Mở một trang rồi chọn ⋯ → Thêm dấu trang."))
                }
                ForEach(store.bookmarks) { b in
                    Button { tab.load(b.url); dismiss() } label: {
                        VStack(alignment: .leading, spacing: 2) {
                            Text(b.title).lineLimit(1).foregroundStyle(.primary)
                            Text(b.url).font(.caption).foregroundStyle(.secondary).lineLimit(1)
                        }
                    }
                }
                .onDelete { store.removeBookmarks(at: $0) }
            }
            .navigationTitle("Dấu trang")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .topBarTrailing) { Button("Xong") { dismiss() } } }
        }
    }
}

struct HistoryView: View {
    @ObservedObject var tab: BrowserTab
    @EnvironmentObject private var store: BrowserStore
    @Environment(\.dismiss) private var dismiss
    @State private var query = ""
    @State private var confirmClear = false

    private var filtered: [HistoryEntry] {
        query.isEmpty ? store.history : store.history.filter {
            $0.title.localizedCaseInsensitiveContains(query) || $0.url.localizedCaseInsensitiveContains(query)
        }
    }

    private var days: [(Date, [HistoryEntry])] {
        let groups = Dictionary(grouping: filtered) { Calendar.current.startOfDay(for: $0.date) }
        return groups.keys.sorted(by: >).map { ($0, groups[$0] ?? []) }
    }

    var body: some View {
        NavigationStack {
            List {
                if filtered.isEmpty {
                    ContentUnavailableView("Chưa có lịch sử", systemImage: "clock", description: Text("Các trang bạn truy cập (ngoài chế độ riêng tư) sẽ hiện ở đây."))
                }
                ForEach(days, id: \.0) { day, entries in
                    Section(day.formatted(.dateTime.day().month(.wide).year().locale(Locale(identifier: "vi_VN")))) {
                        ForEach(entries) { e in
                            Button { tab.load(e.url); dismiss() } label: {
                                VStack(alignment: .leading, spacing: 2) {
                                    Text(e.title).lineLimit(1).foregroundStyle(.primary)
                                    Text(e.url).font(.caption).foregroundStyle(.secondary).lineLimit(1)
                                }
                            }
                            .swipeActions { Button(role: .destructive) { store.removeHistory(e) } label: { Label("Xóa", systemImage: "trash") } }
                        }
                    }
                }
            }
            .searchable(text: $query, prompt: "Tìm trong lịch sử")
            .navigationTitle("Lịch sử")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) { Button("Xóa tất cả", role: .destructive) { confirmClear = true }.disabled(store.history.isEmpty) }
                ToolbarItem(placement: .topBarTrailing) { Button("Xong") { dismiss() } }
            }
            .confirmationDialog("Xóa toàn bộ lịch sử?", isPresented: $confirmClear, titleVisibility: .visible) {
                Button("Xóa lịch sử", role: .destructive) { store.clearHistory() }
                Button("Hủy", role: .cancel) {}
            }
        }
    }
}
