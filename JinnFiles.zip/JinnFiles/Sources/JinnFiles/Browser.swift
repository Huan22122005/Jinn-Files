import SwiftUI
import WebKit
import UIKit
import PhotosUI
import ImageIO

// MARK: - Dữ liệu

struct Bookmark: Codable, Identifiable, Hashable {
    var id = UUID()
    var title: String
    var url: String
    var date = Date()
}

struct HistoryEntry: Codable, Identifiable, Hashable {
    var id = UUID()
    var title: String
    var url: String
    var date: Date
}

struct Favorite: Codable, Identifiable, Hashable {
    var id = UUID()
    var title: String
    var url: String
}

struct ReadingItem: Codable, Identifiable, Hashable {
    var id = UUID()
    var title: String
    var url: String
    var date = Date()
}

struct PendingDownload: Identifiable {
    let id = UUID()
    let url: URL
    var fileName: String
    let size: Int64
    let headers: [String: String]
}

extension UIApplication {
    static func topViewController() -> UIViewController? {
        let scenes = shared.connectedScenes.compactMap { $0 as? UIWindowScene }
        let scene = scenes.first(where: { $0.activationState == .foregroundActive }) ?? scenes.first
        var top = scene?.windows.first(where: \.isKeyWindow)?.rootViewController
        while let p = top?.presentedViewController { top = p }
        return top
    }
}

// MARK: - Một tab trình duyệt

@MainActor
final class BrowserTab: NSObject, ObservableObject, Identifiable, WKNavigationDelegate, WKUIDelegate {
    let id = UUID()
    let isPrivate: Bool
    let webView: WKWebView
    weak var store: BrowserStore?

    @Published var title = "Tab mới"
    @Published var urlString = ""
    @Published var progress = 0.0
    @Published var isLoading = false
    @Published var canGoBack = false
    @Published var canGoForward = false
    @Published var hasContent = false
    @Published var snapshot: UIImage?
    @Published var errorText: String?
    @Published var desktopMode = false
    @Published var blockedAdsOnPage = 0
    @Published var blockedPopupsOnPage = 0

    private var observers: [NSKeyValueObservation] = []

    init(isPrivate: Bool, store: BrowserStore, dataStore: WKWebsiteDataStore) {
        self.isPrivate = isPrivate
        self.store = store
        let cfg = WKWebViewConfiguration()
        cfg.websiteDataStore = dataStore
        cfg.allowsInlineMediaPlayback = true
        webView = WKWebView(frame: .zero, configuration: cfg)
        super.init()
        webView.navigationDelegate = self
        webView.uiDelegate = self
        webView.allowsBackForwardNavigationGestures = true
        // Chừa chỗ để nội dung trang cuộn qua phía dưới thanh địa chỉ bằng kính
        webView.scrollView.contentInset.bottom = 84
        webView.scrollView.verticalScrollIndicatorInsets.bottom = 84

        // Cài đặt trình chặn quảng cáo & popup
        let handler = WeakScriptMessageHandler { [weak self] _, body in
            guard let self,
                  let dict = body as? [String: Any],
                  let kindRaw = dict["kind"] as? String,
                  let kind = BlockedKind(rawValue: kindRaw) else { return }
            let host = (dict["sourceHost"] as? String).flatMap { $0.isEmpty ? nil : $0 }
                ?? AdBlockManager.normalizedHost(from: self.urlString) ?? ""
            let target = (dict["target"] as? String) ?? ""
            self.recordBlocked(kind: kind, sourceHost: host, target: target)
        }
        webView.configuration.userContentController.add(handler, name: AdBlockManager.messageHandlerName)
        AdBlockManager.shared.apply(to: webView)

        observe()
    }

    func recordBlocked(kind: BlockedKind, sourceHost: String, target: String) {
        if kind == .ad { blockedAdsOnPage += 1 } else { blockedPopupsOnPage += 1 }
        AdBlockManager.shared.record(kind: kind, sourceHost: sourceHost, target: target)
    }

    private func observe() {
        let h: (WKWebView) -> Void = { [weak self] _ in Task { @MainActor in self?.refresh() } }
        observers = [
            webView.observe(\.title) { wv, _ in h(wv) },
            webView.observe(\.url) { wv, _ in h(wv) },
            webView.observe(\.estimatedProgress) { wv, _ in h(wv) },
            webView.observe(\.isLoading) { wv, _ in h(wv) },
            webView.observe(\.canGoBack) { wv, _ in h(wv) },
            webView.observe(\.canGoForward) { wv, _ in h(wv) }
        ]
    }

    private func refresh() {
        if let t = webView.title, !t.isEmpty { title = t }
        if let u = webView.url, u.absoluteString != "about:blank" {
            urlString = u.absoluteString
            hasContent = true
        }
        progress = webView.estimatedProgress
        isLoading = webView.isLoading
        canGoBack = webView.canGoBack
        canGoForward = webView.canGoForward
    }

    var displayHost: String {
        guard let u = URL(string: urlString), let h = u.host else { return urlString }
        return h.hasPrefix("www.") ? String(h.dropFirst(4)) : h
    }

    var isSecure: Bool { urlString.hasPrefix("https://") }

    // MARK: Điều hướng

    static func resolveInfo(_ input: String) -> (url: URL, isSearch: Bool)? {
        let t = input.trimmingCharacters(in: .whitespacesAndNewlines)
        if t.isEmpty { return nil }
        if let u = URL(string: t), let s = u.scheme?.lowercased(), ["http", "https", "file"].contains(s), u.host != nil || s == "file" { return (u, false) }
        if !t.contains(" "), t.contains("."), let u = URL(string: "https://" + t), u.host?.contains(".") == true { return (u, false) }
        if t.lowercased().hasPrefix("localhost"), let u = URL(string: "http://" + t) { return (u, false) }
        var c = URLComponents(string: "https://www.google.com/search")!
        c.queryItems = [URLQueryItem(name: "q", value: t)]
        guard let u = c.url else { return nil }
        return (u, true)
    }

    static func resolve(_ input: String) -> URL? { resolveInfo(input)?.url }

    func load(_ input: String) {
        guard let r = Self.resolveInfo(input) else { return }
        if r.isSearch { store?.recordSearch(input.trimmingCharacters(in: .whitespacesAndNewlines), isPrivate: isPrivate) }
        errorText = nil
        hasContent = true
        blockedAdsOnPage = 0
        blockedPopupsOnPage = 0
        webView.load(URLRequest(url: r.url))
    }

    func reload() {
        errorText = nil
        blockedAdsOnPage = 0
        blockedPopupsOnPage = 0
        webView.reload()
    }
    func stop() { webView.stopLoading() }
    func goBack() { webView.goBack() }
    func goForward() { webView.goForward() }

    func goHome() {
        webView.stopLoading()
        hasContent = false
        urlString = ""
        title = "Tab mới"
        errorText = nil
        progress = 0
        isLoading = false
        blockedAdsOnPage = 0
        blockedPopupsOnPage = 0
    }

    func toggleDesktop() {
        desktopMode.toggle()
        webView.configuration.defaultWebpagePreferences.preferredContentMode = desktopMode ? .desktop : .mobile
        webView.customUserAgent = desktopMode
            ? "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Safari/605.1.15"
            : nil
        webView.reload()
    }

    func takeSnapshot() async {
        let cfg = WKSnapshotConfiguration()
        cfg.snapshotWidth = 320
        if let img = try? await webView.takeSnapshot(configuration: cfg) { snapshot = img }
    }

    // MARK: WKNavigationDelegate

    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction,
                 decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        if let url = navigationAction.request.url, let scheme = url.scheme?.lowercased(),
           !["http", "https", "about", "file", "data", "blob"].contains(scheme) {
            UIApplication.shared.open(url)
            decisionHandler(.cancel)
            return
        }
        decisionHandler(.allow)
    }

    func webView(_ webView: WKWebView, decidePolicyFor navigationResponse: WKNavigationResponse,
                 decisionHandler: @escaping (WKNavigationResponsePolicy) -> Void) {
        guard navigationResponse.isForMainFrame else { decisionHandler(.allow); return }
        let resp = navigationResponse.response
        var attachment = false
        if let http = resp as? HTTPURLResponse,
           let cd = http.value(forHTTPHeaderField: "Content-Disposition")?.lowercased(), cd.contains("attachment") {
            attachment = true
        }
        if (attachment || !navigationResponse.canShowMIMEType), let url = resp.url {
            decisionHandler(.cancel)
            store?.requestDownload(url: url, suggested: resp.suggestedFilename, size: resp.expectedContentLength, from: self)
        } else {
            decisionHandler(.allow)
        }
    }

    func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
        errorText = nil
        blockedAdsOnPage = 0
        blockedPopupsOnPage = 0
    }

    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        refresh()
        store?.recordVisit(title: webView.title ?? "", url: webView.url, isPrivate: isPrivate)
    }

    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) { handle(error) }
    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) { handle(error) }

    private func handle(_ error: Error) {
        let ns = error as NSError
        if ns.code == NSURLErrorCancelled || ns.code == 102 { return }   // 102: đã chuyển sang tải xuống
        errorText = error.localizedDescription
    }

    // MARK: WKUIDelegate

    func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration,
                 for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
        guard let url = navigationAction.request.url else { return nil }
        let currentHost = AdBlockManager.normalizedHost(from: urlString)
        let adBlocker = AdBlockManager.shared
        if adBlocker.isPopupBlockActive(for: currentHost) {
            let isScriptPopup = navigationAction.navigationType != .linkActivated
            let isAdTarget = adBlocker.isKnownAdOrPopupURL(url)
            if isScriptPopup || isAdTarget {
                recordBlocked(kind: .popup, sourceHost: currentHost ?? "", target: url.absoluteString)
                return nil
            }
        }
        store?.openTab(url: url, isPrivate: isPrivate, select: true)
        return nil
    }

    func webView(_ webView: WKWebView, runJavaScriptAlertPanelWithMessage message: String,
                 initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping () -> Void) {
        guard let top = UIApplication.topViewController() else { completionHandler(); return }
        let a = UIAlertController(title: webView.url?.host, message: message, preferredStyle: .alert)
        a.addAction(UIAlertAction(title: "OK", style: .default) { _ in completionHandler() })
        top.present(a, animated: true)
    }

    func webView(_ webView: WKWebView, runJavaScriptConfirmPanelWithMessage message: String,
                 initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping (Bool) -> Void) {
        guard let top = UIApplication.topViewController() else { completionHandler(false); return }
        let a = UIAlertController(title: webView.url?.host, message: message, preferredStyle: .alert)
        a.addAction(UIAlertAction(title: "Hủy", style: .cancel) { _ in completionHandler(false) })
        a.addAction(UIAlertAction(title: "OK", style: .default) { _ in completionHandler(true) })
        top.present(a, animated: true)
    }

    func webView(_ webView: WKWebView, contextMenuConfigurationForElement elementInfo: WKContextMenuElementInfo,
                 completionHandler: @escaping (UIContextMenuConfiguration?) -> Void) {
        guard let url = elementInfo.linkURL else { completionHandler(nil); return }
        let priv = isPrivate
        let cfg = UIContextMenuConfiguration(identifier: nil, previewProvider: nil) { [weak self] _ in
            UIMenu(children: [
                UIAction(title: "Mở", image: UIImage(systemName: "safari")) { _ in webView.load(URLRequest(url: url)) },
                UIAction(title: "Mở trong tab mới", image: UIImage(systemName: "plus.square.on.square")) { _ in
                    Task { @MainActor in self?.store?.openTab(url: url, isPrivate: priv, select: false) }
                },
                UIAction(title: "Tải xuống vào Jinn Files", image: UIImage(systemName: "arrow.down.circle")) { _ in
                    Task { @MainActor in
                        if let s = self { s.store?.requestDownload(url: url, suggested: nil, size: -1, from: s) }
                    }
                },
                UIAction(title: "Sao chép liên kết", image: UIImage(systemName: "doc.on.doc")) { _ in
                    UIPasteboard.general.string = url.absoluteString
                }
            ])
        }
        completionHandler(cfg)
    }
}

// MARK: - Kho dữ liệu trình duyệt (tab, dấu trang, lịch sử)

@MainActor
final class BrowserStore: ObservableObject {
    static let shared = BrowserStore()

    @Published var tabs: [BrowserTab] = []
    @Published var currentID: UUID?
    @Published var bookmarks: [Bookmark] = []
    @Published var history: [HistoryEntry] = []
    @Published var pendingDownload: PendingDownload?
    @Published var backgroundImage: UIImage?
    @Published var favorites: [Favorite] = []
    @Published var readingList: [ReadingItem] = []
    @Published var recentSearches: [String] = []

    static let defaultFavorites: [Favorite] = [
        Favorite(title: "Apple", url: "https://www.apple.com"),
        Favorite(title: "Bing", url: "https://www.bing.com"),
        Favorite(title: "Google", url: "https://www.google.com"),
        Favorite(title: "Yahoo", url: "https://www.yahoo.com"),
        Favorite(title: "GitHub", url: "https://github.com")
    ]
    private var favoritesFile: URL { Paths.meta.appendingPathComponent("favorites.json") }
    private var readingFile: URL { Paths.meta.appendingPathComponent("reading.json") }

    private var backgroundFile: URL { Paths.meta.appendingPathComponent("browser-background.jpg") }
    private var privateDataStore: WKWebsiteDataStore?
    private var bookmarksFile: URL { Paths.meta.appendingPathComponent("bookmarks.json") }
    private var historyFile: URL { Paths.meta.appendingPathComponent("history.json") }

    var current: BrowserTab? { tabs.first { $0.id == currentID } ?? tabs.first }

    init() {
        Paths.bootstrap()
        let dec = JSONDecoder(); dec.dateDecodingStrategy = .iso8601
        if let d = try? Data(contentsOf: bookmarksFile) { bookmarks = (try? dec.decode([Bookmark].self, from: d)) ?? [] }
        if let d = try? Data(contentsOf: historyFile) { history = (try? dec.decode([HistoryEntry].self, from: d)) ?? [] }
        if let d = try? Data(contentsOf: backgroundFile) { backgroundImage = UIImage(data: d) }
        if let d = try? Data(contentsOf: favoritesFile), let f = try? dec.decode([Favorite].self, from: d) { favorites = f }
        else { favorites = Self.defaultFavorites }
        if let d = try? Data(contentsOf: readingFile) { readingList = (try? dec.decode([ReadingItem].self, from: d)) ?? [] }
        recentSearches = UserDefaults.standard.stringArray(forKey: "browserSearches") ?? []
        let saved = UserDefaults.standard.stringArray(forKey: "browserTabs") ?? []
        for s in saved { openTab(url: URL(string: s), isPrivate: false, select: true) }
        if tabs.isEmpty { openTab(url: nil, isPrivate: false, select: true) }
    }

    // MARK: Hình nền trang bắt đầu

    /// Lưu ảnh nền (thu nhỏ còn tối đa 2200 px để nhẹ bộ nhớ)
    func setBackground(_ data: Data) {
        guard let src = CGImageSourceCreateWithData(data as CFData, nil) else { return }
        let o: [CFString: Any] = [
            kCGImageSourceCreateThumbnailFromImageAlways: true,
            kCGImageSourceCreateThumbnailWithTransform: true,
            kCGImageSourceThumbnailMaxPixelSize: 2200
        ]
        guard let cg = CGImageSourceCreateThumbnailAtIndex(src, 0, o as CFDictionary) else { return }
        let img = UIImage(cgImage: cg)
        if let jpg = img.jpegData(compressionQuality: 0.85) { try? jpg.write(to: backgroundFile, options: .atomic) }
        backgroundImage = img
    }

    func clearBackground() {
        try? FileManager.default.removeItem(at: backgroundFile)
        backgroundImage = nil
    }

    // MARK: Tab

    private func dataStore(private priv: Bool) -> WKWebsiteDataStore {
        if !priv { return .default() }
        if privateDataStore == nil { privateDataStore = .nonPersistent() }
        return privateDataStore!
    }

    @discardableResult
    func openTab(url: URL? = nil, isPrivate: Bool = false, select: Bool = true) -> BrowserTab {
        let t = BrowserTab(isPrivate: isPrivate, store: self, dataStore: dataStore(private: isPrivate))
        tabs.append(t)
        if select || currentID == nil { currentID = t.id }
        if let url { t.load(url.absoluteString) }
        saveTabs()
        return t
    }

    func select(_ t: BrowserTab) { currentID = t.id }

    func close(_ t: BrowserTab) {
        tabs.removeAll { $0.id == t.id }
        if !tabs.contains(where: { $0.isPrivate }) { privateDataStore = nil }   // hết tab riêng tư: bỏ toàn bộ dữ liệu tạm
        if tabs.isEmpty { openTab(url: nil, isPrivate: false, select: true) }
        else if currentID == t.id { currentID = tabs.last?.id }
        saveTabs()
    }

    func saveTabs() {
        let urls = tabs.filter { !$0.isPrivate }.compactMap { $0.webView.url?.absoluteString }
        UserDefaults.standard.set(urls, forKey: "browserTabs")
    }

    // MARK: Dấu trang

    func isBookmarked(_ url: String) -> Bool { bookmarks.contains { $0.url == url } }

    func toggleBookmark(title: String, url: String) {
        if let i = bookmarks.firstIndex(where: { $0.url == url }) { bookmarks.remove(at: i) }
        else { bookmarks.insert(Bookmark(title: title.isEmpty ? url : title, url: url), at: 0) }
        persist(bookmarks, to: bookmarksFile)
    }

    func removeBookmarks(at offsets: IndexSet) {
        bookmarks.remove(atOffsets: offsets)
        persist(bookmarks, to: bookmarksFile)
    }

    // MARK: Mục ưa thích, danh sách đọc, tìm kiếm gần đây

    func addFavorite(title: String, url: String) {
        guard !favorites.contains(where: { $0.url == url }) else { return }
        favorites.append(Favorite(title: title.isEmpty ? url : title, url: url))
        persist(favorites, to: favoritesFile)
    }

    func removeFavorite(_ f: Favorite) {
        favorites.removeAll { $0.id == f.id }
        persist(favorites, to: favoritesFile)
    }

    func addReading(title: String, url: String) {
        guard !readingList.contains(where: { $0.url == url }) else { return }
        readingList.insert(ReadingItem(title: title.isEmpty ? url : title, url: url), at: 0)
        persist(readingList, to: readingFile)
    }

    func removeReading(at offsets: IndexSet) {
        readingList.remove(atOffsets: offsets)
        persist(readingList, to: readingFile)
    }

    func recordSearch(_ q: String, isPrivate: Bool) {
        guard !isPrivate, !q.isEmpty else { return }
        recentSearches.removeAll { $0 == q }
        recentSearches.insert(q, at: 0)
        if recentSearches.count > 20 { recentSearches.removeLast(recentSearches.count - 20) }
        UserDefaults.standard.set(recentSearches, forKey: "browserSearches")
    }

    func clearSearches() {
        recentSearches = []
        UserDefaults.standard.set([String](), forKey: "browserSearches")
    }

    // MARK: Lịch sử

    func recordVisit(title: String, url: URL?, isPrivate: Bool) {
        guard !isPrivate, let url, ["http", "https"].contains(url.scheme?.lowercased() ?? "") else { return }
        if let first = history.first, first.url == url.absoluteString, Date().timeIntervalSince(first.date) < 5 { return }
        history.insert(HistoryEntry(title: title.isEmpty ? url.host ?? url.absoluteString : title, url: url.absoluteString, date: Date()), at: 0)
        if history.count > 3000 { history.removeLast(history.count - 3000) }
        persist(history, to: historyFile)
    }

    func removeHistory(_ e: HistoryEntry) {
        history.removeAll { $0.id == e.id }
        persist(history, to: historyFile)
    }

    func clearHistory() {
        history = []
        persist(history, to: historyFile)
    }

    /// Xóa lịch sử, cookie, bộ nhớ đệm và mọi dữ liệu trang web
    func clearAllBrowsingData() async {
        clearHistory()
        let types = WKWebsiteDataStore.allWebsiteDataTypes()
        await WKWebsiteDataStore.default().removeData(ofTypes: types, modifiedSince: Date(timeIntervalSince1970: 0))
    }

    private func persist<T: Encodable>(_ value: T, to url: URL) {
        let enc = JSONEncoder(); enc.dateEncodingStrategy = .iso8601
        guard let d = try? enc.encode(value) else { return }
        DispatchQueue.global(qos: .utility).async { try? d.write(to: url, options: .atomic) }
    }

    // MARK: Tải xuống từ trình duyệt

    func requestDownload(url: URL, suggested: String?, size: Int64, from tab: BrowserTab) {
        Task {
            let cookies = await tab.webView.configuration.websiteDataStore.httpCookieStore.allCookies()
            let host = url.host ?? ""
            let matching = cookies.filter { c in
                let d = c.domain.hasPrefix(".") ? String(c.domain.dropFirst()) : c.domain
                return host == d || host.hasSuffix("." + d)
            }
            var headers = HTTPCookie.requestHeaderFields(with: matching)
            if !tab.urlString.isEmpty { headers["Referer"] = tab.urlString }
            var name = (suggested ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
            if name.isEmpty { name = url.lastPathComponent }
            if name.isEmpty { name = "tai-xuong" }
            pendingDownload = PendingDownload(url: url, fileName: name, size: size, headers: headers)
        }
    }
}

// MARK: - Giao diện

struct WebViewRepresentable: UIViewRepresentable {
    let webView: WKWebView
    func makeUIView(context: Context) -> WKWebView { webView }
    func updateUIView(_ uiView: WKWebView, context: Context) {}
}

/// Màn hình trình duyệt. Mọi hộp thoại/cửa sổ trượt nằm ở đây (không bị dựng lại khi đổi tab).
struct BrowserView: View {
    @EnvironmentObject private var store: BrowserStore
    @State private var showTabs = false
    @State private var showBookmarks = false
    @State private var showHistory = false
    @State private var showDownloads = false
    @State private var showShare = false
    @State private var showAdBlock = false
    @State private var confirmClear = false
    @State private var toast: String?
    @State private var showPhotoPicker = false
    @State private var showLocalBackground = false
    @State private var pickedPhoto: PhotosPickerItem?

    var body: some View {
        NavigationStack {
            Group {
                if let tab = store.current {
                    BrowserPage(tab: tab, showTabs: $showTabs, showBookmarks: $showBookmarks, showHistory: $showHistory,
                                showDownloads: $showDownloads, showShare: $showShare, showAdBlock: $showAdBlock,
                                confirmClear: $confirmClear, toast: $toast,
                                showPhotoPicker: $showPhotoPicker, showLocalBackground: $showLocalBackground)
                        .id(tab.id)
                } else {
                    ProgressView()
                }
            }
            .toolbar(.hidden, for: .navigationBar)
        }
        .fullScreenCover(isPresented: $showTabs) { TabSwitcher(toast: $toast) }
        .sheet(isPresented: $showBookmarks) { if let t = store.current { BookmarksView(tab: t) } }
        .sheet(isPresented: $showHistory) { if let t = store.current { HistoryView(tab: t) } }
        .sheet(isPresented: $showDownloads) { NavigationStack { DownloadManagerView() } }
        .sheet(isPresented: $showAdBlock) { if let t = store.current { AdBlockSheetView(tab: t) } }
        .sheet(isPresented: $showShare) {
            if let t = store.current, let u = URL(string: t.urlString) { ActivityView(items: [u]) }
        }
        .sheet(item: $store.pendingDownload) { p in DownloadPromptView(pending: p) }
        .photosPicker(isPresented: $showPhotoPicker, selection: $pickedPhoto, matching: .images)
        .onChange(of: pickedPhoto) { _, item in
            guard let item else { return }
            Task {
                if let d = try? await item.loadTransferable(type: Data.self) {
                    store.setBackground(d)
                    toast = "Đã đổi hình nền trình duyệt"
                }
                pickedPhoto = nil
            }
        }
        .sheet(isPresented: $showLocalBackground) {
            LocalFilePickerSheet(rootTitle: "Chọn ảnh nền", icon: "photo", allowFolders: false,
                                 actionTitle: { $0 == 0 ? "Chọn một ảnh" : "Dùng ảnh đã chọn" }) { urls in
                if let u = urls.first(where: { Kind.detect($0, isDirectory: false) == .image }),
                   let d = try? Data(contentsOf: u) {
                    store.setBackground(d)
                    toast = "Đã đổi hình nền trình duyệt"
                } else {
                    toast = "Hãy chọn một tệp ảnh"
                }
            }
        }
        .confirmationDialog("Xóa lịch sử và dữ liệu duyệt web?", isPresented: $confirmClear, titleVisibility: .visible) {
            Button("Xóa lịch sử, cookie và bộ nhớ đệm", role: .destructive) {
                Task { await store.clearAllBrowsingData(); toast = "Đã xóa lịch sử và dữ liệu duyệt web" }
            }
            Button("Hủy", role: .cancel) {}
        } message: { Text("Dấu trang được giữ lại. Các trang đang đăng nhập sẽ bị đăng xuất.") }
        .toast($toast)
    }
}

enum HomeSection: Int, CaseIterable {
    case home, bookmarks, reading, history
}

// MARK: - Trang trình duyệt (bố cục kiểu Safari trên iPhone, thanh địa chỉ ở dưới)

struct BrowserPage: View {
    @ObservedObject var tab: BrowserTab
    @EnvironmentObject private var store: BrowserStore
    @ObservedObject private var adBlocker = AdBlockManager.shared
    @Binding var showTabs: Bool
    @Binding var showBookmarks: Bool
    @Binding var showHistory: Bool
    @Binding var showDownloads: Bool
    @Binding var showShare: Bool
    @Binding var showAdBlock: Bool
    @Binding var confirmClear: Bool
    @Binding var toast: String?
    @Binding var showPhotoPicker: Bool
    @Binding var showLocalBackground: Bool
    @FocusState private var focused: Bool
    @State private var text = ""
    @State private var section: HomeSection = .home

    private var accent: Color { tab.isPrivate ? .purple : Color.accentColor }
    private var bookmarked: Bool { store.isBookmarked(tab.urlString) }
    private var showHome: Bool { !tab.hasContent || focused }
    private var currentHost: String? { tab.hasContent ? AdBlockManager.normalizedHost(from: tab.urlString) : nil }
    private var adBlockActive: Bool { adBlocker.isAdBlockActive(for: currentHost) }
    private var popupBlockActive: Bool { adBlocker.isPopupBlockActive(for: currentHost) }

    var body: some View {
        ZStack(alignment: .bottom) {
            ZStack(alignment: .top) {
                WebViewRepresentable(webView: tab.webView)
                if let e = tab.errorText, tab.hasContent, !focused { errorView(e) }
                if showHome {
                    BrowserHome(tab: tab, section: $section, searching: focused, query: text,
                                onOpen: { open($0) }, onFill: { text = $0 },
                                showPhotoPicker: $showPhotoPicker, showLocalBackground: $showLocalBackground)
                        .transition(.opacity)
                }
                ProgressView(value: tab.progress)
                    .tint(accent)
                    .opacity(tab.isLoading && !showHome ? 1 : 0)
                    .frame(height: 2)
                    .allowsHitTesting(false)
            }
            .clipped()
            .animation(.easeInOut(duration: 0.2), value: showHome)

            bottomBar
        }
        .background(Color(.systemBackground))
        .tint(accent)
        .onChange(of: focused) { _, f in
            if f {
                text = tab.hasContent ? tab.urlString : ""
                section = .home
            }
        }
    }

    // MARK: Hành động

    private func open(_ input: String) {
        let t = input.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !t.isEmpty else { return }
        tab.load(t)
        closeSearch()
    }

    private func closeSearch() {
        focused = false
        text = ""
        section = .home
    }

    // MARK: Thanh dưới bằng kính lỏng

    private var bottomBar: some View {
        GlassGroup(spacing: 10) {
            HStack(spacing: 10) {
                if !focused {
                    Button {
                        if tab.canGoBack {
                            tab.goBack()
                        } else if tab.hasContent {
                            tab.goHome()
                        }
                    } label: {
                        Image(systemName: "chevron.left")
                            .font(.system(size: 18, weight: .semibold))
                            .foregroundStyle(.primary)
                            .glassCircle(size: 52)
                            .contentShape(Circle())
                    }
                    .buttonStyle(.plain)
                    .disabled(!tab.canGoBack && !tab.hasContent)
                    .opacity((tab.canGoBack || tab.hasContent) ? 1 : 0.45)
                }

                addressField

                if focused {
                    Button { closeSearch() } label: {
                        Image(systemName: "xmark")
                            .font(.system(size: 18, weight: .medium))
                            .foregroundStyle(.primary)
                            .glassCircle(size: 52)
                            .contentShape(Circle())
                    }
                    .buttonStyle(.plain)
                } else {
                    tabsButton
                    menu
                }
            }
        }
        .padding(.horizontal, 12).padding(.top, 4).padding(.bottom, 6)
    }

    private var fieldIcon: String {
        if tab.isPrivate { return "hand.raised.fill" }
        if focused || !tab.hasContent { return "magnifyingglass" }
        return tab.isSecure ? "lock.fill" : "globe"
    }

    private var addressField: some View {
        HStack(spacing: 8) {
            Image(systemName: fieldIcon)
                .font(.system(size: 15, weight: .semibold))
                .foregroundStyle(tab.isPrivate ? Color.purple : Color.secondary)
            TextField(focused ? "Tìm kiếm hoặc nhập tên trang web" : "Tìm hoặc nhập tên web",
                      text: Binding(get: { focused ? text : (tab.hasContent ? tab.displayHost : "") },
                                    set: { text = $0 }))
                .focused($focused)
                .keyboardType(.webSearch)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
                .submitLabel(.go)
                .lineLimit(1)
                .multilineTextAlignment(focused || !tab.hasContent ? .leading : .center)
                .onSubmit { open(text) }
            fieldTrailing
        }
        .padding(.horizontal, 16)
        .frame(height: 52)
        .glassCapsule()
        .overlay(alignment: .bottom) {
            if tab.isLoading && !focused && tab.hasContent {
                ProgressView(value: tab.progress).tint(accent).padding(.horizontal, 26).offset(y: -3)
                    .allowsHitTesting(false)
            }
        }
    }

    @ViewBuilder private var fieldTrailing: some View {
        if focused {
            if !text.isEmpty {
                Button { text = "" } label: { Image(systemName: "xmark.circle.fill").foregroundStyle(.secondary) }
                    .buttonStyle(.plain)
            }
        } else if tab.hasContent {
            if tab.isLoading {
                Button { tab.stop() } label: { Image(systemName: "xmark").font(.footnote.weight(.semibold)) }
                    .buttonStyle(.plain)
            } else {
                Button { tab.reload() } label: { Image(systemName: "arrow.clockwise").font(.footnote.weight(.semibold)) }
                    .buttonStyle(.plain)
            }
        }
    }

    private var tabsButton: some View {
        Button {
            Task { await tab.takeSnapshot(); showTabs = true }
        } label: {
            ZStack(alignment: .topTrailing) {
                Image(systemName: "square.on.square").font(.system(size: 18, weight: .medium)).foregroundStyle(.primary)
                if store.tabs.count > 1 {
                    Text("\(store.tabs.count)")
                        .font(.system(size: 9, weight: .bold)).foregroundStyle(.white)
                        .padding(.horizontal, 4).padding(.vertical, 1)
                        .background(accent, in: Capsule())
                        .offset(x: 10, y: -8)
                }
            }
            .glassCircle(size: 52)
        }
        .buttonStyle(.plain)
    }

    private var menu: some View {
        Menu {
            Button { store.openTab(isPrivate: false, select: true) } label: { Label("Tab mới", systemImage: "plus.square") }
            Button { store.openTab(isPrivate: true, select: true) } label: { Label("Tab riêng tư mới", systemImage: "hand.raised") }
            Button(role: .destructive) { store.close(tab) } label: { Label("Đóng tab này", systemImage: "xmark.square") }
            Divider()
            Button {
                store.toggleBookmark(title: tab.title, url: tab.urlString)
                toast = bookmarked ? "Đã bỏ dấu trang" : "Đã thêm dấu trang"
            } label: {
                Label(bookmarked ? "Bỏ dấu trang" : "Thêm dấu trang", systemImage: bookmarked ? "bookmark.slash" : "bookmark")
            }
            .disabled(!tab.hasContent)
            Button {
                store.addReading(title: tab.title, url: tab.urlString)
                toast = "Đã thêm vào Danh sách đọc"
            } label: { Label("Thêm vào Danh sách đọc", systemImage: "eyeglasses") }
                .disabled(!tab.hasContent)
            Button {
                store.addFavorite(title: tab.title, url: tab.urlString)
                toast = "Đã thêm vào Mục ưa thích"
            } label: { Label("Thêm vào Mục ưa thích", systemImage: "star") }
                .disabled(!tab.hasContent)
            Button { showBookmarks = true } label: { Label("Dấu trang", systemImage: "book") }
            Button { showHistory = true } label: { Label("Lịch sử", systemImage: "clock") }
            Button { showDownloads = true } label: { Label("Tải xuống", systemImage: "arrow.down.circle") }

            // Menu con Chặn quảng cáo (kiểu mũi tên xuống giống Hình nền trang bắt đầu)
            Menu {
                Button {
                    let next = !adBlockActive
                    if let host = currentHost {
                        adBlocker.setAdBlock(next, for: host)
                        tab.reload()
                        toast = next ? "Đã bật chặn quảng cáo trên \(host)" : "Đã tắt chặn quảng cáo trên \(host)"
                    } else {
                        adBlocker.adBlockEnabled = next
                        toast = next ? "Đã bật chặn quảng cáo" : "Đã tắt chặn quảng cáo"
                    }
                } label: {
                    Label(
                        currentHost != nil ? "Chặn quảng cáo trên trang này" : "Chặn quảng cáo trên trang",
                        systemImage: adBlockActive ? "checkmark.circle.fill" : "circle"
                    )
                }

                Button {
                    let next = !popupBlockActive
                    if let host = currentHost {
                        adBlocker.setPopupBlock(next, for: host)
                        tab.reload()
                        toast = next ? "Đã bật chặn popup trên \(host)" : "Đã tắt chặn popup trên \(host)"
                    } else {
                        adBlocker.popupBlockEnabled = next
                        toast = next ? "Đã bật chặn cửa sổ bật lên" : "Đã tắt chặn cửa sổ bật lên"
                    }
                } label: {
                    Label(
                        currentHost != nil ? "Chặn cửa sổ bật lên từ trang này" : "Chặn cửa sổ bật lên (Popup)",
                        systemImage: popupBlockActive ? "checkmark.circle.fill" : "circle"
                    )
                }

                Divider()

                Button {
                    showAdBlock = true
                } label: {
                    let count = currentHost != nil
                        ? (tab.blockedAdsOnPage + tab.blockedPopupsOnPage)
                        : (adBlocker.totalBlockedAds + adBlocker.totalBlockedPopups)
                    Label(
                        count > 0 ? "Kiểm tra & Cài đặt (\(count) đã chặn)" : "Kiểm tra & Cài đặt chặn",
                        systemImage: "slider.horizontal.3"
                    )
                }
            } label: {
                Label(
                    "Chặn quảng cáo",
                    systemImage: (adBlockActive || popupBlockActive) ? "checkmark.shield" : "shield.slash"
                )
            }

            Menu {
                Button { showPhotoPicker = true } label: { Label("Chọn từ thư viện ảnh", systemImage: "photo.on.rectangle") }
                Button { showLocalBackground = true } label: { Label("Chọn từ Jinn Files", systemImage: "folder") }
                if store.backgroundImage != nil {
                    Button(role: .destructive) { store.clearBackground() } label: { Label("Xóa hình nền", systemImage: "trash") }
                }
            } label: { Label("Hình nền trang bắt đầu", systemImage: "paintbrush") }
            Divider()
            Button { showShare = true } label: { Label("Chia sẻ trang", systemImage: "square.and.arrow.up") }
                .disabled(!tab.hasContent)
            Button { tab.toggleDesktop() } label: {
                Label(tab.desktopMode ? "Trang cho di động" : "Trang cho máy tính", systemImage: tab.desktopMode ? "iphone" : "desktopcomputer")
            }
            Divider()
            Button(role: .destructive) { confirmClear = true } label: { Label("Xóa lịch sử và dữ liệu", systemImage: "trash") }
        } label: {
            Image(systemName: "ellipsis").font(.system(size: 18, weight: .semibold))
                .foregroundStyle(.primary).glassCircle(size: 52)
        }
    }

    private func errorView(_ e: String) -> some View {
        VStack(spacing: 12) {
            Image(systemName: "wifi.exclamationmark").font(.largeTitle).foregroundStyle(.secondary)
            Text("Không mở được trang").font(.headline)
            Text(e).font(.footnote).foregroundStyle(.secondary).multilineTextAlignment(.center)
            Button("Thử lại") { tab.reload() }.glassButtonStyle(prominent: true)
        }
        .padding(24)
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Color(.systemBackground))
    }
}

// MARK: - Biểu tượng trang web

struct FaviconView: View {
    let url: String
    let title: String
    var color: Color = .accentColor
    var size: CGFloat = 58

    private var faviconURL: URL? {
        guard let host = URL(string: url)?.host else { return nil }
        return URL(string: "https://www.google.com/s2/favicons?sz=128&domain=\(host)")
    }

    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: size * 0.26, style: .continuous).fill(Color.white)
            AsyncImage(url: faviconURL) { phase in
                switch phase {
                case .success(let img):
                    img.resizable().scaledToFit().padding(size * 0.2)
                default:
                    Text(String(title.prefix(1)).uppercased())
                        .font(.system(size: size * 0.42, weight: .bold)).foregroundStyle(color)
                }
            }
        }
        .frame(width: size, height: size)
        .shadow(color: .black.opacity(0.14), radius: 3, y: 1)
    }
}

// MARK: - Thanh chuyển mục (Ưa thích/Tìm kiếm, Dấu trang, Danh sách đọc, Lịch sử)

struct HomeSegmented: View {
    @Binding var section: HomeSection
    let searching: Bool

    private func icon(_ s: HomeSection) -> String {
        switch s {
        case .home: return searching ? "magnifyingglass" : "circle.grid.3x3.fill"
        case .bookmarks: return "book"
        case .reading: return "eyeglasses"
        case .history: return "clock"
        }
    }

    var body: some View {
        GlassGroup(spacing: 6) {
            HStack(spacing: 0) {
                ForEach(HomeSection.allCases, id: \.self) { s in
                    Button {
                        withAnimation(.easeInOut(duration: 0.2)) { section = s }
                    } label: {
                        Image(systemName: icon(s))
                            .font(.system(size: 19, weight: .medium))
                            .foregroundStyle(.primary)
                            .frame(maxWidth: .infinity, minHeight: 46)
                            .background {
                                if section == s { Capsule().fill(Color.primary.opacity(0.14)) }
                            }
                            .contentShape(Capsule())
                    }
                    .buttonStyle(.plain)
                }
            }
            .padding(4)
            .glassCapsule()
        }
    }
}

// MARK: - Trang chủ trình duyệt và màn hình tìm kiếm

struct BrowserHome: View {
    @ObservedObject var tab: BrowserTab
    @EnvironmentObject private var store: BrowserStore
    @Binding var section: HomeSection
    let searching: Bool
    let query: String
    let onOpen: (String) -> Void
    let onFill: (String) -> Void
    @Binding var showPhotoPicker: Bool
    @Binding var showLocalBackground: Bool

    @State private var editing = false
    @State private var showAllFavorites = false
    @State private var showAddFavorite = false
    @State private var newTitle = ""
    @State private var newURL = ""

    private var dark: Bool { tab.isPrivate || store.backgroundImage != nil }

    var body: some View {
        Group {
            if dark { content.environment(\.colorScheme, .dark) } else { content }
        }
    }

    private var content: some View {
        VStack(spacing: 0) {
            HomeSegmented(section: $section, searching: searching)
                .padding(.horizontal, 16).padding(.top, 8).padding(.bottom, 6)
            Group {
                switch section {
                case .home:
                    if searching { searchContent } else { favoritesContent }
                case .bookmarks: bookmarksList
                case .reading: readingList
                case .history: historyList
                }
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background { backgroundLayer }
    }

    private var backgroundLayer: some View {
        ZStack {
            if let img = store.backgroundImage {
                Color.clear.overlay { Image(uiImage: img).resizable().scaledToFill() }.clipped()
                Color.black.opacity(0.32)
            } else if tab.isPrivate {
                LinearGradient(colors: [Color(red: 0.14, green: 0.09, blue: 0.26), Color(red: 0.05, green: 0.04, blue: 0.11)],
                               startPoint: .top, endPoint: .bottom)
            } else {
                AppBackground()
            }
        }
        .ignoresSafeArea()
        .allowsHitTesting(false)
    }

    // MARK: Mục ưa thích

    private var visibleFavorites: [Favorite] {
        showAllFavorites ? store.favorites : Array(store.favorites.prefix(8))
    }

    private var favoritesContent: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                if tab.isPrivate { privateBanner }
                HStack {
                    Text("Mục ưa thích").font(.title2.bold())
                    Spacer()
                    if store.favorites.count > 8 {
                        Button { withAnimation { showAllFavorites.toggle() } } label: {
                            HStack(spacing: 3) {
                                Text(showAllFavorites ? "Thu gọn" : "Hiển thị tất cả")
                                Image(systemName: showAllFavorites ? "chevron.up" : "chevron.right")
                            }
                            .font(.subheadline.weight(.medium))
                        }
                        .buttonStyle(.plain)
                    }
                }
                LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 12), count: 4), spacing: 18) {
                    ForEach(visibleFavorites) { f in favoriteTile(f) }
                    if editing { addTile }
                }
                HStack {
                    Spacer()
                    Button { withAnimation { editing.toggle() } } label: {
                        Text(editing ? "Xong" : "Sửa").font(.headline).padding(.horizontal, 28).padding(.vertical, 12)
                    }
                    .buttonStyle(.plain)
                    .glassCapsule()
                    Spacer()
                }
                if editing { wallpaperRow }
                if !store.bookmarks.isEmpty && !editing { bookmarksPreview }
            }
            .padding(.horizontal, 18).padding(.top, 14).padding(.bottom, 140)
        }
        .alert("Thêm vào Mục ưa thích", isPresented: $showAddFavorite) {
            TextField("Tên", text: $newTitle)
            TextField("Địa chỉ (ví dụ: example.com)", text: $newURL)
                .textInputAutocapitalization(.never).autocorrectionDisabled().keyboardType(.URL)
            Button("Hủy", role: .cancel) {}
            Button("Thêm") {
                if let u = BrowserTab.resolve(newURL), !(u.host ?? "").isEmpty, !newURL.contains(" ") {
                    store.addFavorite(title: newTitle.isEmpty ? (u.host ?? newURL) : newTitle, url: u.absoluteString)
                }
            }
        }
    }

    private func favoriteTile(_ f: Favorite) -> some View {
        ZStack(alignment: .topLeading) {
            Button { onOpen(f.url) } label: {
                VStack(spacing: 8) {
                    FaviconView(url: f.url, title: f.title, color: .accentColor, size: 76)
                    Text(f.title).font(.footnote).lineLimit(2).multilineTextAlignment(.center)
                        .foregroundStyle(.primary).frame(maxWidth: .infinity)
                }
            }
            .buttonStyle(.plain)
            .disabled(editing)
            if editing {
                Button { withAnimation { store.removeFavorite(f) } } label: {
                    Image(systemName: "minus.circle.fill").font(.title3)
                        .symbolRenderingMode(.palette).foregroundStyle(.white, .red)
                }
                .buttonStyle(.plain)
                .offset(x: -4, y: -4)
            }
        }
    }

    private var addTile: some View {
        Button { newTitle = ""; newURL = ""; showAddFavorite = true } label: {
            VStack(spacing: 8) {
                RoundedRectangle(cornerRadius: 76 * 0.26, style: .continuous)
                    .strokeBorder(Color.primary.opacity(0.4), style: StrokeStyle(lineWidth: 1.5, dash: [5]))
                    .frame(width: 76, height: 76)
                    .overlay(Image(systemName: "plus").font(.title2).foregroundStyle(.primary))
                Text("Thêm").font(.footnote).foregroundStyle(.primary)
            }
        }
        .buttonStyle(.plain)
    }

    private var wallpaperRow: some View {
        Menu {
            Button { showPhotoPicker = true } label: { Label("Chọn từ thư viện ảnh", systemImage: "photo.on.rectangle") }
            Button { showLocalBackground = true } label: { Label("Chọn từ Jinn Files", systemImage: "folder") }
            if store.backgroundImage != nil {
                Button(role: .destructive) { store.clearBackground() } label: { Label("Xóa hình nền", systemImage: "trash") }
            }
        } label: {
            HStack {
                Image(systemName: "paintbrush.pointed.fill")
                Text("Đổi hình nền trang bắt đầu").font(.subheadline.weight(.medium))
                Spacer()
                Image(systemName: "chevron.up.chevron.down").font(.caption)
            }
            .foregroundStyle(.primary)
            .padding(.horizontal, 16).padding(.vertical, 14)
            .frame(maxWidth: .infinity)
            .glassSurface(cornerRadius: 22, interactive: true)
        }
    }

    private var privateBanner: some View {
        HStack(spacing: 12) {
            Image(systemName: "hand.raised.fill").font(.title2).foregroundStyle(.purple)
            VStack(alignment: .leading, spacing: 2) {
                Text("Chế độ duyệt riêng tư").font(.headline)
                Text("Lịch sử, cookie và tìm kiếm của tab riêng tư không được lưu. Tệp tải xuống vẫn nằm trong Jinn Files.")
                    .font(.caption).foregroundStyle(.secondary)
            }
        }
        .padding(14).frame(maxWidth: .infinity, alignment: .leading)
        .glassSurface(cornerRadius: 20)
    }

    private var bookmarksPreview: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Text("Dấu trang").font(.title2.bold())
                Spacer()
                Button { withAnimation { section = .bookmarks } } label: {
                    HStack(spacing: 3) { Text("Hiển thị tất cả"); Image(systemName: "chevron.right") }
                        .font(.subheadline.weight(.medium))
                }
                .buttonStyle(.plain)
            }
            LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 12), count: 4), spacing: 16) {
                ForEach(store.bookmarks.prefix(8)) { b in
                    Button { onOpen(b.url) } label: {
                        VStack(spacing: 6) {
                            FaviconView(url: b.url, title: b.title, size: 60)
                            Text(b.title).font(.caption).lineLimit(2).multilineTextAlignment(.center)
                                .foregroundStyle(.primary).frame(maxWidth: .infinity)
                        }
                    }
                    .buttonStyle(.plain)
                }
            }
        }
    }

    // MARK: Tìm kiếm (khi bấm vào thanh địa chỉ)

    private var matches: [(title: String, url: String, icon: String)] {
        let q = query.trimmingCharacters(in: .whitespaces).lowercased()
        guard !q.isEmpty else { return [] }
        var out: [(title: String, url: String, icon: String)] = []
        var seen = Set<String>()
        for b in store.bookmarks where (b.title + " " + b.url).lowercased().contains(q) && seen.insert(b.url).inserted {
            out.append((b.title, b.url, "book"))
        }
        for h in store.history where (h.title + " " + h.url).lowercased().contains(q) && seen.insert(h.url).inserted {
            out.append((h.title, h.url, "clock"))
        }
        return Array(out.prefix(6))
    }

    private var searchContent: some View {
        ScrollView {
            LazyVStack(alignment: .leading, spacing: 0) {
                let q = query.trimmingCharacters(in: .whitespaces)
                if q.isEmpty {
                    if store.recentSearches.isEmpty {
                        Text("Chưa có tìm kiếm gần đây").font(.subheadline).foregroundStyle(.secondary).padding(.top, 20)
                    } else {
                        HStack {
                            Text("Tìm kiếm gần đây").font(.headline).foregroundStyle(.secondary)
                            Spacer()
                            Button("Xóa tất cả") { store.clearSearches() }.foregroundStyle(.secondary)
                        }
                        .padding(.top, 14).padding(.bottom, 4)
                        ForEach(store.recentSearches, id: \.self) { s in
                            suggestionRow(icon: "magnifyingglass", title: s, subtitle: nil, fill: s) { onOpen(s) }
                            Divider().opacity(0.4)
                        }
                    }
                } else {
                    suggestionRow(icon: "magnifyingglass", title: "Tìm “\(q)” trên Google", subtitle: nil, fill: q) { onOpen(q) }
                    Divider().opacity(0.4)
                    ForEach(Array(matches.enumerated()), id: \.offset) { _, m in
                        suggestionRow(icon: m.icon, title: m.title, subtitle: m.url, fill: m.url) { onOpen(m.url) }
                        Divider().opacity(0.4)
                    }
                }
            }
            .padding(.horizontal, 18).padding(.bottom, 140)
        }
        .scrollDismissesKeyboard(.never)
    }

    private func suggestionRow(icon: String, title: String, subtitle: String?, fill: String,
                               open: @escaping () -> Void) -> some View {
        HStack(spacing: 10) {
            Button(action: open) {
                HStack(spacing: 14) {
                    Image(systemName: icon).font(.title3).foregroundStyle(.primary).frame(width: 28)
                    VStack(alignment: .leading, spacing: 2) {
                        Text(title).lineLimit(1).foregroundStyle(.primary)
                        if let subtitle { Text(subtitle).font(.caption).foregroundStyle(.secondary).lineLimit(1) }
                    }
                    Spacer(minLength: 0)
                }
                .padding(.vertical, 14)
                .contentShape(Rectangle())
            }
            .buttonStyle(.plain)
            Button { onFill(fill) } label: {
                Image(systemName: "arrow.up.left.circle").font(.title2).foregroundStyle(.secondary)
            }
            .buttonStyle(.plain)
        }
    }

    // MARK: Dấu trang, Danh sách đọc, Lịch sử

    private func linkRow(title: String, url: String, onTap: @escaping () -> Void) -> some View {
        Button(action: onTap) {
            HStack(spacing: 12) {
                FaviconView(url: url, title: title, size: 38)
                VStack(alignment: .leading, spacing: 2) {
                    Text(title).lineLimit(1).foregroundStyle(.primary)
                    Text(url).font(.caption).foregroundStyle(.secondary).lineLimit(1)
                }
                Spacer(minLength: 0)
            }
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .listRowBackground(Color.clear)
    }

    private func emptyHint(_ title: String, _ detail: String) -> some View {
        VStack(spacing: 6) {
            Text(title).font(.headline)
            Text(detail).font(.footnote).foregroundStyle(.secondary).multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity).padding(.top, 40)
        .listRowBackground(Color.clear).listRowSeparator(.hidden)
    }

    private var bookmarksList: some View {
        List {
            if store.bookmarks.isEmpty { emptyHint("Chưa có dấu trang", "Mở một trang rồi chọn ⋯ → Thêm dấu trang.") }
            ForEach(store.bookmarks) { b in linkRow(title: b.title, url: b.url) { onOpen(b.url) } }
                .onDelete { store.removeBookmarks(at: $0) }
        }
        .listStyle(.plain).scrollContentBackground(.hidden)
        .contentMargins(.bottom, 140, for: .scrollContent)
    }

    private var readingList: some View {
        List {
            if store.readingList.isEmpty { emptyHint("Danh sách đọc trống", "Mở một trang rồi chọn ⋯ → Thêm vào Danh sách đọc.") }
            ForEach(store.readingList) { r in linkRow(title: r.title, url: r.url) { onOpen(r.url) } }
                .onDelete { store.removeReading(at: $0) }
        }
        .listStyle(.plain).scrollContentBackground(.hidden)
        .contentMargins(.bottom, 140, for: .scrollContent)
    }

    private var historyDays: [(Date, [HistoryEntry])] {
        let groups = Dictionary(grouping: store.history) { Calendar.current.startOfDay(for: $0.date) }
        return groups.keys.sorted(by: >).map { ($0, groups[$0] ?? []) }
    }

    private var historyList: some View {
        List {
            if store.history.isEmpty { emptyHint("Chưa có lịch sử", "Các trang bạn truy cập (ngoài chế độ riêng tư) sẽ hiện ở đây.") }
            ForEach(historyDays, id: \.0) { day, entries in
                Section(day.formatted(.dateTime.day().month(.wide).year().locale(Locale(identifier: "vi_VN")))) {
                    ForEach(entries) { e in
                        linkRow(title: e.title, url: e.url) { onOpen(e.url) }
                            .swipeActions { Button(role: .destructive) { store.removeHistory(e) } label: { Label("Xóa", systemImage: "trash") } }
                    }
                }
            }
            if !store.history.isEmpty {
                Button(role: .destructive) { store.clearHistory() } label: {
                    Label("Xóa toàn bộ lịch sử", systemImage: "trash").frame(maxWidth: .infinity)
                }
                .listRowBackground(Color.clear)
            }
        }
        .listStyle(.plain).scrollContentBackground(.hidden)
        .contentMargins(.bottom, 140, for: .scrollContent)
    }
}

// MARK: - Chuyển tab

struct TabSwitcher: View {
    @EnvironmentObject private var store: BrowserStore
    @Environment(\.dismiss) private var dismiss
    @Binding var toast: String?
    @State private var showPrivate = false
    @State private var didInit = false

    private var shown: [BrowserTab] { store.tabs.filter { $0.isPrivate == showPrivate } }

    var body: some View {
        NavigationStack {
            ScrollView {
                Picker("Loại tab", selection: $showPrivate) {
                    Label("Thường", systemImage: "square.on.square").tag(false)
                    Label("Riêng tư", systemImage: "hand.raised.fill").tag(true)
                }
                .pickerStyle(.segmented).padding()

                if shown.isEmpty {
                    ContentUnavailableView(showPrivate ? "Chưa có tab riêng tư" : "Chưa có tab", systemImage: showPrivate ? "hand.raised" : "square.on.square",
                                           description: Text(showPrivate ? "Tab riêng tư không lưu lịch sử và cookie." : "Bấm nút bên dưới để mở tab mới."))
                        .padding(.top, 20)
                }
                LazyVGrid(columns: [GridItem(.flexible(), spacing: 12), GridItem(.flexible(), spacing: 12)], spacing: 14) {
                    ForEach(shown) { t in card(t) }
                }
                .padding(.horizontal, 12).padding(.bottom, 90)
            }
            .background(AppBackground())
            .navigationTitle(showPrivate ? "Tab riêng tư" : "Các tab")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Menu {
                        Button(role: .destructive) { closeAll() } label: {
                            Label(showPrivate ? "Đóng tất cả tab riêng tư" : "Đóng tất cả tab thường", systemImage: "xmark.square")
                        }
                        .disabled(shown.isEmpty)
                    } label: { Image(systemName: "ellipsis.circle") }
                }
                ToolbarItem(placement: .topBarTrailing) { Button("Xong") { dismiss() } }
            }
            .safeAreaInset(edge: .bottom) {
                Button { newTab() } label: {
                    Label(showPrivate ? "Tab riêng tư mới" : "Tab mới", systemImage: "plus").frame(maxWidth: .infinity)
                }
                .glassButtonStyle(prominent: true).controlSize(.large)
                .tint(showPrivate ? .purple : Color.accentColor)
                .padding()
            }
            .onAppear {
                if !didInit { showPrivate = store.current?.isPrivate ?? false; didInit = true }
            }
        }
    }

    private func newTab() {
        store.openTab(isPrivate: showPrivate, select: true)
        toast = showPrivate ? "Đã mở tab riêng tư" : nil
        dismiss()
    }

    private func closeAll() {
        for t in shown { store.close(t) }
    }

    private func card(_ t: BrowserTab) -> some View {
        ZStack(alignment: .topTrailing) {
            VStack(spacing: 0) {
                Group {
                    if let img = t.snapshot {
                        Image(uiImage: img).resizable().scaledToFill()
                    } else {
                        ZStack {
                            Color(.tertiarySystemBackground)
                            Image(systemName: t.isPrivate ? "hand.raised.fill" : "globe").font(.largeTitle)
                                .foregroundStyle(t.isPrivate ? Color.purple : Color.secondary)
                        }
                    }
                }
                .frame(height: 150).frame(maxWidth: .infinity).clipped()
                HStack(spacing: 6) {
                    Image(systemName: t.isPrivate ? "hand.raised.fill" : "globe").font(.caption2)
                        .foregroundStyle(t.isPrivate ? Color.purple : Color.secondary)
                    Text(t.title).font(.caption.weight(.semibold)).lineLimit(1)
                    Spacer(minLength: 0)
                }
                .padding(.horizontal, 10).padding(.vertical, 8)
            }
            .background(Color(.secondarySystemBackground))
            .clipShape(RoundedRectangle(cornerRadius: 16))
            .overlay(RoundedRectangle(cornerRadius: 16)
                .stroke(t.id == store.current?.id ? (t.isPrivate ? Color.purple : Color.accentColor) : Color.clear, lineWidth: 2.5))
            .contentShape(RoundedRectangle(cornerRadius: 16))
            .onTapGesture { store.select(t); dismiss() }

            // Nút đóng nằm tách riêng, không nằm bên trong nút chọn tab
            Button {
                withAnimation { store.close(t) }
            } label: {
                Image(systemName: "xmark.circle.fill")
                    .font(.title2)
                    .symbolRenderingMode(.palette)
                    .foregroundStyle(.white, Color.black.opacity(0.6))
                    .padding(6)
            }
            .buttonStyle(.plain)
        }
    }
}

// MARK: - Dấu trang và lịch sử

struct BookmarksView: View {
    @ObservedObject var tab: BrowserTab
    @EnvironmentObject private var store: BrowserStore
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            List {
                if store.bookmarks.isEmpty {
                    ContentUnavailableView("Chưa có dấu trang", systemImage: "bookmark",
                                           description: Text("Mở một trang rồi chọn ⋯ → Thêm dấu trang."))
                }
                ForEach(store.bookmarks) { b in
                    Button { tab.load(b.url); dismiss() } label: {
                        VStack(alignment: .leading, spacing: 2) {
                            Text(b.title).lineLimit(1).foregroundStyle(.primary)
                            Text(b.url).font(.caption).foregroundStyle(.secondary).lineLimit(1)
                        }
                    }
                }
                .onDelete { store.removeBookmarks(at: $0) }
            }
            .navigationTitle("Dấu trang")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .topBarTrailing) { Button("Xong") { dismiss() } } }
        }
    }
}

struct HistoryView: View {
    @ObservedObject var tab: BrowserTab
    @EnvironmentObject private var store: BrowserStore
    @Environment(\.dismiss) private var dismiss
    @State private var query = ""
    @State private var confirmClear = false

    private var filtered: [HistoryEntry] {
        query.isEmpty ? store.history : store.history.filter {
            $0.title.localizedCaseInsensitiveContains(query) || $0.url.localizedCaseInsensitiveContains(query)
        }
    }

    private var days: [(Date, [HistoryEntry])] {
        let groups = Dictionary(grouping: filtered) { Calendar.current.startOfDay(for: $0.date) }
        return groups.keys.sorted(by: >).map { ($0, groups[$0] ?? []) }
    }

    var body: some View {
        NavigationStack {
            List {
                if filtered.isEmpty {
                    ContentUnavailableView("Chưa có lịch sử", systemImage: "clock", description: Text("Các trang bạn truy cập (ngoài chế độ riêng tư) sẽ hiện ở đây."))
                }
                ForEach(days, id: \.0) { day, entries in
                    Section(day.formatted(.dateTime.day().month(.wide).year().locale(Locale(identifier: "vi_VN")))) {
                        ForEach(entries) { e in
                            Button { tab.load(e.url); dismiss() } label: {
                                VStack(alignment: .leading, spacing: 2) {
                                    Text(e.title).lineLimit(1).foregroundStyle(.primary)
                                    Text(e.url).font(.caption).foregroundStyle(.secondary).lineLimit(1)
                                }
                            }
                            .swipeActions { Button(role: .destructive) { store.removeHistory(e) } label: { Label("Xóa", systemImage: "trash") } }
                        }
                    }
                }
            }
            .searchable(text: $query, prompt: "Tìm trong lịch sử")
            .navigationTitle("Lịch sử")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) { Button("Xóa tất cả", role: .destructive) { confirmClear = true }.disabled(store.history.isEmpty) }
                ToolbarItem(placement: .topBarTrailing) { Button("Xong") { dismiss() } }
            }
            .confirmationDialog("Xóa toàn bộ lịch sử?", isPresented: $confirmClear, titleVisibility: .visible) {
                Button("Xóa lịch sử", role: .destructive) { store.clearHistory() }
                Button("Hủy", role: .cancel) {}
            }
        }
    }
}
