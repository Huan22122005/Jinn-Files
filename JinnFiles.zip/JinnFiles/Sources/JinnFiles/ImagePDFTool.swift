import SwiftUI
import PDFKit
import UIKit

// MARK: - Xử lý

enum ImagePDFOps {
    /// Ghép nhiều ảnh thành một tệp PDF (mỗi ảnh một trang)
    static func makePDF(images: [URL], pageSize: Int, to out: URL, progress: @escaping (Double) -> Void) throws {
        let a4 = CGRect(x: 0, y: 0, width: 595.2, height: 841.8)
        let letter = CGRect(x: 0, y: 0, width: 612, height: 792)
        let base: CGRect? = pageSize == 1 ? a4 : (pageSize == 2 ? letter : nil)

        let renderer = UIGraphicsPDFRenderer(bounds: CGRect(x: 0, y: 0, width: 595.2, height: 841.8))
        var failed = 0
        try renderer.writePDF(to: out) { ctx in
            for (i, u) in images.enumerated() {
                autoreleasepool {
                    guard let img = Thumbs.downsample(u, maxPixel: 2600) else { failed += 1; return }
                    let w = img.size.width, h = img.size.height
                    guard w > 0, h > 0 else { failed += 1; return }
                    var page: CGRect
                    var inset: CGFloat = 0
                    if let base {
                        page = w > h ? CGRect(x: 0, y: 0, width: base.height, height: base.width) : base   // ảnh ngang -> trang ngang
                        inset = 24
                    } else {
                        page = CGRect(x: 0, y: 0, width: 595, height: 595 * h / w)                          // trang khớp tỷ lệ ảnh
                    }
                    ctx.beginPage(withBounds: page, pageInfo: [:])
                    let avail = page.insetBy(dx: inset, dy: inset)
                    let s = min(avail.width / w, avail.height / h)
                    let dw = w * s, dh = h * s
                    img.draw(in: CGRect(x: avail.midX - dw / 2, y: avail.midY - dh / 2, width: dw, height: dh))
                }
                progress(Double(i + 1) / Double(images.count))
            }
        }
        if failed == images.count { throw AppError("Không đọc được ảnh nào để tạo PDF.") }
    }

    /// Xuất mỗi trang PDF thành một ảnh, trả về số ảnh đã tạo
    static func renderPDF(_ url: URL, password: String?, longSide: CGFloat, jpeg: Bool, into dir: URL,
                          progress: @escaping (Double) -> Void) throws -> Int {
        guard let doc = PDFDocument(url: url) else { throw AppError("Không đọc được tệp PDF.") }
        if doc.isLocked {
            guard let pw = password, !pw.isEmpty, doc.unlock(withPassword: pw) else {
                throw AppError("PDF có mật khẩu. Hãy nhập đúng mật khẩu.")
            }
        }
        let count = doc.pageCount
        guard count > 0 else { throw AppError("PDF không có trang nào.") }

        let base = url.deletingPathExtension().lastPathComponent
        let outDir = FileOps.uniqueURL(dir: dir, name: base)
        try FileManager.default.createDirectory(at: outDir, withIntermediateDirectories: true)

        // Hệ số tỷ lệ của ảnh thu nhỏ (UIImage.scale) để đạt đúng số điểm ảnh mong muốn
        var made = 0
        let digits = max(3, String(count).count)
        for i in 0..<count {
            try autoreleasepool {
                guard let page = doc.page(at: i) else { return }
                let probe = page.thumbnail(of: CGSize(width: 100, height: 100), for: .mediaBox)
                let sc = max(probe.scale, 1)
                let aspect = max(0.05, probe.size.width / max(probe.size.height, 1))
                let target = longSide / sc
                let size = aspect >= 1 ? CGSize(width: target, height: target / aspect)
                                       : CGSize(width: target * aspect, height: target)
                let img = page.thumbnail(of: size, for: .mediaBox)
                guard let data = jpeg ? img.jpegData(compressionQuality: 0.9) : img.pngData() else { return }
                let num = String(repeating: "0", count: max(0, digits - String(i + 1).count)) + String(i + 1)
                let name = "\(base)-trang-\(num).\(jpeg ? "jpg" : "png")"
                try data.write(to: outDir.appendingPathComponent(name), options: .atomic)
                made += 1
            }
            progress(Double(i + 1) / Double(count))
        }
        if made == 0 { try? FileManager.default.removeItem(at: outDir); throw AppError("Không xuất được trang nào.") }
        return made
    }
}

// MARK: - Giao diện

struct ImagePDFToolView: View {
    @State private var mode = 0
    // Ảnh -> PDF
    @State private var images: [URL] = []
    @State private var pageSize = 0
    @State private var sortByDate = false
    @State private var reversed = false
    @State private var pdfName = "Anh"
    @State private var pdfDir: URL = Paths.files.appendingPathComponent("Documents", isDirectory: true)
    @State private var showImagePicker = false
    @State private var showPdfDir = false
    // PDF -> Ảnh
    @State private var pdfs: [URL] = []
    @State private var jpeg = false
    @State private var quality = 1
    @State private var pdfPassword = ""
    @State private var imageDir: URL = Paths.files.appendingPathComponent("Images", isDirectory: true)
    @State private var showPdfPicker = false
    @State private var showImageDir = false
    // Chung
    @State private var busy: String?
    @State private var fraction: Double?
    @State private var message: String?

    private let qualityOptions: [(String, CGFloat)] = [("Nhỏ (1200 px)", 1200), ("Vừa (2000 px)", 2000),
                                                      ("Cao (3200 px)", 3200), ("Rất cao (5000 px)", 5000)]

    var body: some View {
        Form {
            Picker("Chế độ", selection: $mode) {
                Text("Ảnh → PDF").tag(0)
                Text("PDF → Ảnh").tag(1)
            }
            .pickerStyle(.segmented)
            .listRowBackground(Color.clear)

            if mode == 0 { imageToPDF } else { pdfToImage }
        }
        .navigationTitle("Ảnh ⇄ PDF")
        .navigationBarTitleDisplayMode(.inline)
        .overlay { overlay }
        .sheet(isPresented: $showImagePicker) {
            LocalFilePickerSheet(rootTitle: "Chọn ảnh", icon: "checkmark", allowFolders: false,
                                 actionTitle: { "Chọn \($0) tệp" }) { urls in
                let imgs = urls.filter { Kind.detect($0, isDirectory: false) == .image }
                images = imgs
                if imgs.count != urls.count { message = "Đã bỏ qua \(urls.count - imgs.count) tệp không phải ảnh." }
            }
        }
        .sheet(isPresented: $showPdfPicker) {
            LocalFilePickerSheet(rootTitle: "Chọn tệp PDF", icon: "checkmark", allowFolders: false,
                                 actionTitle: { "Chọn \($0) tệp" }) { urls in
                let list = urls.filter { $0.pathExtension.lowercased() == "pdf" }
                pdfs = list
                if list.count != urls.count { message = "Đã bỏ qua \(urls.count - list.count) tệp không phải PDF." }
            }
        }
        .sheet(isPresented: $showPdfDir) { FolderPicker(title: "Lưu PDF vào…", exclude: []) { pdfDir = $0 } }
        .sheet(isPresented: $showImageDir) { FolderPicker(title: "Lưu ảnh vào…", exclude: []) { imageDir = $0 } }
        .alert("Thông báo", isPresented: Binding(get: { message != nil }, set: { if !$0 { message = nil } })) {
            Button("OK") { message = nil }
        } message: { Text(message ?? "") }
    }

    // MARK: Ảnh → PDF

    private var orderedImages: [URL] {
        var list = images
        if sortByDate {
            list.sort {
                let a = (try? $0.resourceValues(forKeys: [.contentModificationDateKey]))?.contentModificationDate ?? .distantPast
                let b = (try? $1.resourceValues(forKeys: [.contentModificationDateKey]))?.contentModificationDate ?? .distantPast
                return a < b
            }
        } else {
            list.sort { $0.lastPathComponent.localizedStandardCompare($1.lastPathComponent) == .orderedAscending }
        }
        return reversed ? list.reversed() : list
    }

    @ViewBuilder private var imageToPDF: some View {
        Section("Ảnh") {
            Button { showImagePicker = true } label: {
                Label(images.isEmpty ? "Chọn ảnh" : "Đã chọn \(images.count) ảnh (bấm để đổi)", systemImage: "photo.on.rectangle")
            }
            if !images.isEmpty {
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 8) {
                        ForEach(Array(orderedImages.prefix(12).enumerated()), id: \.offset) { i, u in
                            VStack(spacing: 2) {
                                ThumbView(item: FileOps.item(from: u)).frame(width: 56, height: 56)
                                    .clipShape(RoundedRectangle(cornerRadius: 8))
                                Text("\(i + 1)").font(.caption2).foregroundStyle(.secondary)
                            }
                        }
                    }
                }
                Picker("Thứ tự trang", selection: $sortByDate) {
                    Text("Theo tên").tag(false)
                    Text("Theo ngày sửa").tag(true)
                }
                .pickerStyle(.segmented)
                Toggle("Đảo ngược thứ tự", isOn: $reversed)
            }
        }
        Section("Tùy chọn") {
            Picker("Kích thước trang", selection: $pageSize) {
                Text("Theo ảnh").tag(0)
                Text("A4").tag(1)
                Text("Letter").tag(2)
            }
            TextField("Tên tệp PDF", text: $pdfName)
            Button { showPdfDir = true } label: {
                LabeledContent("Lưu vào") { Text("Files/" + FileOps.relative(pdfDir)).foregroundStyle(.secondary).lineLimit(1) }
            }
            .buttonStyle(.plain)
        }
        Section {
            Button { makePDF() } label: { Label("Tạo PDF", systemImage: "doc.richtext").frame(maxWidth: .infinity) }
                .glassButtonStyle(prominent: true).controlSize(.large)
                .disabled(images.isEmpty)
        }
    }

    // MARK: PDF → Ảnh

    @ViewBuilder private var pdfToImage: some View {
        Section("Tệp PDF") {
            Button { showPdfPicker = true } label: {
                Label(pdfs.isEmpty ? "Chọn tệp PDF" : "Đã chọn \(pdfs.count) tệp (bấm để đổi)", systemImage: "doc.richtext")
            }
            ForEach(pdfs, id: \.self) { u in
                HStack {
                    Image(systemName: "doc.richtext").foregroundStyle(.red)
                    Text(u.lastPathComponent).lineLimit(1)
                    Spacer()
                    Text(Fmt.size(FileOps.size(of: u))).font(.caption).foregroundStyle(.secondary)
                }.font(.footnote)
            }
        }
        Section {
            Picker("Định dạng ảnh", selection: $jpeg) {
                Text("PNG (nét, nặng hơn)").tag(false)
                Text("JPEG (nhẹ hơn)").tag(true)
            }
            Picker("Chất lượng", selection: $quality) {
                ForEach(0..<qualityOptions.count, id: \.self) { Text(qualityOptions[$0].0).tag($0) }
            }
            SecureField("Mật khẩu PDF (nếu có)", text: $pdfPassword)
            Button { showImageDir = true } label: {
                LabeledContent("Lưu vào") { Text("Files/" + FileOps.relative(imageDir)).foregroundStyle(.secondary).lineLimit(1) }
            }
            .buttonStyle(.plain)
        } header: {
            Text("Tùy chọn")
        } footer: {
            Text("Mỗi PDF được xuất vào một thư mục riêng, mỗi trang là một ảnh.")
        }
        Section {
            Button { renderPDFs() } label: { Label("Xuất thành ảnh", systemImage: "photo.stack").frame(maxWidth: .infinity) }
                .glassButtonStyle(prominent: true).controlSize(.large)
                .disabled(pdfs.isEmpty)
        }
    }

    // MARK: Thực thi

    @ViewBuilder private var overlay: some View {
        if let busy {
            ZStack {
                Color.black.opacity(0.3).ignoresSafeArea()
                VStack(spacing: 12) {
                    if let fraction { ProgressView(value: fraction) } else { ProgressView() }
                    Text(busy).font(.footnote)
                }
                .padding(20).frame(width: 250).glassSurface(cornerRadius: 22)
            }
        }
    }

    private func makePDF() {
        let list = orderedImages, size = pageSize, dir = pdfDir
        var name = pdfName.trimmingCharacters(in: .whitespacesAndNewlines)
        if name.isEmpty { name = "Anh" }
        if !name.lowercased().hasSuffix(".pdf") { name += ".pdf" }
        guard FileOps.validName(name) != nil else { message = "Tên tệp không hợp lệ."; return }
        let fileName = name
        run("Đang tạo PDF…") { progress in
            try FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
            try FileOps.checkSpace(needed: list.reduce(Int64(0)) { $0 + FileOps.size(of: $1) } + 20_000_000)
            let target = FileOps.uniqueURL(dir: dir, name: fileName)
            let tmp = dir.appendingPathComponent(".jinn-pdf-\(UUID().uuidString).part")
            do {
                try ImagePDFOps.makePDF(images: list, pageSize: size, to: tmp, progress: progress)
                try FileManager.default.moveItem(at: tmp, to: target)
            } catch {
                try? FileManager.default.removeItem(at: tmp)
                throw error
            }
            return "Đã tạo \(target.lastPathComponent) (\(list.count) trang) trong Files/\(FileOps.relative(dir))."
        }
    }

    private func renderPDFs() {
        let list = pdfs, pw = pdfPassword, isJPEG = jpeg, dir = imageDir
        let side = qualityOptions[quality].1
        run("Đang xuất ảnh…") { progress in
            try FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
            try FileOps.checkSpace(needed: 100_000_000)
            var total = 0
            var failed: [String] = []
            for (i, u) in list.enumerated() {
                do {
                    total += try ImagePDFOps.renderPDF(u, password: pw, longSide: side, jpeg: isJPEG, into: dir) { f in
                        progress((Double(i) + f) / Double(list.count))
                    }
                } catch {
                    failed.append("• \(u.lastPathComponent): \(error.localizedDescription)")
                }
            }
            var m = "Đã xuất \(total) ảnh vào Files/\(FileOps.relative(dir))."
            if !failed.isEmpty { m += "\nLỗi:\n" + failed.prefix(4).joined(separator: "\n") }
            return m
        }
    }

    private func run(_ title: String, _ work: @escaping @Sendable (@escaping @Sendable (Double) -> Void) throws -> String) {
        busy = title
        fraction = nil
        let cb: @Sendable (Double) -> Void = { f in Task { @MainActor in fraction = f } }
        Task {
            do { message = try await Task.detached { try work(cb) }.value }
            catch { message = error.localizedDescription }
            busy = nil
        }
    }
}
