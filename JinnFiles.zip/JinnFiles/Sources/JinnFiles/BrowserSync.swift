import SwiftUI

// MARK: - Dữ liệu đồng bộ trình duyệt lên Google Drive

struct BrowserSyncPayload: Codable {
    var version: Int = 1
    var updatedAt: Date
    var accountEmail: String
    var bookmarks: [Bookmark]
    var favorites: [Favorite]
    var readingList: [ReadingItem]
    var recentSearches: [String]
    var history: [HistoryEntry]
}

// MARK: - Bộ quản lý đồng bộ tài khoản trình duyệt qua Google Drive

@MainActor
final class BrowserSyncManager: ObservableObject {
    static let shared = BrowserSyncManager()

    private static let folderName = "JinnFiles_BrowserSync"
    private static let fileName = "browser-sync.json"

    @Published var autoSync: Bool {
        didSet { UserDefaults.standard.set(autoSync, forKey: "browserAutoSync") }
    }
    @Published private(set) var isSyncing = false
    @Published private(set) var lastSyncDate: Date?
    @Published private(set) var lastSyncEmail: String?
    @Published var statusMessage: String?
    @Published var errorMessage: String?

    private var debounceTask: Task<Void, Never>?

    private init() {
        autoSync = UserDefaults.standard.object(forKey: "browserAutoSync") as? Bool ?? true
        if let ts = UserDefaults.standard.object(forKey: "browserLastSyncDate") as? Double {
            lastSyncDate = Date(timeIntervalSince1970: ts)
        }
        lastSyncEmail = UserDefaults.standard.string(forKey: "browserLastSyncEmail")
    }

    var canSync: Bool {
        let auth = GoogleAuth.shared
        return auth.isSignedIn && auth.canUseDrive
    }

    /// Gọi tự động khi dữ liệu trình duyệt thay đổi (gom nhóm sau 5 giây để tiết kiệm mạng)
    func scheduleAutoSync() {
        guard autoSync, canSync else { return }
        debounceTask?.cancel()
        debounceTask = Task { [weak self] in
            try? await Task.sleep(nanoseconds: 5_000_000_000)
            guard !Task.isCancelled else { return }
            await self?.syncTwoWay(silent: true)
        }
    }

    /// Đồng bộ 2 chiều: tải bản trên Drive, gộp với dữ liệu trên máy (không mất dữ liệu), rồi lưu lại lên Drive
    func syncTwoWay(silent: Bool = false) async {
        guard !isSyncing else { return }
        guard canSync else {
            if !silent { errorMessage = "Hãy đăng nhập Google và cấp quyền Google Drive trước khi đồng bộ." }
            return
        }

        isSyncing = true
        if !silent { errorMessage = nil; statusMessage = nil }
        defer { isSyncing = false }

        do {
            let folderID = try await ensureSyncFolder()
            let existing = try await findSyncFile(in: folderID)

            if let file = existing {
                let remote = try await downloadPayload(file: file)
                BrowserStore.shared.applySyncPayload(remote, merge: true)
            }

            let email = GoogleAuth.shared.user?.email ?? ""
            let merged = BrowserStore.shared.makeSyncPayload(email: email)
            try await uploadPayload(merged, existingFileID: existing?.id, folderID: folderID)

            markSynced(email: email)
            if !silent { statusMessage = "Đã đồng bộ dữ liệu trình duyệt lên Google Drive." }
        } catch {
            if !silent { errorMessage = error.localizedDescription }
        }
    }

    /// Chỉ tải dữ liệu từ Google Drive về máy (ghi đè dữ liệu hiện tại trên máy)
    func restoreFromDrive() async {
        guard !isSyncing else { return }
        guard canSync else {
            errorMessage = "Hãy đăng nhập Google và cấp quyền Google Drive trước."
            return
        }

        isSyncing = true
        errorMessage = nil
        statusMessage = nil
        defer { isSyncing = false }

        do {
            let folderID = try await ensureSyncFolder()
            guard let file = try await findSyncFile(in: folderID) else {
                errorMessage = "Chưa có bản sao lưu trình duyệt nào trên Google Drive của tài khoản này."
                return
            }
            let remote = try await downloadPayload(file: file)
            BrowserStore.shared.applySyncPayload(remote, merge: false)
            markSynced(email: GoogleAuth.shared.user?.email ?? "")
            statusMessage = "Đã khôi phục toàn bộ dấu trang, mục ưa thích và lịch sử từ Google Drive."
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    /// Chỉ đẩy dữ liệu hiện tại trên máy lên Google Drive (ghi đè bản trên Drive)
    func backupToDrive() async {
        guard !isSyncing else { return }
        guard canSync else {
            errorMessage = "Hãy đăng nhập Google và cấp quyền Google Drive trước."
            return
        }

        isSyncing = true
        errorMessage = nil
        statusMessage = nil
        defer { isSyncing = false }

        do {
            let folderID = try await ensureSyncFolder()
            let existing = try await findSyncFile(in: folderID)
            let email = GoogleAuth.shared.user?.email ?? ""
            let payload = BrowserStore.shared.makeSyncPayload(email: email)
            try await uploadPayload(payload, existingFileID: existing?.id, folderID: folderID)
            markSynced(email: email)
            statusMessage = "Đã sao lưu dữ liệu trình duyệt lên Google Drive."
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    private func markSynced(email: String) {
        let now = Date()
        lastSyncDate = now
        lastSyncEmail = email
        UserDefaults.standard.set(now.timeIntervalSince1970, forKey: "browserLastSyncDate")
        UserDefaults.standard.set(email, forKey: "browserLastSyncEmail")
    }

    // MARK: - Thao tác Google Drive API

    private func ensureSyncFolder() async throws -> String {
        let q = "name = '\(Self.folderName)' and 'root' in parents and mimeType = 'application/vnd.google-apps.folder' and trashed = false"
        if let found = try await findFirstFile(query: q) {
            return found.id
        }
        let created = try await DriveAPI.createFolder(name: Self.folderName, parent: "root")
        return created.id
    }

    private func findSyncFile(in folderID: String) async throws -> DriveFile? {
        let q = "name = '\(Self.fileName)' and '\(folderID)' in parents and trashed = false"
        return try await findFirstFile(query: q)
    }

    private func findFirstFile(query q: String) async throws -> DriveFile? {
        var c = URLComponents(string: DriveAPI.base + "/files")!
        c.queryItems = [
            .init(name: "q", value: q),
            .init(name: "fields", value: "files(\(DriveAPI.fileFields))"),
            .init(name: "pageSize", value: "1"),
            .init(name: "orderBy", value: "modifiedTime desc")
        ]
        let data = try await DriveAPI.send(c.url!)
        let obj = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any]
        let files = (obj?["files"] as? [[String: Any]] ?? []).compactMap(DriveAPI.parse)
        return files.first
    }

    private func downloadPayload(file: DriveFile) async throws -> BrowserSyncPayload {
        let tmp = FileManager.default.temporaryDirectory.appendingPathComponent("browser-sync-dl-\(UUID().uuidString).json")
        defer { try? FileManager.default.removeItem(at: tmp) }
        try await DriveAPI.download(file, to: tmp)
        let data = try Data(contentsOf: tmp)
        let dec = JSONDecoder()
        dec.dateDecodingStrategy = .iso8601
        return try dec.decode(BrowserSyncPayload.self, from: data)
    }

    private func uploadPayload(_ payload: BrowserSyncPayload, existingFileID: String?, folderID: String) async throws {
        let enc = JSONEncoder()
        enc.dateEncodingStrategy = .iso8601
        let data = try enc.encode(payload)

        if let fileID = existingFileID {
            // Cập nhật trực tiếp nội dung tệp sẵn có (không tạo bản sao trùng lặp)
            for attempt in 0..<2 {
                let token = try await GoogleAuth.shared.accessToken(forceRefresh: attempt == 1)
                var c = URLComponents(string: "https://www.googleapis.com/upload/drive/v3/files/\(fileID)")!
                c.queryItems = [.init(name: "uploadType", value: "media")]
                var req = URLRequest(url: c.url!)
                req.httpMethod = "PATCH"
                req.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
                req.setValue("application/json; charset=UTF-8", forHTTPHeaderField: "Content-Type")
                req.httpBody = data
                let (_, resp) = try await URLSession.shared.data(for: req)
                let code = (resp as? HTTPURLResponse)?.statusCode ?? 0
                if code == 401 && attempt == 0 { continue }
                guard (200..<300).contains(code) else {
                    throw AppError("Không thể cập nhật tệp đồng bộ trên Google Drive (mã lỗi \(code)).")
                }
                return
            }
            throw AppError("Phiên đăng nhập Google bị từ chối, hãy đăng nhập lại.")
        } else {
            let tmp = FileManager.default.temporaryDirectory.appendingPathComponent("browser-sync-ul-\(UUID().uuidString).json")
            defer { try? FileManager.default.removeItem(at: tmp) }
            try data.write(to: tmp, options: .atomic)
            try await DriveAPI.upload(file: tmp, name: Self.fileName, parent: folderID) { _ in }
        }
    }
}

// MARK: - Giao diện Tài khoản & Đồng bộ Trình duyệt

struct BrowserAccountSheet: View {
    @ObservedObject private var auth = GoogleAuth.shared
    @ObservedObject private var sync = BrowserSyncManager.shared
    @EnvironmentObject private var store: BrowserStore
    @Environment(\.dismiss) private var dismiss

    @State private var confirmRestore = false
    @State private var confirmSignOut = false
    @State private var clientIDInput = ""

    var body: some View {
        NavigationStack {
            List {
                accountSection
                if auth.isSignedIn && auth.canUseDrive {
                    syncControlsSection
                    dataSummarySection
                }
                if let msg = sync.statusMessage {
                    Section {
                        Label(msg, systemImage: "checkmark.circle.fill")
                            .foregroundStyle(.green)
                            .font(.subheadline)
                    }
                }
                if let err = sync.errorMessage ?? auth.errorMessage {
                    Section {
                        Label(err, systemImage: "exclamationmark.triangle.fill")
                            .foregroundStyle(.red)
                            .font(.subheadline)
                    }
                }
            }
            .listStyle(.insetGrouped)
            .navigationTitle("Tài khoản trình duyệt")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Xong") { dismiss() }
                }
            }
            .onAppear {
                clientIDInput = auth.clientID
                sync.statusMessage = nil
                sync.errorMessage = nil
            }
            .confirmationDialog(
                "Khôi phục dữ liệu từ Google Drive?",
                isPresented: $confirmRestore,
                titleVisibility: .visible
            ) {
                Button("Khôi phục (ghi đè máy này)", role: .destructive) {
                    Task { await sync.restoreFromDrive() }
                }
                Button("Hủy", role: .cancel) {}
            } message: {
                Text("Dấu trang, mục ưa thích, danh sách đọc và lịch sử trên máy này sẽ được thay bằng bản sao lưu trên Google Drive.")
            }
            .confirmationDialog(
                "Đăng xuất tài khoản Google?",
                isPresented: $confirmSignOut,
                titleVisibility: .visible
            ) {
                Button("Đăng xuất", role: .destructive) {
                    auth.signOut()
                }
                Button("Hủy", role: .cancel) {}
            } message: {
                Text("Dữ liệu trên máy vẫn được giữ lại, nhưng trình duyệt sẽ ngừng đồng bộ cho đến khi bạn đăng nhập lại.")
            }
        }
    }

    // MARK: Phần tài khoản Google

    private var accountSection: some View {
        Section {
            if let user = auth.user, auth.isSignedIn {
                HStack(spacing: 14) {
                    avatarView(urlString: user.picture, name: user.name)
                    VStack(alignment: .leading, spacing: 3) {
                        Text(user.name).font(.headline)
                        Text(user.email).font(.subheadline).foregroundStyle(.secondary)
                        if auth.canUseDrive {
                            Label("Đã kết nối Google Drive", systemImage: "checkmark.seal.fill")
                                .font(.caption)
                                .foregroundStyle(.green)
                        } else {
                            Label("Chưa có quyền Google Drive", systemImage: "exclamationmark.circle.fill")
                                .font(.caption)
                                .foregroundStyle(.orange)
                        }
                    }
                }
                .padding(.vertical, 4)

                if !auth.canUseDrive {
                    Button {
                        Task { await auth.signIn() }
                    } label: {
                        Label("Đăng nhập lại để cấp quyền Google Drive", systemImage: "arrow.triangle.2.circlepath")
                    }
                    .disabled(auth.busy)
                }

                Button(role: .destructive) {
                    confirmSignOut = true
                } label: {
                    Label("Đăng xuất", systemImage: "rectangle.portrait.and.arrow.right")
                }
            } else {
                VStack(alignment: .leading, spacing: 8) {
                    Label("Đồng bộ qua Google Drive", systemImage: "icloud.and.arrow.up")
                        .font(.headline)
                    Text("Đăng nhập tài khoản Google để tự động lưu dấu trang, mục ưa thích, danh sách đọc, lịch sử tìm kiếm và lịch sử duyệt web vào thư mục JinnFiles_BrowserSync trên Google Drive của bạn.")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }
                .padding(.vertical, 4)

                if !auth.isConfigured {
                    VStack(alignment: .leading, spacing: 8) {
                        Text("Chưa cấu hình Google Client ID (có thể nhập tại đây hoặc ở tab Tài khoản):")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                        TextField("xxxx.apps.googleusercontent.com", text: $clientIDInput)
                            .textInputAutocapitalization(.never)
                            .autocorrectionDisabled()
                            .font(.footnote)
                        Button("Lưu Client ID") {
                            auth.setClientID(clientIDInput)
                        }
                        .disabled(!clientIDInput.trimmingCharacters(in: .whitespacesAndNewlines).hasSuffix(".apps.googleusercontent.com"))
                    }
                    .padding(.vertical, 4)
                }

                Button {
                    Task {
                        await auth.signIn()
                        if auth.isSignedIn && auth.canUseDrive {
                            await sync.syncTwoWay()
                        }
                    }
                } label: {
                    HStack {
                        if auth.busy {
                            ProgressView().padding(.trailing, 6)
                        } else {
                            Image(systemName: "person.badge.key.fill")
                        }
                        Text(auth.busy ? "Đang đăng nhập..." : "Đăng nhập bằng Google")
                            .fontWeight(.semibold)
                    }
                    .frame(maxWidth: .infinity)
                }
                .disabled(auth.busy || !auth.isConfigured)
            }
        } header: {
            Text("Tài khoản đồng bộ")
        }
    }

    // MARK: Phần điều khiển đồng bộ

    private var syncControlsSection: some View {
        Section {
            Toggle(isOn: $sync.autoSync) {
                Label("Tự động đồng bộ khi có thay đổi", systemImage: "arrow.triangle.2.circlepath.circle")
            }

            Button {
                Task { await sync.syncTwoWay() }
            } label: {
                HStack {
                    Label("Đồng bộ ngay (Gộp 2 chiều)", systemImage: "arrow.triangle.2.circlepath")
                    Spacer()
                    if sync.isSyncing { ProgressView() }
                }
            }
            .disabled(sync.isSyncing)

            Button {
                Task { await sync.backupToDrive() }
            } label: {
                Label("Sao lưu từ máy lên Drive", systemImage: "icloud.and.arrow.up")
            }
            .disabled(sync.isSyncing)

            Button {
                confirmRestore = true
            } label: {
                Label("Khôi phục từ Drive về máy", systemImage: "icloud.and.arrow.down")
            }
            .disabled(sync.isSyncing)
        } header: {
            Text("Đồng bộ Google Drive")
        } footer: {
            if let d = sync.lastSyncDate {
                Text("Lần đồng bộ gần nhất: \(d.formatted(date: .abbreviated, time: .shortened))")
            } else {
                Text("Dữ liệu được lưu vào tệp browser-sync.json trong thư mục JinnFiles_BrowserSync trên Google Drive.")
            }
        }
    }

    // MARK: Thống kê dữ liệu hiện có

    private var dataSummarySection: some View {
        Section("Dữ liệu được đồng bộ") {
            LabeledContent("Mục ưa thích", value: "\(store.favorites.count)")
            LabeledContent("Dấu trang", value: "\(store.bookmarks.count)")
            LabeledContent("Danh sách đọc", value: "\(store.readingList.count)")
            LabeledContent("Tìm kiếm gần đây", value: "\(store.recentSearches.count)")
            LabeledContent("Lịch sử duyệt web", value: "\(store.history.count)")
        }
    }

    private func avatarView(urlString: String?, name: String) -> some View {
        ZStack {
            Circle().fill(Color.accentColor.opacity(0.16))
            if let s = urlString, let url = URL(string: s) {
                AsyncImage(url: url) { phase in
                    if case .success(let img) = phase {
                        img.resizable().scaledToFill()
                    } else {
                        Text(String(name.prefix(1)).uppercased())
                            .font(.title3.bold())
                            .foregroundStyle(Color.accentColor)
                    }
                }
            } else {
                Text(String(name.prefix(1)).uppercased())
                    .font(.title3.bold())
                    .foregroundStyle(Color.accentColor)
            }
        }
        .frame(width: 50, height: 50)
        .clipShape(Circle())
    }
}
