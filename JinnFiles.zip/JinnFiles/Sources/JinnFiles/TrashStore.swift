import SwiftUI

struct TrashEntry: Codable, Identifiable, Hashable {
    var id: UUID
    var name: String
    var originalPath: String   // tương đối so với Files/
    var deletedAt: Date
    var size: Int64
    var isDirectory: Bool

    var payload: URL {
        Paths.trash.appendingPathComponent(id.uuidString, isDirectory: true)
            .appendingPathComponent(name, isDirectory: isDirectory)
    }
    var folder: URL { Paths.trash.appendingPathComponent(id.uuidString, isDirectory: true) }
    var kind: Kind { Kind.detect(URL(fileURLWithPath: name), isDirectory: isDirectory) }
    var expiresAt: Date { deletedAt.addingTimeInterval(TrashStore.retention) }
    var daysLeft: Int {
        max(0, Int(ceil(expiresAt.timeIntervalSinceNow / 86400)))
    }
}

@MainActor
final class TrashStore: ObservableObject {
    static let shared = TrashStore()
    static let retention: TimeInterval = 30 * 86400

    @Published private(set) var entries: [TrashEntry] = []
    private let fm = FileManager.default
    private var file: URL { Paths.meta.appendingPathComponent("trash.json") }

    private var encoder: JSONEncoder {
        let e = JSONEncoder(); e.dateEncodingStrategy = .iso8601; e.outputFormatting = [.prettyPrinted]; return e
    }
    private var decoder: JSONDecoder {
        let d = JSONDecoder(); d.dateDecodingStrategy = .iso8601; return d
    }

    init() {
        Paths.bootstrap()
        load()
    }

    private func save() throws {
        let data = try encoder.encode(entries)
        try data.write(to: file, options: [.atomic])
    }

    func load() {
        var list: [TrashEntry] = []
        if let data = try? Data(contentsOf: file) {
            if let l = try? decoder.decode([TrashEntry].self, from: data) {
                list = l
            } else {
                // Metadata hỏng: sao lưu lại, không xóa dữ liệu
                let bak = Paths.meta.appendingPathComponent("trash.corrupt-\(Int(Date().timeIntervalSince1970)).json")
                try? fm.copyItem(at: file, to: bak)
            }
        }
        list = list.filter { fm.fileExists(atPath: $0.folder.path) }

        // Nhận lại các mục "mồ côi" (ứng dụng bị đóng đột ngột giữa chừng)
        if let dirs = try? fm.contentsOfDirectory(at: Paths.trash, includingPropertiesForKeys: [.creationDateKey]) {
            for d in dirs {
                guard let id = UUID(uuidString: d.lastPathComponent), !list.contains(where: { $0.id == id }),
                      let child = (try? fm.contentsOfDirectory(at: d, includingPropertiesForKeys: nil))?.first else { continue }
                let it = FileOps.item(from: child)
                list.append(TrashEntry(id: id, name: child.lastPathComponent, originalPath: child.lastPathComponent,
                                       deletedAt: Date(), size: FileOps.size(of: child), isDirectory: it.isDirectory))
            }
        }
        entries = list
        try? save()
    }

    func purgeExpired() {
        let now = Date()
        var keep: [TrashEntry] = []
        for e in entries {
            if now >= e.expiresAt {
                do { try fm.removeItem(at: e.folder) } catch { keep.append(e) }
            } else { keep.append(e) }
        }
        if keep.count != entries.count {
            entries = keep
            try? save()
        }
    }

    func moveToTrash(_ url: URL) throws {
        let item = FileOps.item(from: url)
        let size = FileOps.size(of: url)
        let id = UUID()
        let dir = Paths.trash.appendingPathComponent(id.uuidString, isDirectory: true)
        try fm.createDirectory(at: dir, withIntermediateDirectories: true)
        let dest = dir.appendingPathComponent(url.lastPathComponent)
        do { try fm.moveItem(at: url, to: dest) } catch {
            try? fm.removeItem(at: dir)
            throw error
        }
        let entry = TrashEntry(id: id, name: url.lastPathComponent, originalPath: FileOps.relative(url),
                               deletedAt: Date(), size: size, isDirectory: item.isDirectory)
        entries.append(entry)
        do { try save() } catch {
            // hoàn tác: trả dữ liệu về chỗ cũ
            try? fm.moveItem(at: dest, to: url)
            try? fm.removeItem(at: dir)
            entries.removeLast()
            throw error
        }
    }

    func originalParent(of e: TrashEntry) -> URL? {
        let rel = (e.originalPath as NSString).deletingLastPathComponent
        let p = rel.isEmpty ? Paths.files : Paths.files.appendingPathComponent(rel, isDirectory: true)
        var isDir: ObjCBool = false
        return fm.fileExists(atPath: p.path, isDirectory: &isDir) && isDir.boolValue ? p : nil
    }

    func restore(_ e: TrashEntry, into dir: URL) throws {
        let target = FileOps.uniqueURL(dir: dir, name: e.name)
        try fm.moveItem(at: e.payload, to: target)
        entries.removeAll { $0.id == e.id }
        try? save()
        try? fm.removeItem(at: e.folder)
    }

    func deleteForever(_ ids: Set<UUID>) -> Int {
        var failed = 0
        for e in entries where ids.contains(e.id) {
            do { try fm.removeItem(at: e.folder) } catch { failed += 1; continue }
            entries.removeAll { $0.id == e.id }
        }
        try? save()
        return failed
    }

    func emptyAll() -> Int { deleteForever(Set(entries.map(\.id))) }
}
