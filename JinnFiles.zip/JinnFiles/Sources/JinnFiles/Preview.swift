import SwiftUI
import AVKit
import PDFKit

struct PreviewView: View {
    let item: FileItem
    var body: some View {
        Group {
            switch item.kind {
            case .image:
                let sib = FileOps.list(item.url.deletingLastPathComponent())
                    .filter { $0.kind == .image }
                    .sorted { $0.name.localizedStandardCompare($1.name) == .orderedAscending }
                    .map(\.url)
                ImagePager(urls: sib.isEmpty ? [item.url] : sib,
                           start: sib.firstIndex(of: item.url) ?? 0, onClose: nil)
            case .video, .audio: VideoPreview(url: item.url)
            case .pdf: PDFPreview(url: item.url).ignoresSafeArea(edges: .bottom)
            case .text: TextPreview(url: item.url)
            default: UnsupportedPreview(item: item)
            }
        }
        .navigationTitle(item.name)
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) { ShareLink(item: item.url) }
        }
    }
}

struct ImagePager: View {
    let urls: [URL]
    @State var index: Int
    let onClose: (() -> Void)?

    init(urls: [URL], start: Int, onClose: (() -> Void)?) {
        self.urls = urls; self._index = State(initialValue: start); self.onClose = onClose
    }

    var body: some View {
        ZStack(alignment: .top) {
            Color.black.ignoresSafeArea()
            TabView(selection: $index) {
                ForEach(Array(urls.enumerated()), id: \.offset) { i, u in
                    ZoomableImage(url: u).tag(i)
                }
            }
            .tabViewStyle(.page(indexDisplayMode: .never))
            .ignoresSafeArea()
            VStack {
                if let onClose {
                    HStack {
                        Button { onClose() } label: {
                            Image(systemName: "xmark").font(.headline).foregroundStyle(.white).glassCircle(size: 40)
                        }
                        Spacer()
                        Text("\(index + 1)/\(urls.count)").foregroundStyle(.white).font(.footnote)
                        Spacer()
                        if urls.indices.contains(index) { ShareLink(item: urls[index]).tint(.white) }
                    }
                    .padding()
                }
                Spacer()
                if onClose == nil {
                    Text("\(index + 1)/\(urls.count)").font(.footnote).foregroundStyle(.white)
                        .padding(.horizontal, 14).padding(.vertical, 8).glassSurface(cornerRadius: 20).padding(.bottom, 8)
                }
            }
        }
    }
}

struct ZoomableImage: View {
    let url: URL
    @State private var image: UIImage?
    @State private var scale: CGFloat = 1
    @State private var base: CGFloat = 1
    @State private var offset: CGSize = .zero
    @State private var lastOffset: CGSize = .zero

    var body: some View {
        ZStack {
            if let image {
                Image(uiImage: image)
                    .resizable().scaledToFit()
                    .scaleEffect(scale)
                    .offset(offset)
                    .gesture(
                        MagnifyGesture()
                            .onChanged { scale = min(6, max(1, base * $0.magnification)) }
                            .onEnded { _ in base = scale; if scale <= 1.02 { reset() } }
                    )
                    // Chỉ nhận kéo khi đã phóng to, để vuốt trái/phải chuyển ảnh vẫn hoạt động
                    .gesture(
                        DragGesture(minimumDistance: scale > 1 ? 0 : 100_000)
                            .onChanged { offset = CGSize(width: lastOffset.width + $0.translation.width,
                                                         height: lastOffset.height + $0.translation.height) }
                            .onEnded { _ in lastOffset = offset }
                    )
                    .onTapGesture(count: 2) {
                        withAnimation { if scale > 1 { reset() } else { scale = 2.5; base = 2.5 } }
                    }
            } else {
                ProgressView().tint(.white)
            }
        }
        .task(id: url) { image = await Thumbs.load(url, maxPixel: 2600) }
    }

    private func reset() { scale = 1; base = 1; offset = .zero; lastOffset = .zero }
}

struct VideoPreview: View {
    let url: URL
    @State private var player: AVPlayer?
    @State private var duration: String?
    var body: some View {
        VStack(spacing: 8) {
            if let player { VideoPlayer(player: player) } else { ProgressView() }
            if let duration { Text("Thời lượng: \(duration)").font(.footnote).foregroundStyle(.secondary).padding(.bottom, 8) }
        }
        .task {
            player = AVPlayer(url: url)
            if let d = try? await AVURLAsset(url: url).load(.duration) { duration = Fmt.duration(d.seconds) }
        }
        .onDisappear { player?.pause() }
    }
}

struct PDFPreview: UIViewRepresentable {
    let url: URL
    func makeUIView(context: Context) -> PDFView {
        let v = PDFView()
        v.autoScales = true
        v.displayMode = .singlePageContinuous
        v.displayDirection = .vertical
        v.minScaleFactor = v.scaleFactorForSizeToFit * 0.5
        v.maxScaleFactor = 6
        v.document = PDFDocument(url: url)
        return v
    }
    func updateUIView(_ v: PDFView, context: Context) {}
}

struct TextPreview: View {
    let url: URL
    @State private var text: String?
    @State private var truncated = false
    private static let limit = 1_000_000

    var body: some View {
        ScrollView {
            if let text {
                VStack(alignment: .leading, spacing: 8) {
                    if truncated { Text("Chỉ hiển thị phần đầu của tệp lớn.").font(.footnote).foregroundStyle(.orange) }
                    Text(text).font(.system(.callout, design: .monospaced)).textSelection(.enabled)
                        .frame(maxWidth: .infinity, alignment: .leading)
                }.padding()
            } else { ProgressView().padding(40) }
        }
        .task {
            let u = url
            let r = await Task.detached { Self.read(u) }.value
            text = r.0; truncated = r.1
        }
    }

    nonisolated static func read(_ url: URL) -> (String, Bool) {
        guard let h = try? FileHandle(forReadingFrom: url) else { return ("Không thể đọc tệp.", false) }
        defer { try? h.close() }
        let data = (try? h.read(upToCount: limit + 4)) ?? Data()
        let trunc = data.count > limit
        var d = trunc ? data.prefix(limit) : data[...]
        if d.starts(with: [0xFF, 0xFE]) || d.starts(with: [0xFE, 0xFF]) {
            return (String(data: Data(d), encoding: .utf16) ?? "", trunc)
        }
        for _ in 0..<4 {   // cắt dở ký tự UTF-8 ở cuối
            if let s = String(data: Data(d), encoding: .utf8) { return (s, trunc) }
            if d.isEmpty { break }
            d = d.dropLast()
        }
        var str: NSString?
        var lossy: ObjCBool = false
        _ = NSString.stringEncoding(for: Data(data), encodingOptions: nil, convertedString: &str, usedLossyConversion: &lossy)
        if let s = str as String? { return (s, trunc) }
        return (String(decoding: Data(data), as: UTF8.self), trunc)
    }
}

struct UnsupportedPreview: View {
    let item: FileItem
    var body: some View {
        VStack(spacing: 14) {
            Image(systemName: item.kind.symbol).font(.system(size: 64)).foregroundStyle(item.kind.tint)
            Text(item.name).font(.headline).multilineTextAlignment(.center)
            Text("\(item.url.pathExtension.uppercased()) • \(Fmt.size(item.size ?? 0))").foregroundStyle(.secondary)
            Text("Định dạng này chưa hỗ trợ xem trước.").font(.footnote).foregroundStyle(.secondary)
            ShareLink(item: item.url) { Label("Chia sẻ / Mở bằng ứng dụng khác", systemImage: "square.and.arrow.up") }
                .buttonStyle(.borderedProminent)
        }.padding()
    }
}
