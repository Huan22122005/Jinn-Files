import SwiftUI
import WebKit

// MARK: - Mô hình dữ liệu Chặn quảng cáo

enum BlockedKind: String, Codable, CaseIterable {
    case ad = "ad"
    case popup = "popup"

    var title: String {
        switch self {
        case .ad: return "Quảng cáo"
        case .popup: return "Cửa sổ bật lên"
        }
    }

    var icon: String {
        switch self {
        case .ad: return "nosign"
        case .popup: return "macwindow.badge.plus"
        }
    }
}

struct BlockedEvent: Codable, Identifiable, Hashable {
    var id = UUID()
    let kind: BlockedKind
    let sourceHost: String
    let target: String
    let date: Date
}

private struct AdBlockSettingsData: Codable {
    var adBlockEnabled: Bool = true
    var popupBlockEnabled: Bool = true
    var adDisabledHosts: [String] = []
    var popupDisabledHosts: [String] = []
    var customBlockedDomains: [String] = []
    var totalBlockedAds: Int = 0
    var totalBlockedPopups: Int = 0
}

// MARK: - Bridge tránh retain cycle cho WKScriptMessageHandler

final class WeakScriptMessageHandler: NSObject, WKScriptMessageHandler {
    private let onMessage: @MainActor (String, Any) -> Void

    init(onMessage: @escaping @MainActor (String, Any) -> Void) {
        self.onMessage = onMessage
    }

    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        let name = message.name
        let body = message.body
        Task { @MainActor in
            onMessage(name, body)
        }
    }
}

// MARK: - Bộ quản lý Chặn quảng cáo & Popup (kiểu Cốc Cốc)

@MainActor
final class AdBlockManager: ObservableObject {
    static let shared = AdBlockManager()
    static let messageHandlerName = "jinnAdBlock"
    private static let ruleListIdentifier = "jinnfiles.adblocker.rules.v1"

    @Published var adBlockEnabled: Bool = true {
        didSet { guard !isLoadingSettings else { return }; saveSettings(); rebuildRules() }
    }
    @Published var popupBlockEnabled: Bool = true {
        didSet { guard !isLoadingSettings else { return }; saveSettings(); notifyTabsSettingsChanged() }
    }
    @Published var adDisabledHosts: Set<String> = [] {
        didSet { guard !isLoadingSettings else { return }; saveSettings(); rebuildRules() }
    }
    @Published var popupDisabledHosts: Set<String> = [] {
        didSet { guard !isLoadingSettings else { return }; saveSettings(); notifyTabsSettingsChanged() }
    }
    @Published var customBlockedDomains: [String] = [] {
        didSet { guard !isLoadingSettings else { return }; saveSettings(); rebuildRules() }
    }
    @Published var events: [BlockedEvent] = []
    @Published var totalBlockedAds: Int = 0
    @Published var totalBlockedPopups: Int = 0

    private var isLoadingSettings = false
    private(set) var compiledRuleList: WKContentRuleList?

    private var settingsFile: URL { Paths.meta.appendingPathComponent("adblock-settings.json") }
    private var logFile: URL { Paths.meta.appendingPathComponent("adblock-log.json") }

    // Danh sách tên miền quảng cáo, trình theo dõi & popup phổ biến (quốc tế + Việt Nam)
    static let builtInAdDomains: [String] = [
        "doubleclick.net",
        "googlesyndication.com",
        "googleadservices.com",
        "adservice.google.com",
        "pagead2.googlesyndication.com",
        "google-analytics.com",
        "googletagmanager.com",
        "ads.yahoo.com",
        "advertising.com",
        "adnxs.com",
        "amazon-adsystem.com",
        "taboola.com",
        "outbrain.com",
        "mgid.com",
        "criteo.com",
        "criteo.net",
        "rubiconproject.com",
        "pubmatic.com",
        "openx.net",
        "casalemedia.com",
        "smartadserver.com",
        "revcontent.com",
        "zergnet.com",
        "admicro.vn",
        "vcmedia.vn",
        "adtima.vn",
        "eclick.vn",
        "ants.vn",
        "polyad.net",
        "novanet.vn",
        "urekamedia.vn",
        "blueseed.tv",
        "ambientdigitalgroup.com",
        "popads.net",
        "popcash.net",
        "propellerads.com",
        "adsterra.com",
        "highperformanceformat.com",
        "exoclick.com",
        "exosrv.com",
        "juicyads.com",
        "trafficjunky.net",
        "trafficstars.com",
        "hilltopads.net",
        "clickadu.com",
        "admaven.com",
        "onclickalgo.com",
        "pushame.com",
        "tsyndicate.com",
        "realsrv.com",
        "a-ads.com",
        "scorecardresearch.com",
        "quantserve.com",
        "hotjar.com",
        "mc.yandex.ru"
    ]

    static let popupAdKeywords: [String] = [
        "popads", "popcash", "propeller", "adsterra", "exoclick", "juicyads",
        "trafficjunky", "hilltopads", "clickadu", "admaven", "doubleclick",
        "googlesyndication", "mgid", "taboola", "outbrain", "admicro", "adtima"
    ]

    private init() {
        Paths.bootstrap()
        loadSettings()
        loadLog()
        rebuildRules()
    }

    // MARK: - Chuẩn hóa & Kiểm tra trạng thái theo trang

    static func normalizedHost(from urlString: String) -> String? {
        guard let host = URL(string: urlString)?.host?.lowercased(), !host.isEmpty else { return nil }
        return host.hasPrefix("www.") ? String(host.dropFirst(4)) : host
    }

    func isAdBlockActive(for host: String?) -> Bool {
        guard adBlockEnabled else { return false }
        guard let host, !host.isEmpty else { return true }
        return !adDisabledHosts.contains(host)
    }

    func isPopupBlockActive(for host: String?) -> Bool {
        guard popupBlockEnabled else { return false }
        guard let host, !host.isEmpty else { return true }
        return !popupDisabledHosts.contains(host)
    }

    func setAdBlock(_ enabled: Bool, for host: String) {
        if enabled {
            adDisabledHosts.remove(host)
            if !adBlockEnabled { adBlockEnabled = true }
        } else {
            adDisabledHosts.insert(host)
        }
    }

    func setPopupBlock(_ enabled: Bool, for host: String) {
        if enabled {
            popupDisabledHosts.remove(host)
            if !popupBlockEnabled { popupBlockEnabled = true }
        } else {
            popupDisabledHosts.insert(host)
        }
    }

    func isKnownAdOrPopupURL(_ url: URL) -> Bool {
        let host = (url.host ?? "").lowercased()
        let full = url.absoluteString.lowercased()
        if allBlockedDomains.contains(where: { host == $0 || host.hasSuffix("." + $0) }) {
            return true
        }
        return Self.popupAdKeywords.contains(where: { full.contains($0) })
    }

    var allBlockedDomains: [String] {
        var seen = Set<String>()
        var result: [String] = []
        for d in (customBlockedDomains + Self.builtInAdDomains) {
            let clean = Self.cleanDomain(d)
            if !clean.isEmpty && seen.insert(clean).inserted {
                result.append(clean)
            }
        }
        return result
    }

    static func cleanDomain(_ raw: String) -> String {
        var s = raw.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        if let u = URL(string: s), let h = u.host { s = h.lowercased() }
        if s.hasPrefix("www.") { s = String(s.dropFirst(4)) }
        if let slash = s.firstIndex(of: "/") { s = String(s[..<slash]) }
        return s
    }

    func addCustomDomain(_ raw: String) {
        let domain = Self.cleanDomain(raw)
        guard !domain.isEmpty, domain.contains("."), !customBlockedDomains.contains(domain) else { return }
        customBlockedDomains.insert(domain, at: 0)
    }

    func removeCustomDomain(_ domain: String) {
        customBlockedDomains.removeAll { $0 == domain }
    }

    // MARK: - Ghi nhận & Nhật ký đã chặn

    func record(kind: BlockedKind, sourceHost: String, target: String) {
        let host = sourceHost.isEmpty ? "Trang web" : sourceHost
        let cleanTarget = target.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !cleanTarget.isEmpty else { return }

        // Tránh spam trùng lặp liên tiếp trong 1.5 giây
        if let last = events.first,
           last.kind == kind,
           last.sourceHost == host,
           last.target == cleanTarget,
           Date().timeIntervalSince(last.date) < 1.5 {
            return
        }

        let ev = BlockedEvent(kind: kind, sourceHost: host, target: cleanTarget, date: Date())
        events.insert(ev, at: 0)
        if events.count > 500 {
            events.removeLast(events.count - 500)
        }
        if kind == .ad { totalBlockedAds += 1 } else { totalBlockedPopups += 1 }
        saveSettings()
        saveLog()
    }

    func events(for host: String?) -> [BlockedEvent] {
        guard let host, !host.isEmpty else { return events }
        return events.filter { $0.sourceHost == host }
    }

    func clearEvents() {
        events = []
        totalBlockedAds = 0
        totalBlockedPopups = 0
        saveSettings()
        saveLog()
    }

    // MARK: - Áp dụng vào WKWebView

    func apply(to webView: WKWebView) {
        let ucc = webView.configuration.userContentController
        ucc.removeAllContentRuleLists()
        if adBlockEnabled, let list = compiledRuleList {
            ucc.add(list)
        }
        ucc.removeAllUserScripts()
        ucc.addUserScript(makeProtectionScript())
    }

    func rebuildRules() {
        let json = buildContentRuleJSON()
        Task {
            do {
                let list = try await WKContentRuleListStore.default().compileContentRuleList(
                    forIdentifier: Self.ruleListIdentifier,
                    encodedContentRuleList: json
                )
                self.compiledRuleList = list
                self.notifyTabsSettingsChanged()
            } catch {
                // Nếu biên dịch thất bại, vẫn giữ script bảo vệ phía JS
                self.notifyTabsSettingsChanged()
            }
        }
    }

    private func notifyTabsSettingsChanged() {
        for tab in BrowserStore.shared.tabs {
            apply(to: tab.webView)
        }
    }

    private func buildContentRuleJSON() -> String {
        var rules: [[String: Any]] = []
        let exceptions = adDisabledHosts.map { "*\($0)" }

        for domain in allBlockedDomains {
            let escaped = NSRegularExpression.escapedPattern(for: domain)
            var trigger: [String: Any] = [
                "url-filter": "^https?://([^/]+\\.)?\(escaped)(/|:|$)",
                "load-type": ["third-party"]
            ]
            if !exceptions.isEmpty {
                trigger["unless-domain"] = exceptions
            }
            rules.append([
                "trigger": trigger,
                "action": ["type": "block"]
            ])
        }

        // Quy tắc ẩn phần tử quảng cáo phổ biến ở tầng WebKit
        var cosmeticTrigger: [String: Any] = ["url-filter": ".*"]
        if !exceptions.isEmpty {
            cosmeticTrigger["unless-domain"] = exceptions
        }
        let selectors = [
            ".adsbygoogle",
            "ins.adsbygoogle",
            "[id^='google_ads_iframe']",
            "[id^='div-gpt-ad']",
            ".ad-banner",
            ".ads-banner",
            ".ad-container",
            ".ads-container",
            ".ad-wrapper",
            ".sponsored-ad",
            ".admicro-ad",
            "[class*='admicro']",
            "[id*='admicro']",
            ".adtima-ad",
            ".mgbox",
            ".trc_rbox_container",
            ".OUTBRAIN"
        ].joined(separator: ", ")

        rules.append([
            "trigger": cosmeticTrigger,
            "action": [
                "type": "css-display-none",
                "selector": selectors
            ]
        ])

        guard let data = try? JSONSerialization.data(withJSONObject: rules),
              let str = String(data: data, encoding: .utf8) else {
            return "[]"
        }
        return str
    }

    private func makeProtectionScript() -> WKUserScript {
        let adDisabledJSON = encodeStringArray(Array(adDisabledHosts))
        let popupDisabledJSON = encodeStringArray(Array(popupDisabledHosts))
        let adDomainsJSON = encodeStringArray(allBlockedDomains)

        let source = """
        (function() {
            if (window.__jinnAdBlockInstalled) return;
            window.__jinnAdBlockInstalled = true;

            const AD_GLOBAL = \(adBlockEnabled ? "true" : "false");
            const POPUP_GLOBAL = \(popupBlockEnabled ? "true" : "false");
            const AD_DISABLED = new Set(\(adDisabledJSON));
            const POPUP_DISABLED = new Set(\(popupDisabledJSON));
            const AD_DOMAINS = \(adDomainsJSON);

            const rawHost = (location.hostname || '').toLowerCase();
            const host = rawHost.startsWith('www.') ? rawHost.slice(4) : rawHost;
            const adActive = AD_GLOBAL && !AD_DISABLED.has(host);
            const popupActive = POPUP_GLOBAL && !POPUP_DISABLED.has(host);

            function report(kind, target) {
                try {
                    window.webkit.messageHandlers.\(Self.messageHandlerName).postMessage({
                        kind: kind,
                        sourceHost: host,
                        target: String(target || '').slice(0, 220)
                    });
                } catch (e) {}
            }

            function isAdUrl(urlStr) {
                if (!urlStr) return false;
                try {
                    const u = new URL(urlStr, location.href);
                    const h = u.hostname.toLowerCase();
                    for (let i = 0; i < AD_DOMAINS.length; i++) {
                        const d = AD_DOMAINS[i];
                        if (h === d || h.endsWith('.' + d)) return true;
                    }
                } catch (e) {}
                return false;
            }

            // 1. Chặn cửa sổ bật lên (window.open)
            if (popupActive) {
                const origOpen = window.open;
                window.open = function(url, name, specs) {
                    report('popup', url || 'window.open()');
                    return null;
                };
            }

            // 2. Chặn và đếm quảng cáo trên trang (DOM + iframe + script)
            if (adActive) {
                const reportedSet = new Set();
                const selectors = [
                    'ins.adsbygoogle',
                    '.adsbygoogle',
                    '[id^="google_ads_iframe"]',
                    '[id^="div-gpt-ad"]',
                    'iframe[src*="doubleclick"]',
                    'iframe[src*="googlesyndication"]',
                    'iframe[src*="admicro"]',
                    'iframe[src*="adtima"]',
                    'iframe[src*="mgid"]',
                    'iframe[src*="exoclick"]',
                    'iframe[src*="adsterra"]',
                    '.ad-banner',
                    '.ads-banner',
                    '.ad-container',
                    '.ads-container',
                    '.sponsored-ad',
                    '.mgbox',
                    '.OUTBRAIN',
                    '.trc_rbox_container'
                ];

                function scanAds(root) {
                    if (!root || !root.querySelectorAll) return;
                    try {
                        const nodes = root.querySelectorAll(selectors.join(','));
                        nodes.forEach(function(el) {
                            if (el.dataset && el.dataset.jinnBlocked) return;
                            if (el.dataset) el.dataset.jinnBlocked = '1';
                            el.style.setProperty('display', 'none', 'important');
                            el.style.setProperty('visibility', 'hidden', 'important');
                            const label = el.getAttribute('src') || el.id || (typeof el.className === 'string' ? el.className.split(' ')[0] : '') || el.tagName;
                            const key = 'ad:' + label;
                            if (!reportedSet.has(key)) {
                                reportedSet.add(key);
                                report('ad', label);
                            }
                        });

                        const iframes = root.querySelectorAll('iframe[src]');
                        iframes.forEach(function(f) {
                            if (f.dataset && f.dataset.jinnBlocked) return;
                            const src = f.getAttribute('src') || '';
                            if (isAdUrl(src)) {
                                if (f.dataset) f.dataset.jinnBlocked = '1';
                                f.style.setProperty('display', 'none', 'important');
                                const key = 'if:' + src;
                                if (!reportedSet.has(key)) {
                                    reportedSet.add(key);
                                    report('ad', src);
                                }
                            }
                        });
                    } catch (e) {}
                }

                if (document.readyState === 'loading') {
                    document.addEventListener('DOMContentLoaded', function() { scanAds(document); }, { once: true });
                } else {
                    scanAds(document);
                }

                let timer = null;
                const observer = new MutationObserver(function() {
                    if (timer) return;
                    timer = setTimeout(function() {
                        timer = null;
                        scanAds(document);
                    }, 350);
                });
                const startObs = function() {
                    if (document.documentElement) {
                        observer.observe(document.documentElement, { childList: true, subtree: true });
                    }
                };
                startObs();
                window.addEventListener('load', function() { scanAds(document); }, { once: true });
            }
        })();
        """

        return WKUserScript(source: source, injectionTime: .atDocumentStart, forMainFrameOnly: false)
    }

    private func encodeStringArray(_ arr: [String]) -> String {
        guard let data = try? JSONSerialization.data(withJSONObject: arr),
              let str = String(data: data, encoding: .utf8) else { return "[]" }
        return str
    }

    // MARK: - Lưu trữ

    private func loadSettings() {
        guard let data = try? Data(contentsOf: settingsFile),
              let s = try? JSONDecoder().decode(AdBlockSettingsData.self, from: data) else { return }
        isLoadingSettings = true
        defer { isLoadingSettings = false }
        adBlockEnabled = s.adBlockEnabled
        popupBlockEnabled = s.popupBlockEnabled
        adDisabledHosts = Set(s.adDisabledHosts)
        popupDisabledHosts = Set(s.popupDisabledHosts)
        customBlockedDomains = s.customBlockedDomains
        totalBlockedAds = s.totalBlockedAds
        totalBlockedPopups = s.totalBlockedPopups
    }

    private func saveSettings() {
        let s = AdBlockSettingsData(
            adBlockEnabled: adBlockEnabled,
            popupBlockEnabled: popupBlockEnabled,
            adDisabledHosts: Array(adDisabledHosts).sorted(),
            popupDisabledHosts: Array(popupDisabledHosts).sorted(),
            customBlockedDomains: customBlockedDomains,
            totalBlockedAds: totalBlockedAds,
            totalBlockedPopups: totalBlockedPopups
        )
        guard let data = try? JSONEncoder().encode(s) else { return }
        let url = settingsFile
        DispatchQueue.global(qos: .utility).async { try? data.write(to: url, options: .atomic) }
    }

    private func loadLog() {
        let dec = JSONDecoder()
        dec.dateDecodingStrategy = .iso8601
        if let data = try? Data(contentsOf: logFile),
           let list = try? dec.decode([BlockedEvent].self, from: data) {
            events = list
        }
    }

    private func saveLog() {
        let enc = JSONEncoder()
        enc.dateEncodingStrategy = .iso8601
        guard let data = try? enc.encode(events) else { return }
        let url = logFile
        DispatchQueue.global(qos: .utility).async { try? data.write(to: url, options: .atomic) }
    }
}

// MARK: - Giao diện kiểm soát & cài đặt Chặn quảng cáo (kiểu Cốc Cốc)

enum AdBlockSheetTab: Int, CaseIterable {
    case overview, log, control

    var title: String {
        switch self {
        case .overview: return "Tổng quan"
        case .log: return "Đã chặn"
        case .control: return "Kiểm soát"
        }
    }
}

struct AdBlockSheetView: View {
    @ObservedObject var tab: BrowserTab
    @ObservedObject private var manager = AdBlockManager.shared
    @Environment(\.dismiss) private var dismiss

    @State private var selectedTab: AdBlockSheetTab = .overview
    @State private var onlyCurrentSite = true
    @State private var newDomain = ""
    @State private var confirmClear = false

    private var currentHost: String? {
        guard tab.hasContent else { return nil }
        return AdBlockManager.normalizedHost(from: tab.urlString)
    }

    private var pageAdActive: Bool { manager.isAdBlockActive(for: currentHost) }
    private var pagePopupActive: Bool { manager.isPopupBlockActive(for: currentHost) }
    private var anyActive: Bool { pageAdActive || pagePopupActive }

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                Picker("Mục", selection: $selectedTab) {
                    ForEach(AdBlockSheetTab.allCases, id: \.self) { t in
                        Text(t.title).tag(t)
                    }
                }
                .pickerStyle(.segmented)
                .padding(.horizontal, 16)
                .padding(.top, 8)
                .padding(.bottom, 10)

                switch selectedTab {
                case .overview: overviewView
                case .log: logView
                case .control: controlView
                }
            }
            .background(Color(.systemGroupedBackground))
            .navigationTitle("Chặn quảng cáo")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Xong") { dismiss() }
                }
            }
            .confirmationDialog("Xóa toàn bộ nhật ký đã chặn?", isPresented: $confirmClear, titleVisibility: .visible) {
                Button("Xóa nhật ký & bộ đếm", role: .destructive) { manager.clearEvents() }
                Button("Hủy", role: .cancel) {}
            }
        }
    }

    // MARK: Tab 1 - Tổng quan (kiểu Cốc Cốc)

    private var overviewView: some View {
        ScrollView {
            VStack(spacing: 16) {
                // Thẻ trạng thái chính
                VStack(spacing: 10) {
                    ZStack {
                        Circle()
                            .fill((anyActive ? Color.green : Color.secondary).opacity(0.15))
                            .frame(width: 64, height: 64)
                        Image(systemName: anyActive ? "checkmark.shield.fill" : "shield.slash.fill")
                            .font(.system(size: 32))
                            .foregroundStyle(anyActive ? .green : .secondary)
                    }
                    Text(anyActive ? "Chặn quảng cáo đang bật" : "Chặn quảng cáo đang tắt")
                        .font(.title3.bold())
                    Text(currentHost != nil
                         ? (anyActive ? "Đang chặn quảng cáo và cửa sổ bật lên trên trang này" : "Đã tạm dừng chặn trên trang này")
                         : (anyActive ? "Đang bảo vệ tất cả các trang bạn truy cập" : "Tính năng chặn quảng cáo toàn cục đang tắt"))
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                        .multilineTextAlignment(.center)
                }
                .padding(.vertical, 18)
                .padding(.horizontal, 16)
                .frame(maxWidth: .infinity)
                .background(Color(.secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 18))

                // Thẻ điều khiển cho trang hiện tại (nếu đang mở trang web)
                if let host = currentHost {
                    VStack(spacing: 0) {
                        HStack {
                            Text("Trang web").foregroundStyle(.secondary)
                            Spacer()
                            Text(host).fontWeight(.semibold)
                        }
                        .padding(.horizontal, 16).padding(.vertical, 14)

                        Divider().padding(.leading, 16)

                        Toggle(isOn: Binding(
                            get: { pageAdActive },
                            set: { val in
                                manager.setAdBlock(val, for: host)
                                tab.reload()
                            }
                        )) {
                            Label("Chặn quảng cáo trên trang này", systemImage: "nosign")
                        }
                        .tint(.green)
                        .padding(.horizontal, 16).padding(.vertical, 12)

                        Divider().padding(.leading, 16)

                        Toggle(isOn: Binding(
                            get: { pagePopupActive },
                            set: { val in
                                manager.setPopupBlock(val, for: host)
                                tab.reload()
                            }
                        )) {
                            Label("Chặn cửa sổ bật lên từ trang này", systemImage: "macwindow.badge.plus")
                        }
                        .tint(.green)
                        .padding(.horizontal, 16).padding(.vertical, 12)
                    }
                    .background(Color(.secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 18))

                    Text("Hãy thử tạm dừng chặn nếu trang web bạn đang xem không hoạt động đúng.")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(.horizontal, 6)
                }

                // Thống kê nhanh
                HStack(spacing: 12) {
                    statCard(
                        title: currentHost != nil ? "Quảng cáo trang này" : "Tổng quảng cáo",
                        value: currentHost != nil ? tab.blockedAdsOnPage : manager.totalBlockedAds,
                        icon: "nosign",
                        color: .orange
                    )
                    statCard(
                        title: currentHost != nil ? "Popup trang này" : "Tổng popup",
                        value: currentHost != nil ? tab.blockedPopupsOnPage : manager.totalBlockedPopups,
                        icon: "macwindow.badge.plus",
                        color: .purple
                    )
                }

                // Công tắc toàn cục
                VStack(spacing: 0) {
                    Toggle(isOn: $manager.adBlockEnabled) {
                        Label("Bật chặn quảng cáo mặc định", systemImage: "shield.lefthalf.filled")
                    }
                    .tint(.green)
                    .padding(.horizontal, 16).padding(.vertical, 12)

                    Divider().padding(.leading, 16)

                    Toggle(isOn: $manager.popupBlockEnabled) {
                        Label("Bật chặn cửa sổ bật lên mặc định", systemImage: "rectangle.stack.badge.minus")
                    }
                    .tint(.green)
                    .padding(.horizontal, 16).padding(.vertical, 12)
                }
                .background(Color(.secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 18))

                // Nút xem nhật ký nhanh
                Button {
                    selectedTab = .log
                } label: {
                    HStack {
                        Label("Xem các quảng cáo & popup đã chặn", systemImage: "list.bullet.rectangle")
                        Spacer()
                        Text("\(manager.events.count)")
                            .font(.subheadline.weight(.semibold))
                            .foregroundStyle(.secondary)
                        Image(systemName: "chevron.right")
                            .font(.caption.weight(.semibold))
                            .foregroundStyle(.secondary)
                    }
                    .foregroundStyle(.primary)
                    .padding(.horizontal, 16).padding(.vertical, 14)
                    .background(Color(.secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 18))
                }
                .buttonStyle(.plain)
            }
            .padding(16)
        }
    }

    private func statCard(title: String, value: Int, icon: String, color: Color) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack {
                Image(systemName: icon).foregroundStyle(color)
                Spacer()
                Text("\(value)").font(.title2.bold())
            }
            Text(title).font(.caption).foregroundStyle(.secondary)
        }
        .padding(14)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color(.secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 16))
    }

    // MARK: Tab 2 - Nhật ký đã chặn

    private var displayedEvents: [BlockedEvent] {
        if onlyCurrentSite, let host = currentHost {
            return manager.events(for: host)
        }
        return manager.events
    }

    private var logView: some View {
        List {
            if currentHost != nil {
                Section {
                    Toggle("Chỉ hiển thị trang hiện tại (\(currentHost ?? ""))", isOn: $onlyCurrentSite)
                        .tint(.green)
                }
            }

            Section {
                if displayedEvents.isEmpty {
                    ContentUnavailableView(
                        "Chưa có mục nào bị chặn",
                        systemImage: "checkmark.shield",
                        description: Text("Khi trình duyệt chặn quảng cáo hoặc cửa sổ bật lên, chi tiết sẽ hiển thị ở đây để bạn kiểm tra.")
                    )
                    .listRowBackground(Color.clear)
                } else {
                    ForEach(displayedEvents) { ev in
                        HStack(spacing: 12) {
                            Image(systemName: ev.kind.icon)
                                .font(.body.weight(.semibold))
                                .foregroundStyle(ev.kind == .popup ? .purple : .orange)
                                .frame(width: 28)
                            VStack(alignment: .leading, spacing: 3) {
                                Text(ev.target)
                                    .font(.subheadline.weight(.medium))
                                    .lineLimit(2)
                                HStack(spacing: 6) {
                                    Text(ev.kind.title)
                                        .font(.caption2.weight(.semibold))
                                        .padding(.horizontal, 6).padding(.vertical, 2)
                                        .background((ev.kind == .popup ? Color.purple : Color.orange).opacity(0.15), in: Capsule())
                                    Text(ev.sourceHost)
                                        .font(.caption)
                                        .foregroundStyle(.secondary)
                                        .lineLimit(1)
                                    Spacer(minLength: 0)
                                    Text(ev.date, style: .time)
                                        .font(.caption2)
                                        .foregroundStyle(.secondary)
                                }
                            }
                        }
                        .padding(.vertical, 2)
                        .swipeActions(edge: .trailing) {
                            if ev.kind == .popup, let url = URL(string: ev.target), url.scheme?.hasPrefix("http") == true {
                                Button("Mở") {
                                    tab.load(url.absoluteString)
                                    dismiss()
                                }
                                .tint(.blue)
                            }
                        }
                    }
                }
            } header: {
                HStack {
                    Text("Tổng cộng: \(manager.totalBlockedAds) quảng cáo • \(manager.totalBlockedPopups) popup")
                    Spacer()
                    if !manager.events.isEmpty {
                        Button("Xóa", role: .destructive) { confirmClear = true }
                            .font(.caption)
                    }
                }
            }
        }
        .listStyle(.insetGrouped)
    }

    // MARK: Tab 3 - Kiểm soát ngoại lệ & bộ lọc tùy chỉnh

    private var controlView: some View {
        List {
            Section("Trang web tạm dừng chặn quảng cáo") {
                if manager.adDisabledHosts.isEmpty {
                    Text("Không có trang web ngoại lệ").foregroundStyle(.secondary)
                } else {
                    ForEach(Array(manager.adDisabledHosts).sorted(), id: \.self) { host in
                        HStack {
                            Text(host)
                            Spacer()
                            Button("Bật lại chặn") {
                                manager.adDisabledHosts.remove(host)
                                if host == currentHost { tab.reload() }
                            }
                            .font(.caption.weight(.semibold))
                        }
                    }
                }
            }

            Section("Trang web cho phép cửa sổ bật lên") {
                if manager.popupDisabledHosts.isEmpty {
                    Text("Không có trang web ngoại lệ").foregroundStyle(.secondary)
                } else {
                    ForEach(Array(manager.popupDisabledHosts).sorted(), id: \.self) { host in
                        HStack {
                            Text(host)
                            Spacer()
                            Button("Chặn lại") {
                                manager.popupDisabledHosts.remove(host)
                                if host == currentHost { tab.reload() }
                            }
                            .font(.caption.weight(.semibold))
                        }
                    }
                }
            }

            Section {
                HStack {
                    TextField("Nhập tên miền cần chặn (vd: ads.example.com)", text: $newDomain)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                        .keyboardType(.URL)
                    Button("Thêm") {
                        manager.addCustomDomain(newDomain)
                        newDomain = ""
                    }
                    .disabled(newDomain.trimmingCharacters(in: .whitespaces).isEmpty)
                }
                ForEach(manager.customBlockedDomains, id: \.self) { d in
                    Text(d)
                }
                .onDelete { offsets in
                    for i in offsets {
                        manager.removeCustomDomain(manager.customBlockedDomains[i])
                    }
                }
            } header: {
                Text("Tên miền chặn thủ công")
            } footer: {
                Text("Đang áp dụng \(manager.allBlockedDomains.count) bộ lọc tên miền quảng cáo và trình theo dõi.")
            }
        }
        .listStyle(.insetGrouped)
    }
}
