import Foundation
import Security

/// Lưu dữ liệu nhạy cảm trong Keychain. Nếu bản sideload bị gỡ quyền Keychain thì dùng UserDefaults làm dự phòng.
enum SecureStore {
    private static let service = "com.jinn.JinnFiles"

    static func set(_ key: String, _ data: Data) {
        let q: [String: Any] = [kSecClass as String: kSecClassGenericPassword,
                                kSecAttrService as String: service,
                                kSecAttrAccount as String: key]
        SecItemDelete(q as CFDictionary)
        var a = q
        a[kSecValueData as String] = data
        a[kSecAttrAccessible as String] = kSecAttrAccessibleAfterFirstUnlock
        let st = SecItemAdd(a as CFDictionary, nil)
        if st == errSecSuccess {
            UserDefaults.standard.removeObject(forKey: "secure." + key)
        } else {
            UserDefaults.standard.set(data, forKey: "secure." + key)
        }
    }

    static func get(_ key: String) -> Data? {
        let q: [String: Any] = [kSecClass as String: kSecClassGenericPassword,
                                kSecAttrService as String: service,
                                kSecAttrAccount as String: key,
                                kSecReturnData as String: true,
                                kSecMatchLimit as String: kSecMatchLimitOne]
        var out: CFTypeRef?
        if SecItemCopyMatching(q as CFDictionary, &out) == errSecSuccess, let d = out as? Data { return d }
        return UserDefaults.standard.data(forKey: "secure." + key)
    }

    static func delete(_ key: String) {
        let q: [String: Any] = [kSecClass as String: kSecClassGenericPassword,
                                kSecAttrService as String: service,
                                kSecAttrAccount as String: key]
        SecItemDelete(q as CFDictionary)
        UserDefaults.standard.removeObject(forKey: "secure." + key)
    }
}
