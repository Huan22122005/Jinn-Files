import SwiftUI

enum AppearanceMode: String, CaseIterable, Identifiable {
    case system, light, dark
    var id: String { rawValue }
    var title: String {
        switch self {
        case .system: return "Theo hệ thống"
        case .light: return "Sáng"
        case .dark: return "Tối"
        }
    }
    var scheme: ColorScheme? {
        switch self {
        case .system: return nil
        case .light: return .light
        case .dark: return .dark
        }
    }
}

@available(iOS 26.0, *)
private func makeGlass(tint: Color?, interactive: Bool) -> Glass {
    var g = Glass.regular
    if let tint { g = g.tint(tint) }
    if interactive { g = g.interactive() }
    return g
}

extension View {
    /// Bề mặt kính (Liquid Glass trên iOS 26+, vật liệu mờ trên bản cũ hơn)
    @ViewBuilder
    func glassSurface(cornerRadius: CGFloat = 24, tint: Color? = nil, interactive: Bool = false) -> some View {
        if #available(iOS 26.0, *) {
            self.glassEffect(makeGlass(tint: tint, interactive: interactive),
                             in: RoundedRectangle(cornerRadius: cornerRadius))
        } else {
            self.background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: cornerRadius))
        }
    }

    /// Nút tròn bằng kính
    @ViewBuilder
    func glassCircle(size: CGFloat = 44) -> some View {
        if #available(iOS 26.0, *) {
            self.frame(width: size, height: size).glassEffect(.regular.interactive(), in: Circle())
        } else {
            self.frame(width: size, height: size).background(.ultraThinMaterial, in: Circle())
        }
    }

    @ViewBuilder
    func glassButtonStyle(prominent: Bool = false) -> some View {
        if #available(iOS 26.0, *) {
            if prominent { self.buttonStyle(.glassProminent) } else { self.buttonStyle(.glass) }
        } else {
            if prominent { self.buttonStyle(.borderedProminent) } else { self.buttonStyle(.bordered) }
        }
    }
}

/// Bảng màu chủ đề của ứng dụng
enum AppTheme: String, CaseIterable, Identifiable {
    case blue, sunset, ruby, titan, ocean, indigo, emerald
    var id: String { rawValue }

    var title: String {
        switch self {
        case .blue: return "Xanh dương"
        case .sunset: return "Hoàng hôn"
        case .ruby: return "Hồng ngọc"
        case .titan: return "Titan"
        case .ocean: return "Đại dương"
        case .indigo: return "Tím chàm"
        case .emerald: return "Lục bảo"
        }
    }

    private static func c(_ r: Double, _ g: Double, _ b: Double) -> Color { Color(red: r, green: g, blue: b) }

    var accent: Color {
        switch self {
        case .blue: return Self.c(0.04, 0.52, 1.0)
        case .sunset: return Self.c(1.0, 0.45, 0.20)
        case .ruby: return Self.c(0.88, 0.10, 0.38)
        case .titan: return Self.c(0.50, 0.54, 0.60)
        case .ocean: return Self.c(0.0, 0.60, 0.80)
        case .indigo: return Self.c(0.37, 0.30, 0.85)
        case .emerald: return Self.c(0.07, 0.65, 0.45)
        }
    }

    /// Ba mảng màu mờ phía sau lớp kính
    var blobs: [Color] {
        switch self {
        case .blue: return [Self.c(0.1, 0.45, 1.0), Self.c(0.6, 0.3, 0.9), Self.c(0.2, 0.8, 0.95)]
        case .sunset: return [Self.c(1.0, 0.5, 0.1), Self.c(0.95, 0.25, 0.5), Self.c(1.0, 0.8, 0.2)]
        case .ruby: return [Self.c(0.9, 0.1, 0.4), Self.c(0.6, 0.05, 0.25), Self.c(1.0, 0.4, 0.55)]
        case .titan: return [Self.c(0.6, 0.63, 0.68), Self.c(0.4, 0.43, 0.5), Self.c(0.75, 0.78, 0.82)]
        case .ocean: return [Self.c(0.0, 0.55, 0.8), Self.c(0.0, 0.35, 0.65), Self.c(0.2, 0.85, 0.85)]
        case .indigo: return [Self.c(0.35, 0.3, 0.85), Self.c(0.55, 0.25, 0.8), Self.c(0.25, 0.45, 0.95)]
        case .emerald: return [Self.c(0.07, 0.65, 0.45), Self.c(0.0, 0.5, 0.4), Self.c(0.45, 0.85, 0.6)]
        }
    }

    var lightGradient: [Color] {
        switch self {
        case .blue: return [Self.c(0.88, 0.94, 1.0), Self.c(0.94, 0.90, 1.0)]
        case .sunset: return [Self.c(1.0, 0.93, 0.86), Self.c(1.0, 0.88, 0.92)]
        case .ruby: return [Self.c(1.0, 0.90, 0.93), Self.c(0.98, 0.86, 0.90)]
        case .titan: return [Self.c(0.93, 0.94, 0.95), Self.c(0.88, 0.89, 0.91)]
        case .ocean: return [Self.c(0.86, 0.96, 1.0), Self.c(0.84, 0.94, 0.97)]
        case .indigo: return [Self.c(0.91, 0.90, 1.0), Self.c(0.95, 0.90, 1.0)]
        case .emerald: return [Self.c(0.87, 0.98, 0.93), Self.c(0.86, 0.95, 0.97)]
        }
    }

    var darkGradient: [Color] {
        switch self {
        case .blue: return [Self.c(0.03, 0.06, 0.15), Self.c(0.09, 0.05, 0.20)]
        case .sunset: return [Self.c(0.18, 0.07, 0.05), Self.c(0.20, 0.05, 0.14)]
        case .ruby: return [Self.c(0.17, 0.03, 0.08), Self.c(0.12, 0.02, 0.07)]
        case .titan: return [Self.c(0.08, 0.09, 0.10), Self.c(0.14, 0.15, 0.17)]
        case .ocean: return [Self.c(0.0, 0.07, 0.14), Self.c(0.0, 0.11, 0.17)]
        case .indigo: return [Self.c(0.06, 0.05, 0.18), Self.c(0.10, 0.05, 0.22)]
        case .emerald: return [Self.c(0.02, 0.12, 0.09), Self.c(0.02, 0.10, 0.13)]
        }
    }
}

/// Nền có màu nhẹ để lớp kính có thứ để khúc xạ, đổi theo bảng màu đã chọn
struct AppBackground: View {
    @Environment(\.colorScheme) private var scheme
    @AppStorage("theme") private var themeID = AppTheme.blue.rawValue
    private var theme: AppTheme { AppTheme(rawValue: themeID) ?? .blue }

    var body: some View {
        let dark = scheme == .dark
        ZStack {
            LinearGradient(colors: dark ? theme.darkGradient : theme.lightGradient,
                           startPoint: .topLeading, endPoint: .bottomTrailing)
            Circle().fill(theme.blobs[0].opacity(dark ? 0.30 : 0.22))
                .frame(width: 320).blur(radius: 70).offset(x: -120, y: -260)
            Circle().fill(theme.blobs[1].opacity(dark ? 0.26 : 0.18))
                .frame(width: 300).blur(radius: 80).offset(x: 140, y: 120)
            Circle().fill(theme.blobs[2].opacity(dark ? 0.18 : 0.16))
                .frame(width: 260).blur(radius: 70).offset(x: -90, y: 330)
        }
        .ignoresSafeArea()
    }
}
