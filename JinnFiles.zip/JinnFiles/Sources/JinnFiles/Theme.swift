import SwiftUI

enum AppearanceMode: String, CaseIterable, Identifiable {
    case system, light, dark
    var id: String { rawValue }
    var title: String {
        switch self {
        case .system: return "Theo hệ thống"
        case .light: return "Sáng"
        case .dark: return "Tối"
        }
    }
    var scheme: ColorScheme? {
        switch self {
        case .system: return nil
        case .light: return .light
        case .dark: return .dark
        }
    }
}

@available(iOS 26.0, *)
private func makeGlass(tint: Color?, interactive: Bool) -> Glass {
    var g = Glass.regular
    if let tint { g = g.tint(tint) }
    if interactive { g = g.interactive() }
    return g
}

extension View {
    /// Bề mặt kính (Liquid Glass trên iOS 26+, vật liệu mờ trên bản cũ hơn)
    @ViewBuilder
    func glassSurface(cornerRadius: CGFloat = 24, tint: Color? = nil, interactive: Bool = false) -> some View {
        if #available(iOS 26.0, *) {
            self.glassEffect(makeGlass(tint: tint, interactive: interactive),
                             in: RoundedRectangle(cornerRadius: cornerRadius))
        } else {
            self.background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: cornerRadius))
        }
    }

    /// Nút tròn bằng kính
    @ViewBuilder
    func glassCircle(size: CGFloat = 44) -> some View {
        if #available(iOS 26.0, *) {
            self.frame(width: size, height: size).glassEffect(.regular.interactive(), in: Circle())
        } else {
            self.frame(width: size, height: size).background(.ultraThinMaterial, in: Circle())
        }
    }

    @ViewBuilder
    func glassButtonStyle(prominent: Bool = false) -> some View {
        if #available(iOS 26.0, *) {
            if prominent { self.buttonStyle(.glassProminent) } else { self.buttonStyle(.glass) }
        } else {
            if prominent { self.buttonStyle(.borderedProminent) } else { self.buttonStyle(.bordered) }
        }
    }
}

/// Nền có màu nhẹ để lớp kính có thứ để khúc xạ
struct AppBackground: View {
    @Environment(\.colorScheme) private var scheme
    var body: some View {
        ZStack {
            LinearGradient(
                colors: scheme == .dark
                    ? [Color(red: 0.03, green: 0.06, blue: 0.15), Color(red: 0.09, green: 0.05, blue: 0.20)]
                    : [Color(red: 0.88, green: 0.94, blue: 1.0), Color(red: 0.94, green: 0.90, blue: 1.0)],
                startPoint: .topLeading, endPoint: .bottomTrailing)
            Circle().fill(Color.blue.opacity(scheme == .dark ? 0.30 : 0.22))
                .frame(width: 320).blur(radius: 70).offset(x: -120, y: -260)
            Circle().fill(Color.purple.opacity(scheme == .dark ? 0.26 : 0.18))
                .frame(width: 300).blur(radius: 80).offset(x: 140, y: 120)
            Circle().fill(Color.cyan.opacity(scheme == .dark ? 0.18 : 0.16))
                .frame(width: 260).blur(radius: 70).offset(x: -90, y: 330)
        }
        .ignoresSafeArea()
    }
}
