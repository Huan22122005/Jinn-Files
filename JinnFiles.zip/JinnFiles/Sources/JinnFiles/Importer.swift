import Foundation

/// Nhập tệp từ vị trí gốc (không để bộ chọn sao chép trước hàng loạt).
/// Từng tệp được sao chép riêng, lỗi một tệp không làm hỏng cả lô.
enum ImportOps {
    static func run(_ urls: [URL], here: URL, progress: @Sendable (Double) -> Void) -> String {
        var ok = 0
        var failed: [String] = []
        for (i, u) in urls.enumerated() {
            do { try copyOne(u, here: here); ok += 1 }
            catch { failed.append("• \(u.lastPathComponent): \(error.localizedDescription)") }
            progress(Double(i + 1) / Double(max(urls.count, 1)))
        }
        var msg = "Đã nhập \(ok)/\(urls.count) tệp."
        if !failed.isEmpty {
            msg += "\nLỗi:\n" + failed.prefix(5).joined(separator: "\n")
            if failed.count > 5 { msg += "\n…và \(failed.count - 5) lỗi khác" }
        }
        return msg
    }

    private static func copyOne(_ u: URL, here: URL) throws {
        let fm = FileManager.default
        let isDir = (try? u.resourceValues(forKeys: [.isDirectoryKey]))?.isDirectory ?? false
        let kind = Kind.detect(u, isDirectory: isDir)
        let atRoot = here.resolvingSymlinksInPath() == Paths.files.resolvingSymlinksInPath()
        let dir = atRoot ? Paths.category(for: kind) : here
        try fm.createDirectory(at: dir, withIntermediateDirectories: true)
        try FileOps.checkSpace(needed: FileOps.size(of: u))

        // Sao chép vào tệp tạm ẩn rồi mới đổi tên: không bao giờ để lại tệp dở dang trong danh sách
        let tmp = dir.appendingPathComponent(".jinn-import-\(UUID().uuidString).part")
        var coordErr: NSError?
        var inner: Error?
        // NSFileCoordinator cũng tự tải tệp iCloud chưa có trên máy
        NSFileCoordinator().coordinate(readingItemAt: u, options: [], error: &coordErr) { r in
            do { try fm.copyItem(at: r, to: tmp) } catch { inner = error }
        }
        if let e = coordErr { throw e }
        if let e = inner { try? fm.removeItem(at: tmp); throw e }
        do { try fm.moveItem(at: tmp, to: FileOps.uniqueURL(dir: dir, name: u.lastPathComponent)) }
        catch { try? fm.removeItem(at: tmp); throw error }
    }
}

enum ExternalAccess {
    /// Đảm bảo tệp ngoài đã sẵn sàng đọc (tải từ iCloud nếu cần). Trả về nội dung lỗi nếu thất bại.
    static func materialize(_ u: URL) -> String? {
        var cerr: NSError?
        var readable = false
        NSFileCoordinator().coordinate(readingItemAt: u, options: [], error: &cerr) { r in
            readable = FileManager.default.isReadableFile(atPath: r.path)
        }
        if let e = cerr { return e.localizedDescription }
        return readable ? nil : "Không có quyền đọc tệp này."
    }
}
