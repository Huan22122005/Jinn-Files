import SwiftUI
import AVKit
import Combine
import UniformTypeIdentifiers

// MARK: - Cổng vào: kiểm tra đăng nhập và quyền

struct GoogleDriveBrowser: View {
    @EnvironmentObject private var auth: GoogleAuth

    var body: some View {
        if !auth.isSignedIn {
            ContentUnavailableView("Chưa đăng nhập", systemImage: "person.crop.circle.badge.exclamationmark",
                                   description: Text("Đăng nhập Google ở tab Tài khoản để dùng Google Drive."))
                .navigationTitle("Google Drive")
        } else if !auth.canUseDrive {
            VStack(spacing: 14) {
                ContentUnavailableView("Cần cấp quyền Google Drive", systemImage: "lock.open",
                                       description: Text("Hãy đăng nhập lại và đồng ý cấp quyền Google Drive cho Jinn Files."))
                Button("Đăng nhập lại") { Task { await auth.signIn() } }
                    .glassButtonStyle(prominent: true).controlSize(.large)
            }
            .navigationTitle("Google Drive")
        } else {
            DriveFolderView(folder: .root)
        }
    }
}

// MARK: - Model một thư mục Drive

@MainActor
final class DriveFolderModel: ObservableObject {
    let folder: DriveFolderRef
    @Published var items: [DriveFile] = []
    @Published var results: [DriveFile] = []
    @Published var loading = false
    @Published var finished = false
    @Published var message: String?
    @Published var busy: String?
    @Published var selecting = false
    @Published var selection = Set<String>()
    private var nextToken: String?
    private var searchGen = 0

    init(folder: DriveFolderRef) { self.folder = folder }

    func reload() async {
        nextToken = nil; finished = false
        await loadMore(replace: true)
    }

    func loadMore(replace: Bool = false) async {
        guard !loading, !finished || replace else { return }
        loading = true
        defer { loading = false }
        do {
            let (files, next) = try await DriveAPI.list(parent: folder.id, pageToken: replace ? nil : nextToken)
            if replace { items = files } else {
                let known = Set(items.map(\.id))
                items += files.filter { !known.contains($0.id) }
            }
            nextToken = next
            finished = next == nil
        } catch {
            message = error.localizedDescription
            finished = true
        }
    }

    func search(_ q: String) async {
        searchGen += 1
        let g = searchGen
        guard !q.isEmpty else { results = []; return }
        try? await Task.sleep(nanoseconds: 350_000_000)   // chờ người dùng gõ xong
        guard g == searchGen else { return }
        do {
            let r = try await DriveAPI.search(q)
            if g == searchGen { results = r }
        } catch { message = error.localizedDescription }
    }

    func toggle(_ f: DriveFile) {
        if selection.contains(f.id) { selection.remove(f.id) } else { selection.insert(f.id) }
    }

    func endSelecting() { selecting = false; selection.removeAll() }

    func run(_ title: String, _ work: @escaping () async throws -> String) async {
        busy = title
        do { message = try await work() } catch { message = error.localizedDescription }
        busy = nil
        endSelecting()
        await reload()
    }

    func createFolder(_ name: String) async {
        let n = name.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !n.isEmpty else { message = "Tên thư mục không được để trống."; return }
        await run("Đang tạo thư mục…") { try await DriveAPI.createFolder(name: n, parent: self.folder.id); return "Đã tạo thư mục." }
    }

    func rename(_ f: DriveFile, to name: String) async {
        let n = name.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !n.isEmpty, n != f.name else { return }
        await run("Đang đổi tên…") { try await DriveAPI.rename(f.id, to: n); return "Đã đổi tên." }
    }

    func trash(_ files: [DriveFile]) async {
        await run("Đang chuyển vào thùng rác…") {
            for f in files { try await DriveAPI.trash(f.id) }
            return "Đã chuyển \(files.count) mục vào thùng rác Google Drive (giữ 30 ngày)."
        }
    }

    func deleteForever(_ files: [DriveFile]) async {
        await run("Đang xóa vĩnh viễn…") {
            for f in files { try await DriveAPI.deleteForever(f.id) }
            return "Đã xóa vĩnh viễn \(files.count) mục."
        }
    }

    func move(_ files: [DriveFile], to dest: DriveFolderRef) async {
        await run("Đang di chuyển…") {
            for f in files where f.id != dest.id { try await DriveAPI.move(f, to: dest.id) }
            return "Đã di chuyển \(files.count) mục vào \(dest.name)."
        }
    }

    func copy(_ files: [DriveFile], to dest: DriveFolderRef) async {
        await run("Đang sao chép…") {
            let only = files.filter { !$0.isFolder }
            for f in only { try await DriveAPI.copy(f, to: dest.id) }
            let skipped = files.count - only.count
            return "Đã sao chép \(only.count) tệp." + (skipped > 0 ? " Google Drive không hỗ trợ sao chép thư mục (\(skipped) thư mục bị bỏ qua)." : "")
        }
    }

    func download(_ files: [DriveFile], to dir: URL) async {
        await run("Đang tải về…") {
            var ok = 0
            var failed: [String] = []
            for f in files {
                do { try await DriveAPI.downloadTree(f, into: dir); ok += 1 }
                catch { failed.append("• \(f.name): \(error.localizedDescription)") }
            }
            var m = "Đã tải về \(ok)/\(files.count) mục."
            if !failed.isEmpty { m += "\nLỗi:\n" + failed.prefix(4).joined(separator: "\n") }
            return m
        }
    }
}

// MARK: - Hình thu nhỏ

struct DriveThumb: View {
    let file: DriveFile
    @State private var image: UIImage?

    var body: some View {
        ZStack {
            if let image {
                Image(uiImage: image).resizable().scaledToFill()
            } else {
                Image(systemName: file.kind.symbol).font(.system(size: 26)).foregroundStyle(file.kind.tint)
            }
        }
        .task(id: file.id) {
            if !file.isFolder && file.thumbnail != nil { image = await DriveAPI.thumbnail(file) }
        }
    }
}

// MARK: - Màn hình thư mục Drive

enum DriveSheet: Identifiable {
    case move([DriveFile]), copy([DriveFile]), download([DriveFile])
    var id: String {
        switch self {
        case .move(let f): return "m" + (f.first?.id ?? "")
        case .copy(let f): return "c" + (f.first?.id ?? "")
        case .download(let f): return "d" + (f.first?.id ?? "")
        }
    }
}

struct DriveFolderView: View {
    let folder: DriveFolderRef
    @EnvironmentObject private var uploader: DriveUploader
    @StateObject private var model: DriveFolderModel
    @AppStorage("driveViewMode") private var mode = "list"
    @AppStorage("driveSortKey") private var sortKey = "name"
    @AppStorage("driveSortAsc") private var sortAsc = true

    @State private var query = ""
    @State private var sheet: DriveSheet?
    @State private var showNew = false
    @State private var newName = ""
    @State private var renameTarget: DriveFile?
    @State private var showRename = false
    @State private var renameText = ""
    @State private var pendingDelete: [DriveFile] = []
    @State private var showDelete = false
    @State private var showLocalPicker = false
    @State private var showImporter = false

    init(folder: DriveFolderRef) {
        self.folder = folder
        _model = StateObject(wrappedValue: DriveFolderModel(folder: folder))
    }

    private var displayed: [DriveFile] {
        let base = query.isEmpty ? model.items : model.results
        let cmp: (DriveFile, DriveFile) -> Bool = { a, b in
            let r: Bool
            switch sortKey {
            case "size":
                let x = a.size ?? 0, y = b.size ?? 0
                r = x == y ? a.name.localizedStandardCompare(b.name) == .orderedAscending : x < y
            case "date": r = (a.modified ?? .distantPast) < (b.modified ?? .distantPast)
            default: r = a.name.localizedStandardCompare(b.name) == .orderedAscending
            }
            return sortAsc ? r : !r
        }
        return base.filter(\.isFolder).sorted(by: cmp) + base.filter { !$0.isFolder }.sorted(by: cmp)
    }

    private var selectedFiles: [DriveFile] { displayed.filter { model.selection.contains($0.id) } }
    private var allSelected: Bool { !displayed.isEmpty && displayed.allSatisfy { model.selection.contains($0.id) } }

    var body: some View {
        let items = displayed
        ScrollView {
            VStack(spacing: 10) {
                if !uploader.jobs.isEmpty { UploadQueueView().padding(.horizontal, 12) }
                if items.isEmpty && !model.loading {
                    ContentUnavailableView(query.isEmpty ? "Thư mục trống" : "Không tìm thấy", systemImage: "folder",
                                           description: Text(query.isEmpty ? "Bấm ⋯ để tạo thư mục hoặc tải tệp lên." : "Thử từ khóa khác."))
                        .padding(.top, 40)
                } else if mode == "grid" {
                    gridView(items)
                } else {
                    listView(items)
                }
                if model.loading { ProgressView().padding() }
            }
        }
        .navigationTitle(folder.name)
        .navigationBarTitleDisplayMode(.inline)
        .searchable(text: $query, prompt: "Tìm trong Google Drive")
        .onChange(of: query) { _, q in Task { await model.search(q) } }
        .refreshable { await model.reload() }
        .task { if model.items.isEmpty && !model.finished { await model.reload() } }
        .onChange(of: uploader.version) { _, _ in Task { await model.reload() } }
        .toolbar { toolbar }
        .toolbar(model.selecting ? .hidden : .visible, for: .tabBar)
        .overlay { busyOverlay }
        .safeAreaInset(edge: .bottom) { if model.selecting { selectionBar } }
        .sheet(item: $sheet) { s in sheetContent(s) }
        .sheet(isPresented: $showLocalPicker) {
            LocalFilePickerSheet(rootTitle: "Chọn tệp để tải lên", icon: "icloud.and.arrow.up", allowFolders: true,
                                 actionTitle: { "Tải lên \($0) mục" }) { urls in
                uploader.enqueue(urls, parentId: folder.id)
            }
        }
        .fileImporter(isPresented: $showImporter, allowedContentTypes: [.item], allowsMultipleSelection: true) { r in
            if case .success(let urls) = r { uploader.enqueue(urls, parentId: folder.id) }
        }
        .alert("Thông báo", isPresented: Binding(get: { model.message != nil }, set: { if !$0 { model.message = nil } })) {
            Button("OK") { model.message = nil }
        } message: { Text(model.message ?? "") }
        .alert("Thư mục mới", isPresented: $showNew) {
            TextField("Tên thư mục", text: $newName)
            Button("Hủy", role: .cancel) {}
            Button("Tạo") { let n = newName; Task { await model.createFolder(n) } }
        }
        .alert("Đổi tên", isPresented: $showRename) {
            TextField("Tên mới", text: $renameText)
            Button("Hủy", role: .cancel) {}
            Button("Lưu") { if let t = renameTarget { let n = renameText; Task { await model.rename(t, to: n) } } }
        }
        .confirmationDialog("Xóa \(pendingDelete.count) mục?", isPresented: $showDelete, titleVisibility: .visible) {
            Button("Chuyển vào thùng rác Google Drive") { let f = pendingDelete; Task { await model.trash(f) } }
            Button("Xóa vĩnh viễn", role: .destructive) { let f = pendingDelete; Task { await model.deleteForever(f) } }
            Button("Hủy", role: .cancel) {}
        } message: { Text("Thùng rác của Google Drive giữ mục 30 ngày. Xóa vĩnh viễn không thể khôi phục.") }
    }

    // MARK: Thanh công cụ

    @ToolbarContentBuilder
    private var toolbar: some ToolbarContent {
        ToolbarItem(placement: .topBarTrailing) {
            if model.selecting {
                HStack(spacing: 14) {
                    Button(allSelected ? "Bỏ chọn" : "Chọn tất cả") {
                        let ids = Set(displayed.map(\.id))
                        if allSelected { model.selection.subtract(ids) } else { model.selection.formUnion(ids) }
                    }
                    Button("Xong") { model.endSelecting() }
                }
            } else {
                Menu {
                    Picker("Chế độ xem", selection: $mode) {
                        Label("Danh sách", systemImage: "list.bullet").tag("list")
                        Label("Lưới", systemImage: "square.grid.2x2").tag("grid")
                    }
                    Picker("Sắp xếp", selection: $sortKey) {
                        Text("Tên").tag("name"); Text("Dung lượng").tag("size"); Text("Ngày chỉnh sửa").tag("date")
                    }
                    Picker("Thứ tự", selection: $sortAsc) {
                        Label("Tăng dần", systemImage: "arrow.up").tag(true)
                        Label("Giảm dần", systemImage: "arrow.down").tag(false)
                    }
                    Divider()
                    Button { newName = ""; showNew = true } label: { Label("Thư mục mới", systemImage: "folder.badge.plus") }
                    Button { showLocalPicker = true } label: { Label("Tải lên từ Jinn Files", systemImage: "icloud.and.arrow.up") }
                    Button { showImporter = true } label: { Label("Tải lên từ app Tệp", systemImage: "square.and.arrow.up.on.square") }
                    Button { model.selecting = true } label: { Label("Chọn nhiều", systemImage: "checkmark.circle") }
                    Button { Task { await model.reload() } } label: { Label("Làm mới", systemImage: "arrow.clockwise") }
                } label: { Image(systemName: "ellipsis.circle") }
            }
        }
    }

    // MARK: Thanh thao tác khi chọn nhiều

    private func barLabel(_ symbol: String, _ title: String, tint: Color = .primary) -> some View {
        VStack(spacing: 3) {
            Image(systemName: symbol).font(.title3)
            Text(title).font(.caption2)
        }
        .foregroundStyle(tint)
        .frame(maxWidth: .infinity)
        .padding(.vertical, 4)
        .contentShape(Rectangle())
    }

    private var selectionBar: some View {
        let files = selectedFiles
        let empty = files.isEmpty
        return HStack(spacing: 0) {
            Button { sheet = .move(files) } label: { barLabel("folder", "Di chuyển") }
            Button { sheet = .copy(files) } label: { barLabel("doc.on.doc", "Sao chép") }
            Button { sheet = .download(files) } label: { barLabel("arrow.down.circle", "Tải về") }
            Button { pendingDelete = files; showDelete = true } label: { barLabel("trash", "Xóa", tint: .red) }
        }
        .buttonStyle(.plain)
        .disabled(empty)
        .opacity(empty ? 0.45 : 1)
        .padding(.horizontal, 8).padding(.vertical, 6)
        .glassSurface(cornerRadius: 30)
        .padding(.horizontal, 16).padding(.bottom, 6)
    }

    @ViewBuilder private var busyOverlay: some View {
        if let b = model.busy {
            ZStack {
                Color.black.opacity(0.3).ignoresSafeArea()
                VStack(spacing: 12) { ProgressView(); Text(b).font(.footnote) }
                    .padding(20).frame(width: 240).glassSurface(cornerRadius: 22)
            }
        }
    }

    @ViewBuilder private func sheetContent(_ s: DriveSheet) -> some View {
        switch s {
        case .move(let f):
            DriveFolderPicker(title: "Di chuyển vào…", excludeIDs: Set(f.map(\.id))) { dest in
                Task { await model.move(f, to: dest) }
            }
        case .copy(let f):
            DriveFolderPicker(title: "Sao chép vào…") { dest in Task { await model.copy(f, to: dest) } }
        case .download(let f):
            FolderPicker(title: "Tải về thư mục…", exclude: []) { dir in Task { await model.download(f, to: dir) } }
        }
    }

    // MARK: Danh sách / lưới

    @ViewBuilder private func tappable<C: View>(_ f: DriveFile, @ViewBuilder _ content: () -> C) -> some View {
        Group {
            if model.selecting {
                Button { model.toggle(f) } label: { content() }
            } else if f.isFolder {
                NavigationLink(value: f.ref) { content() }
            } else {
                NavigationLink(value: f) { content() }
            }
        }
        .buttonStyle(.plain)
        .contextMenu { menu(f) }
    }

    @ViewBuilder private func menu(_ f: DriveFile) -> some View {
        Button { renameTarget = f; renameText = f.name; showRename = true } label: { Label("Đổi tên", systemImage: "pencil") }
        Button { sheet = .move([f]) } label: { Label("Di chuyển vào…", systemImage: "folder") }
        if !f.isFolder { Button { sheet = .copy([f]) } label: { Label("Sao chép vào…", systemImage: "doc.on.doc") } }
        Button { sheet = .download([f]) } label: { Label("Tải về Jinn Files…", systemImage: "arrow.down.circle") }
        if let w = f.webLink, let u = URL(string: w) {
            Link(destination: u) { Label("Mở trong Google Drive", systemImage: "arrow.up.right.square") }
        }
        Button(role: .destructive) { pendingDelete = [f]; showDelete = true } label: { Label("Xóa", systemImage: "trash") }
    }

    private func check(_ f: DriveFile) -> some View {
        Image(systemName: model.selection.contains(f.id) ? "checkmark.circle.fill" : "circle")
            .foregroundStyle(model.selection.contains(f.id) ? Color.accentColor : .secondary)
    }

    private func subtitle(_ f: DriveFile) -> String {
        var p: [String] = []
        if let s = f.size { p.append(Fmt.size(s)) }
        if let d = f.modified { p.append(Fmt.date(d)) }
        return p.joined(separator: " • ")
    }

    private func listView(_ items: [DriveFile]) -> some View {
        LazyVStack(spacing: 0) {
            ForEach(Array(items.enumerated()), id: \.element.id) { i, f in
                tappable(f) {
                    HStack(spacing: 12) {
                        if model.selecting { check(f).font(.title3) }
                        DriveThumb(file: f).frame(width: 48, height: 48)
                            .clipShape(RoundedRectangle(cornerRadius: 8))
                        VStack(alignment: .leading, spacing: 2) {
                            Text(f.name).lineLimit(1)
                            Text(subtitle(f)).font(.caption).foregroundStyle(.secondary).lineLimit(1)
                        }
                        Spacer()
                        if f.isFolder && !model.selecting { Image(systemName: "chevron.right").font(.footnote).foregroundStyle(.tertiary) }
                    }
                    .padding(.horizontal, 16).padding(.vertical, 8)
                    .contentShape(Rectangle())
                }
                .onAppear { if query.isEmpty && i >= items.count - 6 { Task { await model.loadMore() } } }
                Divider().padding(.leading, 76)
            }
        }
    }

    private func gridView(_ items: [DriveFile]) -> some View {
        LazyVGrid(columns: [GridItem(.adaptive(minimum: 100), spacing: 12)], spacing: 14) {
            ForEach(Array(items.enumerated()), id: \.element.id) { i, f in
                tappable(f) {
                    VStack(spacing: 6) {
                        DriveThumb(file: f).frame(maxWidth: .infinity).frame(height: 96)
                            .background(Color(.secondarySystemBackground))
                            .clipShape(RoundedRectangle(cornerRadius: 12))
                            .overlay(alignment: .topLeading) { if model.selecting { check(f).font(.title3).padding(6) } }
                        Text(f.name).font(.caption).lineLimit(2).multilineTextAlignment(.center)
                        if let s = f.size { Text(Fmt.size(s)).font(.caption2).foregroundStyle(.secondary) }
                    }
                }
                .onAppear { if query.isEmpty && i >= items.count - 6 { Task { await model.loadMore() } } }
            }
        }
        .padding()
    }
}

// MARK: - Xem trước tệp Drive

struct DriveFilePreview: View {
    let file: DriveFile
    @State private var item: FileItem?
    @State private var error: String?
    @State private var forceDownload = false

    private var isMedia: Bool { file.kind == .video || file.kind == .audio }

    var body: some View {
        Group {
            if let item {
                PreviewView(item: item)
            } else if isMedia && !forceDownload {
                DriveStreamPlayer(file: file, onFail: { forceDownload = true })
            } else if let error {
                VStack(spacing: 12) {
                    ContentUnavailableView("Không mở được tệp", systemImage: "exclamationmark.triangle",
                                           description: Text(error))
                    Button("Thử lại") { Task { await load() } }.glassButtonStyle(prominent: true)
                }
            } else {
                VStack(spacing: 10) {
                    ProgressView()
                    Text("Đang tải xuống…").font(.footnote).foregroundStyle(.secondary)
                    if let s = file.size { Text(Fmt.size(s)).font(.caption).foregroundStyle(.tertiary) }
                }
            }
        }
        .navigationTitle(file.name)
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                if let w = file.webLink, let u = URL(string: w) {
                    Link(destination: u) { Image(systemName: "arrow.up.right.square") }
                }
            }
        }
        .task(id: forceDownload) { if !isMedia || forceDownload { await load() } }
    }

    private func load() async {
        error = nil
        do {
            let url = try await DriveAPI.cachedFile(file)
            item = FileOps.item(from: url)
        } catch { self.error = error.localizedDescription }
    }
}

/// Phát video/âm thanh trực tiếp từ Drive (gửi kèm mã truy cập), nếu lỗi sẽ chuyển sang tải về rồi phát
struct DriveStreamPlayer: View {
    let file: DriveFile
    let onFail: () -> Void
    @State private var player: AVPlayer?

    var body: some View {
        ZStack {
            if let player { VideoPlayer(player: player) } else { ProgressView() }
        }
        .task {
            guard let token = try? await GoogleAuth.shared.accessToken() else { onFail(); return }
            let asset = AVURLAsset(url: DriveAPI.streamURL(file),
                                   options: ["AVURLAssetHTTPHeaderFieldsKey": ["Authorization": "Bearer \(token)"]])
            let item = AVPlayerItem(asset: asset)
            let p = AVPlayer(playerItem: item)
            player = p
            p.play()
            for await status in item.publisher(for: \.status).values {
                if status == .failed { onFail(); return }
                if status == .readyToPlay { return }
            }
        }
        .onDisappear { player?.pause() }
    }
}

// MARK: - Chọn thư mục Drive

struct DriveFolderPicker: View {
    let title: String
    var excludeIDs: Set<String> = []
    let onPick: (DriveFolderRef) -> Void
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            DriveFolderPickerLevel(folder: .root, title: title, exclude: excludeIDs,
                                   onPick: { onPick($0); dismiss() }, onCancel: { dismiss() })
        }
    }
}

struct DriveFolderPickerLevel: View {
    let folder: DriveFolderRef
    let title: String
    let exclude: Set<String>
    let onPick: (DriveFolderRef) -> Void
    let onCancel: () -> Void

    @State private var folders: [DriveFile] = []
    @State private var loading = true
    @State private var errorText: String?
    @State private var showNew = false
    @State private var newName = ""

    var body: some View {
        List {
            if let errorText { Text(errorText).foregroundStyle(.red).font(.footnote) }
            ForEach(folders.filter { !exclude.contains($0.id) }) { f in
                NavigationLink {
                    DriveFolderPickerLevel(folder: f.ref, title: title, exclude: exclude, onPick: onPick, onCancel: onCancel)
                } label: { Label(f.name, systemImage: "folder.fill") }
            }
            if loading { ProgressView() }
            else if folders.isEmpty && errorText == nil { Text("Không có thư mục con").foregroundStyle(.secondary) }
        }
        .navigationTitle(folder.id == "root" ? title : folder.name)
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .topBarLeading) { Button("Hủy", action: onCancel) }
            ToolbarItem(placement: .topBarTrailing) {
                Button { newName = ""; showNew = true } label: { Image(systemName: "folder.badge.plus") }
            }
        }
        .safeAreaInset(edge: .bottom) {
            Button { onPick(folder) } label: {
                Label("Chọn \"\(folder.name)\"", systemImage: "checkmark").frame(maxWidth: .infinity)
            }
            .glassButtonStyle(prominent: true).controlSize(.large).padding()
        }
        .alert("Thư mục mới", isPresented: $showNew) {
            TextField("Tên thư mục", text: $newName)
            Button("Hủy", role: .cancel) {}
            Button("Tạo") {
                let n = newName.trimmingCharacters(in: .whitespacesAndNewlines)
                guard !n.isEmpty else { return }
                Task {
                    do { try await DriveAPI.createFolder(name: n, parent: folder.id); await load() }
                    catch { errorText = error.localizedDescription }
                }
            }
        }
        .task { await load() }
    }

    private func load() async {
        loading = true
        errorText = nil
        var all: [DriveFile] = []
        var token: String?
        do {
            repeat {
                let (f, next) = try await DriveAPI.list(parent: folder.id, foldersOnly: true, pageToken: token)
                all += f
                token = next
            } while token != nil
            folders = all.sorted { $0.name.localizedStandardCompare($1.name) == .orderedAscending }
        } catch { errorText = error.localizedDescription }
        loading = false
    }
}
