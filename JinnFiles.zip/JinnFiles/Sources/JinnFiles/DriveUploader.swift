import SwiftUI
import UIKit

final class UploadProgressDelegate: NSObject, URLSessionTaskDelegate, @unchecked Sendable {
    let onProgress: @Sendable (Double) -> Void
    init(_ f: @escaping @Sendable (Double) -> Void) { onProgress = f }
    func urlSession(_ s: URLSession, task: URLSessionTask, didSendBodyData b: Int64,
                    totalBytesSent t: Int64, totalBytesExpectedToSend e: Int64) {
        if e > 0 { onProgress(Double(t) / Double(e)) }
    }
}

struct DriveJob: Identifiable, Equatable {
    enum State: Equatable { case waiting, uploading(Double), done, failed(String) }
    let id = UUID()
    let url: URL
    let parentId: String
    var state: State = .waiting
    var name: String { url.lastPathComponent }
}

/// Hàng đợi tải tệp và thư mục lên Google Drive
@MainActor
final class DriveUploader: ObservableObject {
    static let shared = DriveUploader()

    @Published private(set) var jobs: [DriveJob] = []
    @Published private(set) var running = false
    /// Tăng lên mỗi khi có mục tải xong, để màn hình Drive tự làm mới
    @Published private(set) var version = 0

    func enqueue(_ urls: [URL], parentId: String) {
        for u in urls {
            _ = u.startAccessingSecurityScopedResource()   // tệp chọn từ app Tệp ngoài vùng của ứng dụng
            jobs.append(DriveJob(url: u, parentId: parentId))
        }
        start()
    }

    func retryFailed() {
        for i in jobs.indices { if case .failed = jobs[i].state { jobs[i].state = .waiting } }
        start()
    }

    func clearFinished() {
        jobs.removeAll { j in
            if case .done = j.state { return true }
            if case .failed = j.state { return true }
            return false
        }
    }

    private func setState(_ id: UUID, _ s: DriveJob.State) {
        if let i = jobs.firstIndex(where: { $0.id == id }) { jobs[i].state = s }
    }

    private func start() {
        guard !running else { return }
        running = true
        UIApplication.shared.isIdleTimerDisabled = true   // giữ màn hình sáng để không bị gián đoạn khi tải tệp lớn
        Task {
            while let i = jobs.firstIndex(where: { $0.state == .waiting }) {
                let job = jobs[i]
                jobs[i].state = .uploading(0)
                do {
                    var isDir: ObjCBool = false
                    FileManager.default.fileExists(atPath: job.url.path, isDirectory: &isDir)
                    if isDir.boolValue {
                        let folder = try await DriveAPI.createFolder(name: job.name, parent: job.parentId)
                        let u = job.url
                        let kids = await Task.detached { FileOps.list(u) }.value
                        for k in kids { jobs.append(DriveJob(url: k.url, parentId: folder.id)) }
                    } else {
                        let id = job.id
                        try await DriveAPI.upload(file: job.url, name: job.name, parent: job.parentId) { p in
                            Task { @MainActor in self.setState(id, .uploading(p)) }
                        }
                    }
                    setState(job.id, .done)
                    version += 1
                } catch {
                    setState(job.id, .failed(error.localizedDescription))
                }
            }
            running = false
            UIApplication.shared.isIdleTimerDisabled = false
        }
    }
}

struct UploadQueueView: View {
    @EnvironmentObject var uploader: DriveUploader

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Text("Hàng đợi tải lên").font(.headline)
                Spacer()
                if uploader.running { ProgressView() }
            }
            ForEach(uploader.jobs.reversed().prefix(30)) { job in
                HStack(spacing: 10) {
                    icon(job.state)
                    VStack(alignment: .leading, spacing: 2) {
                        Text(job.name).font(.subheadline).lineLimit(1)
                        switch job.state {
                        case .waiting: Text("Đang chờ").font(.caption).foregroundStyle(.secondary)
                        case .uploading(let p): ProgressView(value: p)
                        case .done: Text("Đã tải lên").font(.caption).foregroundStyle(.green)
                        case .failed(let m): Text(m).font(.caption).foregroundStyle(.red)
                        }
                    }
                }
            }
            HStack {
                Button("Thử lại mục lỗi") { uploader.retryFailed() }.glassButtonStyle()
                Button("Xóa mục đã xong") { uploader.clearFinished() }.glassButtonStyle()
            }.font(.footnote)
        }
        .padding(16).frame(maxWidth: .infinity, alignment: .leading).glassSurface(cornerRadius: 26)
    }

    @ViewBuilder private func icon(_ s: DriveJob.State) -> some View {
        switch s {
        case .waiting: Image(systemName: "clock").foregroundStyle(.secondary)
        case .uploading: Image(systemName: "arrow.up.circle").foregroundStyle(Color.accentColor)
        case .done: Image(systemName: "checkmark.circle.fill").foregroundStyle(.green)
        case .failed: Image(systemName: "exclamationmark.triangle.fill").foregroundStyle(.red)
        }
    }
}
