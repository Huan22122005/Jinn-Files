import SwiftUI
import UIKit
import AuthenticationServices
import CryptoKit

struct GoogleUser: Codable, Equatable {
    var name: String
    var email: String
    var picture: String?
}

/// Đăng nhập Google bằng OAuth 2.0 + PKCE (không cần SDK ngoài).
@MainActor
final class GoogleAuth: NSObject, ObservableObject, ASWebAuthenticationPresentationContextProviding {
    static let shared = GoogleAuth()
    static let scopes = "openid email profile https://www.googleapis.com/auth/photoslibrary.appendonly"

    @Published private(set) var clientID: String
    @Published private(set) var user: GoogleUser?
    @Published private(set) var busy = false
    @Published var errorMessage: String?

    private struct Tokens: Codable {
        var access: String
        var expiry: Date
        var refresh: String?
    }
    private var tokens: Tokens?
    private var session: ASWebAuthenticationSession?

    override init() {
        clientID = UserDefaults.standard.string(forKey: "googleClientID") ?? ""
        super.init()
        if let d = SecureStore.get("google.tokens"), let t = try? JSONDecoder().decode(Tokens.self, from: d) { tokens = t }
        if let d = UserDefaults.standard.data(forKey: "googleUser"),
           let u = try? JSONDecoder().decode(GoogleUser.self, from: d) { user = u }
    }

    var isSignedIn: Bool { tokens != nil && user != nil }
    var isConfigured: Bool { clientID.hasSuffix(".apps.googleusercontent.com") && clientID.count > 30 }

    func setClientID(_ s: String) {
        clientID = s.trimmingCharacters(in: .whitespacesAndNewlines)
        UserDefaults.standard.set(clientID, forKey: "googleClientID")
    }

    private var redirectScheme: String {
        "com.googleusercontent.apps." + clientID.replacingOccurrences(of: ".apps.googleusercontent.com", with: "")
    }

    // MARK: Đăng nhập / đăng xuất

    func signIn() async {
        guard isConfigured else { errorMessage = "Chưa nhập Client ID hợp lệ."; return }
        busy = true
        defer { busy = false }
        do {
            let verifier = Self.randomString(64)
            let challenge = Self.base64url(Data(SHA256.hash(data: Data(verifier.utf8))))
            let state = Self.randomString(24)
            let scheme = redirectScheme
            let redirect = "\(scheme):/oauth2redirect"

            var c = URLComponents(string: "https://accounts.google.com/o/oauth2/v2/auth")!
            c.queryItems = [
                .init(name: "client_id", value: clientID),
                .init(name: "redirect_uri", value: redirect),
                .init(name: "response_type", value: "code"),
                .init(name: "scope", value: Self.scopes),
                .init(name: "code_challenge", value: challenge),
                .init(name: "code_challenge_method", value: "S256"),
                .init(name: "state", value: state),
                .init(name: "access_type", value: "offline"),
                .init(name: "prompt", value: "consent")
            ]
            let callback = try await startSession(url: c.url!, scheme: scheme)
            let items = URLComponents(url: callback, resolvingAgainstBaseURL: false)?.queryItems ?? []
            if let err = items.first(where: { $0.name == "error" })?.value { throw AppError("Google trả về lỗi: \(err)") }
            guard items.first(where: { $0.name == "state" })?.value == state,
                  let code = items.first(where: { $0.name == "code" })?.value else {
                throw AppError("Phản hồi đăng nhập không hợp lệ.")
            }
            let o = try await tokenRequest(["code": code, "client_id": clientID, "code_verifier": verifier,
                                            "redirect_uri": redirect, "grant_type": "authorization_code"])
            guard let access = o["access_token"] as? String else { throw AppError("Không nhận được mã truy cập.") }
            let t = Tokens(access: access,
                           expiry: Date().addingTimeInterval((o["expires_in"] as? Double) ?? 3600),
                           refresh: o["refresh_token"] as? String)
            saveTokens(t)
            let u = try await fetchUser(token: access)
            user = u
            if let d = try? JSONEncoder().encode(u) { UserDefaults.standard.set(d, forKey: "googleUser") }
        } catch let e as ASWebAuthenticationSessionError where e.code == .canceledLogin {
            // người dùng tự hủy
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    func signOut() {
        if let r = tokens?.refresh {
            Task.detached {
                var req = URLRequest(url: URL(string: "https://oauth2.googleapis.com/revoke")!)
                req.httpMethod = "POST"
                req.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
                req.httpBody = "token=\(r)".data(using: .utf8)
                _ = try? await URLSession.shared.data(for: req)
            }
        }
        tokens = nil
        user = nil
        SecureStore.delete("google.tokens")
        UserDefaults.standard.removeObject(forKey: "googleUser")
    }

    // MARK: Mã truy cập

    func accessToken(forceRefresh: Bool = false) async throws -> String {
        guard var t = tokens else { throw AppError("Chưa đăng nhập Google.") }
        if !forceRefresh && t.expiry > Date().addingTimeInterval(60) { return t.access }
        guard let r = t.refresh else {
            signOut()
            throw AppError("Phiên đăng nhập đã hết hạn, hãy đăng nhập lại.")
        }
        do {
            let o = try await tokenRequest(["client_id": clientID, "refresh_token": r, "grant_type": "refresh_token"])
            guard let a = o["access_token"] as? String else { throw AppError("Không làm mới được phiên đăng nhập.") }
            t.access = a
            t.expiry = Date().addingTimeInterval((o["expires_in"] as? Double) ?? 3600)
            saveTokens(t)
            return a
        } catch {
            if error.localizedDescription.contains("invalid_grant") {
                signOut()
                throw AppError("Phiên đăng nhập đã hết hạn (với ứng dụng ở chế độ Testing, Google hủy phiên sau 7 ngày). Hãy đăng nhập lại.")
            }
            throw error
        }
    }

    // MARK: Hỗ trợ

    private func saveTokens(_ t: Tokens) {
        var t = t
        if t.refresh == nil { t.refresh = tokens?.refresh }   // giữ refresh token cũ nếu lần này không có
        tokens = t
        if let d = try? JSONEncoder().encode(t) { SecureStore.set("google.tokens", d) }
    }

    private func startSession(url: URL, scheme: String) async throws -> URL {
        try await withCheckedThrowingContinuation { cont in
            let s = ASWebAuthenticationSession(url: url, callbackURLScheme: scheme) { callback, error in
                if let callback { cont.resume(returning: callback) }
                else { cont.resume(throwing: error ?? AppError("Đăng nhập bị hủy.")) }
            }
            s.presentationContextProvider = self
            self.session = s
            if !s.start() { cont.resume(throwing: AppError("Không mở được cửa sổ đăng nhập.")) }
        }
    }

    private func tokenRequest(_ params: [String: String]) async throws -> [String: Any] {
        var r = URLRequest(url: URL(string: "https://oauth2.googleapis.com/token")!)
        r.httpMethod = "POST"
        r.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
        r.httpBody = params.map { "\($0.key)=\(Self.enc($0.value))" }.joined(separator: "&").data(using: .utf8)
        let (data, resp) = try await URLSession.shared.data(for: r)
        let obj = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any] ?? [:]
        if (resp as? HTTPURLResponse)?.statusCode != 200 {
            let code = obj["error"] as? String ?? "lỗi"
            let desc = obj["error_description"] as? String ?? ""
            throw AppError("\(code): \(desc)")
        }
        return obj
    }

    private func fetchUser(token: String) async throws -> GoogleUser {
        var r = URLRequest(url: URL(string: "https://www.googleapis.com/oauth2/v3/userinfo")!)
        r.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        let (data, _) = try await URLSession.shared.data(for: r)
        let o = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any] ?? [:]
        let email = o["email"] as? String ?? ""
        return GoogleUser(name: o["name"] as? String ?? email, email: email, picture: o["picture"] as? String)
    }

    nonisolated func presentationAnchor(for session: ASWebAuthenticationSession) -> ASPresentationAnchor {
        MainActor.assumeIsolated {
            UIApplication.shared.connectedScenes
                .compactMap { $0 as? UIWindowScene }
                .flatMap(\.windows)
                .first(where: \.isKeyWindow) ?? ASPresentationAnchor()
        }
    }

    private static func randomString(_ n: Int) -> String {
        var b = [UInt8](repeating: 0, count: n)
        _ = SecRandomCopyBytes(kSecRandomDefault, n, &b)
        return String(base64url(Data(b)).prefix(n))
    }
    private static func base64url(_ d: Data) -> String {
        d.base64EncodedString().replacingOccurrences(of: "+", with: "-")
            .replacingOccurrences(of: "/", with: "_").replacingOccurrences(of: "=", with: "")
    }
    private static func enc(_ s: String) -> String {
        s.addingPercentEncoding(withAllowedCharacters: CharacterSet(charactersIn: "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-._~")) ?? s
    }
}
