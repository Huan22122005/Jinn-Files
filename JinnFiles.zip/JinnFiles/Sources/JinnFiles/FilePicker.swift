import SwiftUI
import UIKit

final class PickSelection: ObservableObject {
    @Published var urls = Set<URL>()
}

enum PickAction {
    case share
    case custom(([URL]) -> Void)
}

struct PickConfig {
    var rootTitle: String
    var icon: String
    var allowFolders: Bool
    var actionTitle: (Int) -> String
    var action: PickAction
}

/// Duyệt từng thư mục trong Tệp của tôi để chọn tệp (và thư mục nếu được phép).
/// Lựa chọn được giữ khi chuyển giữa các thư mục.
struct FilePickerLevel: View {
    let url: URL
    let isRoot: Bool
    let config: PickConfig
    var onClose: (() -> Void)? = nil

    @EnvironmentObject var sel: PickSelection
    @AppStorage("pickerViewMode") private var mode = "list"
    @State private var folders: [FileItem] = []
    @State private var files: [FileItem] = []
    @State private var loading = true
    @State private var showShare = false

    private var allHereSelected: Bool {
        let all = files.map(\.url) + (config.allowFolders ? folders.map(\.url) : [])
        return !all.isEmpty && all.allSatisfy { sel.urls.contains($0) }
    }

    var body: some View {
        ScrollView {
            LazyVStack(alignment: .leading, spacing: 0) {
                ForEach(folders) { f in folderRow(f); Divider().padding(.leading, 16) }
                if mode == "grid" {
                    LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 6), count: 3), spacing: 10) {
                        ForEach(files) { gridCell($0) }
                    }
                    .padding(.horizontal, 8).padding(.top, 8)
                } else {
                    ForEach(files) { f in fileRow(f); Divider().padding(.leading, 76) }
                }
                if !loading && folders.isEmpty && files.isEmpty {
                    ContentUnavailableView("Thư mục trống", systemImage: "folder").padding(.top, 40)
                }
            }
        }
        .navigationTitle(isRoot ? config.rootTitle : url.lastPathComponent)
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            if let onClose { ToolbarItem(placement: .topBarLeading) { Button("Đóng") { onClose() } } }
            ToolbarItem(placement: .topBarTrailing) {
                Menu {
                    Button(allHereSelected ? "Bỏ chọn ở thư mục này" : "Chọn tất cả ở thư mục này") { toggleAllHere() }
                    Button("Chọn cả thư mục con") { selectRecursive() }
                    Button("Bỏ chọn tất cả (mọi thư mục)", role: .destructive) { sel.urls.removeAll() }
                    Picker("Kiểu hiển thị", selection: $mode) {
                        Label("Danh sách (tên, dung lượng)", systemImage: "list.bullet").tag("list")
                        Label("Lưới (hình thu nhỏ)", systemImage: "square.grid.3x3").tag("grid")
                    }
                } label: { Image(systemName: "ellipsis.circle") }
            }
        }
        .safeAreaInset(edge: .bottom) {
            Button { perform() } label: {
                Label(config.actionTitle(sel.urls.count), systemImage: config.icon).frame(maxWidth: .infinity)
            }
            .glassButtonStyle(prominent: true).controlSize(.large)
            .disabled(sel.urls.isEmpty).padding()
        }
        .sheet(isPresented: $showShare) { ActivityView(items: Array(sel.urls)) }
        .task(id: url) {
            let u = url
            let r: ([FileItem], [FileItem]) = await Task.detached {
                let all = FileOps.list(u)
                let f = all.filter { $0.isDirectory && !Paths.isGoogleDrive($0.url) }
                    .sorted { $0.name.localizedStandardCompare($1.name) == .orderedAscending }
                let m = all.filter { !$0.isDirectory }.sorted { $0.modified > $1.modified }
                return (f, m)
            }.value
            folders = r.0; files = r.1; loading = false
        }
    }

    private func perform() {
        switch config.action {
        case .share: showShare = true
        case .custom(let f): f(Array(sel.urls))
        }
    }

    private func toggleAllHere() {
        let all = Set(files.map(\.url) + (config.allowFolders ? folders.map(\.url) : []))
        if allHereSelected { sel.urls.subtract(all) } else { sel.urls.formUnion(all) }
    }

    private func selectRecursive() {
        let u = url
        Task {
            let all = await Task.detached { FileOps.allFiles(in: u) }.value
            sel.urls.formUnion(all.map(\.url))
        }
    }

    private func toggle(_ u: URL) {
        if sel.urls.contains(u) { sel.urls.remove(u) } else { sel.urls.insert(u) }
    }

    private func check(_ u: URL) -> some View {
        Image(systemName: sel.urls.contains(u) ? "checkmark.circle.fill" : "circle")
            .font(.title3)
            .foregroundStyle(sel.urls.contains(u) ? Color.accentColor : .secondary)
    }

    private func folderRow(_ f: FileItem) -> some View {
        HStack(spacing: 6) {
            if config.allowFolders {
                Button { toggle(f.url) } label: { check(f.url).padding(.leading, 16).padding(.vertical, 12) }
                    .buttonStyle(.plain)
            }
            NavigationLink {
                FilePickerLevel(url: f.url, isRoot: false, config: config)
            } label: {
                HStack(spacing: 12) {
                    Image(systemName: "folder.fill").foregroundStyle(Color.accentColor).font(.title3)
                    Text(f.name).foregroundStyle(.primary)
                    Spacer()
                    Image(systemName: "chevron.right").font(.footnote).foregroundStyle(.tertiary)
                }
                .padding(.leading, config.allowFolders ? 4 : 16).padding(.trailing, 16).padding(.vertical, 12)
                .contentShape(Rectangle())
            }
            .buttonStyle(.plain)
        }
    }

    private func fileRow(_ f: FileItem) -> some View {
        Button { toggle(f.url) } label: {
            HStack(spacing: 12) {
                check(f.url)
                ThumbView(item: f).frame(width: 48, height: 48).clipShape(RoundedRectangle(cornerRadius: 8))
                VStack(alignment: .leading, spacing: 2) {
                    Text(f.name).lineLimit(1).foregroundStyle(.primary)
                    Text("\(Fmt.size(f.size ?? 0)) • \(Fmt.date(f.modified))").font(.caption).foregroundStyle(.secondary)
                }
                Spacer()
            }
            .padding(.horizontal, 16).padding(.vertical, 8)
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
    }

    private func gridCell(_ f: FileItem) -> some View {
        Button { toggle(f.url) } label: {
            VStack(spacing: 4) {
                Color.clear.aspectRatio(1, contentMode: .fit)
                    .overlay { ThumbView(item: f) }
                    .background(Color(.secondarySystemBackground))
                    .clipShape(RoundedRectangle(cornerRadius: 10))
                    .overlay(alignment: .topTrailing) { check(f.url).padding(6).shadow(radius: 2) }
                Text(f.name).font(.caption2).lineLimit(2).multilineTextAlignment(.center).foregroundStyle(.primary)
                Text(Fmt.size(f.size ?? 0)).font(.caption2).foregroundStyle(.secondary)
            }
        }
        .buttonStyle(.plain)
    }
}

/// Màn hình chọn tệp dạng cửa sổ trượt
struct LocalFilePickerSheet: View {
    let rootTitle: String
    let icon: String
    let allowFolders: Bool
    let actionTitle: (Int) -> String
    let onConfirm: ([URL]) -> Void
    @Environment(\.dismiss) private var dismiss
    @StateObject private var sel = PickSelection()

    var body: some View {
        NavigationStack {
            FilePickerLevel(
                url: Paths.files, isRoot: true,
                config: PickConfig(rootTitle: rootTitle, icon: icon, allowFolders: allowFolders,
                                   actionTitle: actionTitle,
                                   action: .custom { urls in onConfirm(urls); dismiss() }),
                onClose: { dismiss() })
        }
        .environmentObject(sel)
    }
}
