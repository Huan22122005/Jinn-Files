import Foundation
import ZIPFoundation
import SWCompression

enum ExtractMode {
    case newFolder          // vào thư mục mới cùng tên tệp nén, trong thư mục hiện tại
    case here               // vào thư mục hiện tại
    case into(URL)          // vào thư mục được chọn
}

enum ArchiveOps {
    /// Giải nén vào thư mục tạm (cùng ổ đĩa), sau đó mới chuyển vào đích.
    /// Không bao giờ ghi đè: trùng tên sẽ được đổi thành "tên (1)".
    static func extract(archive: URL, mode: ExtractMode, currentDir: URL,
                        progress: @escaping @Sendable (Double) -> Void) throws {
        let fm = FileManager.default
        let parentForStaging: URL
        switch mode {
        case .newFolder, .here: parentForStaging = currentDir
        case .into(let d): parentForStaging = d
        }
        let staging = parentForStaging.appendingPathComponent(".jinn-extract-\(UUID().uuidString)", isDirectory: true)
        try fm.createDirectory(at: staging, withIntermediateDirectories: true)
        defer { try? fm.removeItem(at: staging) }

        let ext = archive.pathExtension.lowercased()
        if ext == "7z" {
            try extract7z(archive, to: staging, progress: progress)
        } else {
            try extractZip(archive, to: staging, progress: progress)
        }

        switch mode {
        case .newFolder:
            let base = archive.deletingPathExtension().lastPathComponent
            let target = FileOps.uniqueURL(dir: currentDir, name: base)
            try fm.moveItem(at: staging, to: target)
        case .here, .into:
            let dest: URL
            if case .into(let d) = mode { dest = d } else { dest = currentDir }
            let children = try fm.contentsOfDirectory(at: staging, includingPropertiesForKeys: nil)
            for c in children {
                try fm.moveItem(at: c, to: FileOps.uniqueURL(dir: dest, name: c.lastPathComponent))
            }
        }
    }

    private static func extractZip(_ src: URL, to dest: URL, progress: @escaping @Sendable (Double) -> Void) throws {
        let p = Progress()
        let obs = p.observe(\.fractionCompleted) { pr, _ in progress(pr.fractionCompleted) }
        defer { obs.invalidate() }
        do {
            try FileManager.default.unzipItem(at: src, to: dest, progress: p)
        } catch {
            throw AppError("Tệp ZIP không hợp lệ hoặc bị lỗi.")
        }
    }

    private static func extract7z(_ src: URL, to dest: URL, progress: @escaping @Sendable (Double) -> Void) throws {
        let fm = FileManager.default
        let data = try Data(contentsOf: src, options: .mappedIfSafe)
        let entries: [SevenZipEntry]
        do { entries = try SevenZipContainer.open(container: data) }
        catch { throw AppError("Tệp 7Z không hợp lệ, được mã hóa hoặc không được hỗ trợ.") }

        let destRoot = dest.resolvingSymlinksInPath().path
        for (i, e) in entries.enumerated() {
            let name = e.info.name
            let comps = name.split(separator: "/").map(String.init)
            if name.hasPrefix("/") || comps.contains("..") { continue }   // chặn path traversal
            let target = dest.appendingPathComponent(name)
            guard target.resolvingSymlinksInPath().path.hasPrefix(destRoot) else { continue }
            switch e.info.type {
            case .directory:
                try fm.createDirectory(at: target, withIntermediateDirectories: true)
            case .regular:
                try fm.createDirectory(at: target.deletingLastPathComponent(), withIntermediateDirectories: true)
                try (e.data ?? Data()).write(to: target)
            default: break
            }
            progress(Double(i + 1) / Double(max(entries.count, 1)))
        }
    }

    static func zip(_ urls: [URL], in dir: URL, progress: @escaping @Sendable (Double) -> Void) throws {
        let fm = FileManager.default
        let tmp = dir.appendingPathComponent(".jinn-zip-\(UUID().uuidString)", isDirectory: true)
        try fm.createDirectory(at: tmp, withIntermediateDirectories: true)
        defer { try? fm.removeItem(at: tmp) }

        let name: String
        let source: URL
        let keepParent: Bool
        if urls.count == 1 {
            name = urls[0].lastPathComponent + ".zip"
            source = urls[0]; keepParent = true
        } else {
            name = "Archive.zip"
            let bundle = tmp.appendingPathComponent("bundle", isDirectory: true)
            try fm.createDirectory(at: bundle, withIntermediateDirectories: true)
            for u in urls { try fm.copyItem(at: u, to: bundle.appendingPathComponent(u.lastPathComponent)) }
            source = bundle; keepParent = false
        }
        let out = tmp.appendingPathComponent("out.zip")
        let p = Progress()
        let obs = p.observe(\.fractionCompleted) { pr, _ in progress(pr.fractionCompleted) }
        defer { obs.invalidate() }
        try fm.zipItem(at: source, to: out, shouldKeepParent: keepParent, compressionMethod: .deflate, progress: p)
        try fm.moveItem(at: out, to: FileOps.uniqueURL(dir: dir, name: name))
    }
}
