import Foundation
import ZIPFoundation
import SWCompression

enum ExtractMode {
    case newFolder          // vào thư mục mới cùng tên tệp nén, trong thư mục hiện tại
    case here               // vào thư mục hiện tại
    case into(URL)          // vào thư mục được chọn
}

enum ArchiveOps {
    /// Giải nén vào thư mục tạm (cùng ổ đĩa), sau đó mới chuyển vào đích.
    /// Không bao giờ ghi đè: trùng tên sẽ được đổi thành "tên (1)".
    static func extract(archive: URL, mode: ExtractMode, currentDir: URL, password: String? = nil,
                        progress: @escaping @Sendable (Double) -> Void) throws {
        let fm = FileManager.default
        let parentForStaging: URL
        switch mode {
        case .newFolder, .here: parentForStaging = currentDir
        case .into(let d): parentForStaging = d
        }
        let staging = parentForStaging.appendingPathComponent(".jinn-extract-\(UUID().uuidString)", isDirectory: true)
        try fm.createDirectory(at: staging, withIntermediateDirectories: true)
        defer { try? fm.removeItem(at: staging) }

        let ext = archive.pathExtension.lowercased()
        if ext == "7z" {
            try extract7z(archive, to: staging, progress: progress)
        } else {
            if MiniZipReader.needsPassword(archive) {
                try MiniZipReader.extract(url: archive, to: staging, password: password, progress: progress)
            } else {
                var firstError: Error?
                do { try extractZip(archive, to: staging, progress: progress) } catch { firstError = error }
                if firstError != nil || isEmptyDir(staging, fm) {
                    // Công cụ giải nén dự phòng của ứng dụng
                    do { try MiniZipReader.extract(url: archive, to: staging, password: nil, progress: progress) }
                    catch { if let e = firstError { throw e } else { throw error } }
                }
            }
        }
        if isEmptyDir(staging, fm) {
            throw AppError("Không có tệp nào được giải nén: tệp nén rỗng hoặc không đọc được.")
        }

        switch mode {
        case .newFolder:
            let base = archive.deletingPathExtension().lastPathComponent
            let target = FileOps.uniqueURL(dir: currentDir, name: base)
            try fm.moveItem(at: staging, to: target)
        case .here, .into:
            let dest: URL
            if case .into(let d) = mode { dest = d } else { dest = currentDir }
            let children = try fm.contentsOfDirectory(at: staging, includingPropertiesForKeys: nil)
            for c in children {
                try fm.moveItem(at: c, to: FileOps.uniqueURL(dir: dest, name: c.lastPathComponent))
            }
        }
    }

    private static func isEmptyDir(_ url: URL, _ fm: FileManager) -> Bool {
        ((try? fm.contentsOfDirectory(atPath: url.path)) ?? []).isEmpty
    }

    private static func extractZip(_ src: URL, to dest: URL, progress: @escaping @Sendable (Double) -> Void) throws {
        let p = Progress()
        let obs = p.observe(\.fractionCompleted) { pr, _ in progress(pr.fractionCompleted) }
        defer { obs.invalidate() }
        do {
            try FileManager.default.unzipItem(at: src, to: dest, progress: p)
        } catch {
            throw AppError("Tệp ZIP không hợp lệ hoặc bị lỗi.")
        }
    }

    private static func extract7z(_ src: URL, to dest: URL, progress: @escaping @Sendable (Double) -> Void) throws {
        let fm = FileManager.default
        let data = try Data(contentsOf: src, options: .mappedIfSafe)
        let entries: [SevenZipEntry]
        do { entries = try SevenZipContainer.open(container: data) }
        catch { throw AppError("Tệp 7Z không hợp lệ, được mã hóa hoặc không được hỗ trợ.") }

        for (i, e) in entries.enumerated() {
            let name = e.info.name
            guard let target = safeExtractTarget(dest: dest, name: name) else { continue }   // chặn path traversal
            switch e.info.type {
            case .directory:
                try fm.createDirectory(at: target, withIntermediateDirectories: true)
            case .regular:
                try fm.createDirectory(at: target.deletingLastPathComponent(), withIntermediateDirectories: true)
                try (e.data ?? Data()).write(to: target)
            default: break
            }
            progress(Double(i + 1) / Double(max(entries.count, 1)))
        }
    }

    static func zip(_ urls: [URL], in dir: URL, name customName: String? = nil, password: String? = nil,
                    progress: @escaping @Sendable (Double) -> Void) throws {
        if let pw = password, !pw.isEmpty {
            try zipEncrypted(urls, in: dir, name: customName, password: pw, progress: progress)
            return
        }
        let fm = FileManager.default
        let tmp = dir.appendingPathComponent(".jinn-zip-\(UUID().uuidString)", isDirectory: true)
        try fm.createDirectory(at: tmp, withIntermediateDirectories: true)
        defer { try? fm.removeItem(at: tmp) }

        let name: String
        let source: URL
        let keepParent: Bool
        if let c = customName, !c.isEmpty {
            name = c.lowercased().hasSuffix(".zip") ? c : c + ".zip"
            if urls.count == 1 { source = urls[0]; keepParent = true } else {
                let bundle = tmp.appendingPathComponent("bundle", isDirectory: true)
                try fm.createDirectory(at: bundle, withIntermediateDirectories: true)
                for u in urls { try fm.copyItem(at: u, to: bundle.appendingPathComponent(u.lastPathComponent)) }
                source = bundle; keepParent = false
            }
        } else if urls.count == 1 {
            name = urls[0].lastPathComponent + ".zip"
            source = urls[0]; keepParent = true
        } else {
            name = "Archive.zip"
            let bundle = tmp.appendingPathComponent("bundle", isDirectory: true)
            try fm.createDirectory(at: bundle, withIntermediateDirectories: true)
            for u in urls { try fm.copyItem(at: u, to: bundle.appendingPathComponent(u.lastPathComponent)) }
            source = bundle; keepParent = false
        }
        let out = tmp.appendingPathComponent("out.zip")
        let p = Progress()
        let obs = p.observe(\.fractionCompleted) { pr, _ in progress(pr.fractionCompleted) }
        defer { obs.invalidate() }
        try fm.zipItem(at: source, to: out, shouldKeepParent: keepParent, compressionMethod: .deflate, progress: p)
        if let list = try? MiniZipReader.entries(of: out), list.isEmpty {
            // tệp ZIP tạo ra không có mục nào: dùng bộ nén dự phòng
            try? fm.removeItem(at: out)
            try zipEncrypted(urls, in: dir, name: customName, password: nil, progress: progress)
            return
        }
        try fm.moveItem(at: out, to: FileOps.uniqueURL(dir: dir, name: name))
    }

    // MARK: ZIP có mật khẩu (mã hóa ZipCrypto)

    private static func zipEncrypted(_ urls: [URL], in dir: URL, name customName: String?, password: String?,
                                     progress: @escaping @Sendable (Double) -> Void) throws {
        let fm = FileManager.default
        let tmpDir = dir.appendingPathComponent(".jinn-zip-\(UUID().uuidString)", isDirectory: true)
        try fm.createDirectory(at: tmpDir, withIntermediateDirectories: true)
        defer { try? fm.removeItem(at: tmpDir) }

        var base = customName?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        if base.isEmpty { base = urls.count == 1 ? urls[0].lastPathComponent : "Archive" }
        let finalName = base.lowercased().hasSuffix(".zip") ? base : base + ".zip"

        var total: Int64 = 0
        for u in urls { total += FileOps.size(of: u) }
        total = max(total, 1)
        let out = tmpDir.appendingPathComponent("out.zip")
        let writer = try MiniZipWriter(url: out, password: password)
        var done: Int64 = 0
        let report: (Int64) -> Void = { n in done += n; progress(min(1, Double(done) / Double(total))) }

        func add(_ url: URL, _ rel: String) throws {
            let v = try? url.resourceValues(forKeys: [.isDirectoryKey, .contentModificationDateKey])
            let modified = v?.contentModificationDate ?? Date()
            if v?.isDirectory == true {
                try writer.addDirectory(name: rel, modified: modified)
                let kids = (try? fm.contentsOfDirectory(at: url, includingPropertiesForKeys: nil)) ?? []
                for k in kids.sorted(by: { $0.lastPathComponent < $1.lastPathComponent }) where !k.lastPathComponent.hasPrefix(".jinn-") {
                    try add(k, rel + "/" + k.lastPathComponent)
                }
            } else {
                try writer.addFile(name: rel, source: url, modified: modified, progress: report)
            }
        }
        do {
            for u in urls { try add(u, u.lastPathComponent) }
            try writer.finish()
        } catch {
            writer.abort()
            throw error
        }
        try fm.moveItem(at: out, to: FileOps.uniqueURL(dir: dir, name: finalName))
    }
}
