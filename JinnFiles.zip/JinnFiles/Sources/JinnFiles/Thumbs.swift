import SwiftUI
import ImageIO
import AVFoundation
import PDFKit

enum Thumbs {
    static let cache = NSCache<NSString, UIImage>()

    private static func fnv(_ s: String) -> String {
        var h: UInt64 = 0xcbf29ce484222325
        for b in s.utf8 { h = (h ^ UInt64(b)) &* 0x100000001b3 }
        return String(h, radix: 16)
    }

    /// Giải mã ảnh có giảm kích thước (không nạp ảnh gốc đầy đủ vào RAM)
    static func downsample(_ url: URL, maxPixel: Int) -> UIImage? {
        let opts: [CFString: Any] = [kCGImageSourceShouldCache: false]
        guard let src = CGImageSourceCreateWithURL(url as CFURL, opts as CFDictionary) else { return nil }
        let o: [CFString: Any] = [
            kCGImageSourceCreateThumbnailFromImageAlways: true,
            kCGImageSourceCreateThumbnailWithTransform: true,
            kCGImageSourceShouldCacheImmediately: true,
            kCGImageSourceThumbnailMaxPixelSize: maxPixel
        ]
        guard let cg = CGImageSourceCreateThumbnailAtIndex(src, 0, o as CFDictionary) else { return nil }
        return UIImage(cgImage: cg)
    }

    static func load(_ url: URL, maxPixel: Int) async -> UIImage? {
        await Task.detached(priority: .userInitiated) { downsample(url, maxPixel: maxPixel) }.value
    }

    static func thumbnail(for item: FileItem, maxPixel: Int = 300) async -> UIImage? {
        let key = "\(item.url.path)|\(item.modified.timeIntervalSince1970)|\(maxPixel)"
        if let c = cache.object(forKey: key as NSString) { return c }
        let disk = Paths.thumbs.appendingPathComponent(fnv(key) + ".jpg")
        let img: UIImage? = await Task.detached(priority: .utility) { () -> UIImage? in
            if let d = try? Data(contentsOf: disk), let i = UIImage(data: d) { return i }
            var result: UIImage?
            switch item.kind {
            case .image:
                result = downsample(item.url, maxPixel: maxPixel)
            case .video:
                let gen = AVAssetImageGenerator(asset: AVURLAsset(url: item.url))
                gen.appliesPreferredTrackTransform = true
                gen.maximumSize = CGSize(width: maxPixel, height: maxPixel)
                if let cg = try? gen.copyCGImage(at: CMTime(seconds: 1, preferredTimescale: 600), actualTime: nil)
                    ?? gen.copyCGImage(at: .zero, actualTime: nil) {
                    result = UIImage(cgImage: cg)
                }
            case .pdf:
                result = PDFDocument(url: item.url)?.page(at: 0)?
                    .thumbnail(of: CGSize(width: maxPixel, height: maxPixel), for: .mediaBox)
            default: break
            }
            if let r = result, maxPixel <= 400, let d = r.jpegData(compressionQuality: 0.8) {
                try? d.write(to: disk, options: .atomic)
            }
            return result
        }.value
        if let img { cache.setObject(img, forKey: key as NSString) }
        return img
    }

    static func clearDisk() {
        cache.removeAllObjects()
        if let f = try? FileManager.default.contentsOfDirectory(at: Paths.thumbs, includingPropertiesForKeys: nil) {
            f.forEach { try? FileManager.default.removeItem(at: $0) }
        }
    }
}

struct ThumbView: View {
    let item: FileItem
    var body: some View {
        ZStack {
            if item.kind == .image || item.kind == .video || item.kind == .pdf {
                ThumbLoaded(item: item)
            } else {
                Image(systemName: item.kind.symbol)
                    .font(.system(size: 34))
                    .foregroundStyle(item.kind.tint)
            }
        }
    }
}

private struct ThumbLoaded: View {
    let item: FileItem
    @State private var image: UIImage?
    var body: some View {
        GeometryReader { geo in
            ZStack {
                if let image {
                    Image(uiImage: image).resizable().scaledToFill()
                        .frame(width: geo.size.width, height: geo.size.height).clipped()
                } else {
                    Image(systemName: item.kind.symbol).font(.system(size: 28)).foregroundStyle(item.kind.tint)
                        .frame(width: geo.size.width, height: geo.size.height)
                }
            }
        }
        .task(id: item.url) { image = await Thumbs.thumbnail(for: item) }
    }
}
