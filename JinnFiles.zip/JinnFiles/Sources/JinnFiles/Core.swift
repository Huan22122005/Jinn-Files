import SwiftUI
import UniformTypeIdentifiers

struct AppError: LocalizedError {
    let message: String
    init(_ m: String) { message = m }
    var errorDescription: String? { message }
}

enum Paths {
    static let fm = FileManager.default
    static let base: URL = fm.urls(for: .documentDirectory, in: .userDomainMask)[0]
        .appendingPathComponent("JinnFiles", isDirectory: true)
    static let files = base.appendingPathComponent("Files", isDirectory: true)
    static let trash = base.appendingPathComponent("Trash", isDirectory: true)
    static let thumbs = base.appendingPathComponent("Thumbnails", isDirectory: true)
    static let meta = base.appendingPathComponent("Metadata", isDirectory: true)
    /// Thư mục đặc biệt: mở ra trình xem ảnh đã tải lên Google Photos
    static let googlePhotos = files.appendingPathComponent("Google Photos", isDirectory: true)

    static func isGooglePhotos(_ u: URL) -> Bool {
        u.resolvingSymlinksInPath().path == googlePhotos.resolvingSymlinksInPath().path
    }

    static func bootstrap() {
        var dirs = [trash, thumbs, meta, googlePhotos]
        for s in ["Documents", "Images", "Videos", "Archives", "Other"] {
            dirs.append(files.appendingPathComponent(s, isDirectory: true))
        }
        for d in dirs { try? fm.createDirectory(at: d, withIntermediateDirectories: true) }
    }

    /// Thư mục phân loại khi nhập tệp vào gốc
    static func category(for kind: Kind) -> URL {
        switch kind {
        case .image: return files.appendingPathComponent("Images", isDirectory: true)
        case .video, .audio: return files.appendingPathComponent("Videos", isDirectory: true)
        case .archive: return files.appendingPathComponent("Archives", isDirectory: true)
        case .pdf, .text: return files.appendingPathComponent("Documents", isDirectory: true)
        default: return files.appendingPathComponent("Other", isDirectory: true)
        }
    }
}

enum Kind: String {
    case folder, image, video, audio, pdf, text, archive, other

    var symbol: String {
        switch self {
        case .folder: return "folder.fill"
        case .image: return "photo"
        case .video: return "film"
        case .audio: return "waveform"
        case .pdf: return "doc.richtext"
        case .text: return "doc.text"
        case .archive: return "doc.zipper"
        case .other: return "doc"
        }
    }
    var label: String {
        switch self {
        case .folder: return "Thư mục"
        case .image: return "Hình ảnh"
        case .video: return "Video"
        case .audio: return "Âm thanh"
        case .pdf: return "PDF"
        case .text: return "Văn bản"
        case .archive: return "Tệp nén"
        case .other: return "Tệp"
        }
    }
    var tint: Color {
        switch self {
        case .folder: return .blue
        case .image: return .green
        case .video: return .purple
        case .audio: return .pink
        case .pdf: return .red
        case .text: return .gray
        case .archive: return .orange
        case .other: return .secondary
        }
    }

    static let textExt: Set<String> = ["txt", "md", "json", "xml", "csv", "log", "yml", "yaml", "swift", "py", "js", "html", "css", "ini", "conf", "rtf", "srt", "plist"]

    static func detect(_ url: URL, isDirectory: Bool) -> Kind {
        if isDirectory { return .folder }
        let ext = url.pathExtension.lowercased()
        if ext == "7z" { return .archive }
        if textExt.contains(ext) { return .text }
        guard let t = UTType(filenameExtension: ext) else { return .other }
        if t.conforms(to: .image) { return .image }
        if t.conforms(to: .movie) || t.conforms(to: .video) { return .video }
        if t.conforms(to: .audio) { return .audio }
        if t.conforms(to: .pdf) { return .pdf }
        if t.conforms(to: .archive) { return .archive }
        if t.conforms(to: .text) { return .text }
        return .other
    }
}

struct FileItem: Identifiable, Hashable {
    let url: URL
    let isDirectory: Bool
    let size: Int64?
    let modified: Date
    let created: Date?
    let kind: Kind
    var id: URL { url }
    var name: String { url.lastPathComponent }
}

enum Fmt {
    static func size(_ b: Int64) -> String {
        ByteCountFormatter.string(fromByteCount: b, countStyle: .file)
    }
    private static let dateFormatter: DateFormatter = {
        let f = DateFormatter()
        f.locale = Locale(identifier: "vi_VN")
        f.dateStyle = .medium
        f.timeStyle = .short
        return f
    }()
    static func date(_ d: Date) -> String { dateFormatter.string(from: d) }
    static func duration(_ s: Double) -> String {
        guard s.isFinite else { return "" }
        let t = Int(s)
        return t >= 3600
            ? String(format: "%d:%02d:%02d", t / 3600, (t % 3600) / 60, t % 60)
            : String(format: "%d:%02d", t / 60, t % 60)
    }
}

enum FileOps {
    static let fm = FileManager.default
    static let keys: [URLResourceKey] = [.isDirectoryKey, .fileSizeKey, .contentModificationDateKey, .creationDateKey]

    static func item(from url: URL) -> FileItem {
        let v = try? url.resourceValues(forKeys: Set(keys))
        let isDir = v?.isDirectory ?? false
        return FileItem(url: url, isDirectory: isDir,
                        size: isDir ? nil : Int64(v?.fileSize ?? 0),
                        modified: v?.contentModificationDate ?? .distantPast,
                        created: v?.creationDate,
                        kind: Kind.detect(url, isDirectory: isDir))
    }

    static func list(_ dir: URL) -> [FileItem] {
        guard let urls = try? fm.contentsOfDirectory(at: dir, includingPropertiesForKeys: keys,
                                                     options: [.skipsHiddenFiles]) else { return [] }
        return urls.map(item(from:))
    }

    static func search(in root: URL, query: String, limit: Int = 500) -> [FileItem] {
        var out: [FileItem] = []
        guard let e = fm.enumerator(at: root, includingPropertiesForKeys: keys, options: [.skipsHiddenFiles]) else { return [] }
        while let u = e.nextObject() as? URL {
            if u.lastPathComponent.localizedCaseInsensitiveContains(query) {
                out.append(item(from: u))
                if out.count >= limit { break }
            }
        }
        return out
    }

    static func all(of kind: Kind, in root: URL) -> [FileItem] {
        var out: [FileItem] = []
        guard let e = fm.enumerator(at: root, includingPropertiesForKeys: keys, options: [.skipsHiddenFiles]) else { return [] }
        while let u = e.nextObject() as? URL {
            let it = item(from: u)
            if it.kind == kind { out.append(it) }
        }
        return out.sorted { $0.modified > $1.modified }
    }

    static func size(of url: URL) -> Int64 {
        let v = try? url.resourceValues(forKeys: [.isDirectoryKey, .fileSizeKey])
        if v?.isDirectory != true { return Int64(v?.fileSize ?? 0) }
        var total: Int64 = 0
        if let e = fm.enumerator(at: url, includingPropertiesForKeys: [.fileSizeKey, .isDirectoryKey], options: []) {
            while let u = e.nextObject() as? URL {
                let r = try? u.resourceValues(forKeys: [.fileSizeKey])
                total += Int64(r?.fileSize ?? 0)
            }
        }
        return total
    }

    static func validName(_ s: String) -> String? {
        let t = s.trimmingCharacters(in: .whitespacesAndNewlines)
        if t.isEmpty || t == "." || t == ".." || t.contains("/") || t.contains(":") { return nil }
        return t
    }

    static func uniqueURL(dir: URL, name: String) -> URL {
        var c = dir.appendingPathComponent(name)
        guard fm.fileExists(atPath: c.path) else { return c }
        let ns = name as NSString
        let ext = ns.pathExtension
        let base = ns.deletingPathExtension
        var i = 1
        repeat {
            let n = ext.isEmpty ? "\(base) (\(i))" : "\(base) (\(i)).\(ext)"
            c = dir.appendingPathComponent(n)
            i += 1
        } while fm.fileExists(atPath: c.path)
        return c
    }

    static func relative(_ url: URL) -> String {
        let root = Paths.files.resolvingSymlinksInPath().path
        let p = url.resolvingSymlinksInPath().path
        guard p.hasPrefix(root) else { return url.lastPathComponent }
        var r = String(p.dropFirst(root.count))
        if r.hasPrefix("/") { r.removeFirst() }
        return r
    }

    static func isInside(_ child: URL, of parent: URL) -> Bool {
        let c = child.resolvingSymlinksInPath().path
        let p = parent.resolvingSymlinksInPath().path
        return c == p || c.hasPrefix(p + "/")
    }

    static func checkSpace(needed: Int64) throws {
        let v = try? Paths.base.resourceValues(forKeys: [.volumeAvailableCapacityForImportantUsageKey])
        if let avail = v?.volumeAvailableCapacityForImportantUsage, avail < needed + 50_000_000 {
            throw AppError("Không đủ dung lượng lưu trữ trên thiết bị.")
        }
    }
}
