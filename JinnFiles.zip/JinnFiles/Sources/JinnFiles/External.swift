import SwiftUI
import UIKit
import UniformTypeIdentifiers

// MARK: - Lưu vị trí ngoài (bookmark) — chỉ đọc, không sao chép vào app

struct ExternalLocation: Codable, Identifiable, Hashable {
    var id: UUID
    var name: String
    var bookmark: Data
    var isDirectory: Bool
}

@MainActor
final class ExternalStore: ObservableObject {
    static let shared = ExternalStore()
    @Published private(set) var locations: [ExternalLocation] = []
    @Published private(set) var resolved: [UUID: URL] = [:]
    @Published private(set) var resolving = false
    @Published private(set) var adding = false
    @Published var message: String?
    private var accessing: [UUID: URL] = [:]
    private var file: URL { Paths.meta.appendingPathComponent("external.json") }

    init() {
        Paths.bootstrap()
        if let d = try? Data(contentsOf: file),
           let l = try? JSONDecoder().decode([ExternalLocation].self, from: d) { locations = l }
        resolveAll()
    }

    private func save() {
        if let d = try? JSONEncoder().encode(locations) { try? d.write(to: file, options: .atomic) }
    }

    /// Giải mã dấu trang ở nền, không chặn giao diện
    private func resolveAll() {
        let locs = locations
        guard !locs.isEmpty else { return }
        resolving = true
        Task.detached {
            var out: [(UUID, URL, Data?)] = []
            for l in locs {
                var stale = false
                guard let u = try? URL(resolvingBookmarkData: l.bookmark, options: [], relativeTo: nil,
                                       bookmarkDataIsStale: &stale) else { continue }
                _ = u.startAccessingSecurityScopedResource()
                let nb: Data? = stale ? (try? u.bookmarkData(options: [], includingResourceValuesForKeys: nil, relativeTo: nil)) : nil
                out.append((l.id, u, nb))
            }
            await self.applyResolved(out)
        }
    }

    private func applyResolved(_ out: [(UUID, URL, Data?)]) {
        for (id, u, nb) in out {
            accessing[id] = u
            resolved[id] = u
            if let nb, let i = locations.firstIndex(where: { $0.id == id }) { locations[i].bookmark = nb }
        }
        save()
        resolving = false
    }

    func add(_ urls: [URL]) {
        guard !urls.isEmpty else { return }
        adding = true
        // Mở quyền truy cập ngay (rất nhẹ), phần nặng làm ở nền
        for u in urls { _ = u.startAccessingSecurityScopedResource() }
        Task.detached {
            var made: [(URL, Data, Bool)] = []
            for u in urls {
                if let bm = try? u.bookmarkData(options: [], includingResourceValuesForKeys: nil, relativeTo: nil) {
                    let isDir = (try? u.resourceValues(forKeys: [.isDirectoryKey]))?.isDirectory ?? u.hasDirectoryPath
                    made.append((u, bm, isDir))
                } else {
                    u.stopAccessingSecurityScopedResource()
                }
            }
            await self.finishAdd(made, requested: urls.count)
        }
    }

    private func finishAdd(_ made: [(URL, Data, Bool)], requested: Int) {
        for (u, bm, isDir) in made {
            if resolved.values.contains(where: { $0.standardizedFileURL == u.standardizedFileURL }) {
                u.stopAccessingSecurityScopedResource()
                continue
            }
            let loc = ExternalLocation(id: UUID(), name: u.lastPathComponent, bookmark: bm, isDirectory: isDir)
            locations.append(loc)
            resolved[loc.id] = u
            accessing[loc.id] = u
        }
        save()
        adding = false
        if made.count < requested {
            message = "Không thể ghi nhớ \(requested - made.count) mục (không có quyền truy cập)."
        }
    }

    /// Chỉ gỡ lối tắt, tuyệt đối không xóa tệp thật
    func remove(_ l: ExternalLocation) {
        accessing[l.id]?.stopAccessingSecurityScopedResource()
        accessing[l.id] = nil
        resolved[l.id] = nil
        locations.removeAll { $0.id == l.id }
        save()
    }
}

enum PickerMode: String, Identifiable {
    case file, folder
    var id: String { rawValue }
}

struct ExternalPicker: UIViewControllerRepresentable {
    let mode: PickerMode
    var onPick: ([URL]) -> Void
    func makeUIViewController(context: Context) -> UIDocumentPickerViewController {
        // asCopy: false -> mở tại chỗ, không sao chép. Chỉ một loại nội dung để bộ chọn mở nhanh hơn.
        let p = UIDocumentPickerViewController(forOpeningContentTypes: mode == .folder ? [.folder] : [.item], asCopy: false)
        p.allowsMultipleSelection = (mode == .file)
        p.delegate = context.coordinator
        return p
    }
    func updateUIViewController(_ vc: UIDocumentPickerViewController, context: Context) {}
    func makeCoordinator() -> Coord { Coord(onPick) }
    final class Coord: NSObject, UIDocumentPickerDelegate {
        let onPick: ([URL]) -> Void
        init(_ f: @escaping ([URL]) -> Void) { onPick = f }
        func documentPicker(_ c: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) { onPick(urls) }
    }
}

// MARK: - Tab "Trực tiếp"

struct ExternalTab: View {
    @StateObject private var store = ExternalStore.shared
    @State private var showFile = false
    @State private var showFolder = false

    /// Không đọc ổ đĩa trên luồng giao diện: dựng thông tin từ dữ liệu đã lưu
    private func lightItem(_ l: ExternalLocation, _ u: URL) -> FileItem {
        FileItem(url: u, isDirectory: l.isDirectory, size: nil, modified: .distantPast, created: nil,
                 kind: Kind.detect(u, isDirectory: l.isDirectory))
    }

    private func handle(_ r: Result<[URL], Error>) {
        switch r {
        case .success(let urls): store.add(urls)
        case .failure(let e): store.message = "Lỗi: \(e.localizedDescription)"
        }
    }

    var body: some View {
        NavigationStack {
            Group {
                if store.locations.isEmpty && !store.adding {
                    ContentUnavailableView {
                        Label("Xem trực tiếp", systemImage: "externaldrive")
                    } description: {
                        Text("Chọn tệp hoặc thư mục trên iPhone (Tệp, iCloud Drive, ổ USB...) để xem ngay, không cần nhập vào ứng dụng.")
                    } actions: {
                        Button("Chọn thư mục") { showFolder = true }.buttonStyle(.borderedProminent)
                        Button("Chọn tệp") { showFile = true }
                    }
                } else {
                    List {
                        if store.adding { HStack { ProgressView(); Text("Đang thêm…").foregroundStyle(.secondary) } }
                        ForEach(store.locations) { l in
                            if let u = store.resolved[l.id] {
                                let item = lightItem(l, u)
                                NavigationLink(value: item) {
                                    HStack(spacing: 12) {
                                        ThumbView(item: item).frame(width: 44, height: 44)
                                            .clipShape(RoundedRectangle(cornerRadius: 8))
                                        VStack(alignment: .leading, spacing: 2) {
                                            Text(l.name).lineLimit(1)
                                            Text(l.isDirectory ? "Thư mục" : item.kind.label).font(.caption).foregroundStyle(.secondary)
                                        }
                                    }
                                }
                                .swipeActions { Button(role: .destructive) { store.remove(l) } label: { Label("Gỡ", systemImage: "minus.circle") } }
                            } else if store.resolving {
                                HStack { ProgressView(); Text(l.name).foregroundStyle(.secondary) }
                            } else {
                                Label("\(l.name) — không còn truy cập được", systemImage: "exclamationmark.triangle")
                                    .foregroundStyle(.red)
                                    .swipeActions { Button(role: .destructive) { store.remove(l) } label: { Label("Gỡ", systemImage: "minus.circle") } }
                            }
                        }
                        Section {} footer: { Text("Vuốt sang trái để gỡ khỏi danh sách. Việc gỡ không xóa tệp gốc.") }
                    }
                }
            }
            .navigationTitle("Xem trực tiếp")
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Menu {
                        Button { showFolder = true } label: { Label("Chọn thư mục", systemImage: "folder.badge.plus") }
                        Button { showFile = true } label: { Label("Chọn tệp", systemImage: "doc.badge.plus") }
                    } label: { Image(systemName: "plus") }
                }
            }
            .fileImporter(isPresented: $showFile, allowedContentTypes: [.item], allowsMultipleSelection: true) { r in
                handle(r)
            }
            .alert("Thông báo", isPresented: Binding(get: { store.message != nil }, set: { if !$0 { store.message = nil } })) {
                Button("OK") { store.message = nil }
            } message: { Text(store.message ?? "") }
            .navigationDestination(for: FileItem.self) { item in
                if item.isDirectory {
                    ExternalFolderView(url: item.url)
                } else {
                    ExternalFilePreview(url: item.url)
                }
            }
        }
        .fileImporter(isPresented: $showFolder, allowedContentTypes: [.folder], allowsMultipleSelection: false) { r in
            handle(r)
        }
    }
}

struct ExternalFilePreview: View {
    let url: URL
    @State private var item: FileItem?
    @State private var error: String?
    var body: some View {
        Group {
            if let item { PreviewView(item: item) }
            else if let error {
                ContentUnavailableView("Không mở được tệp", systemImage: "exclamationmark.triangle", description: Text(error))
            } else {
                VStack(spacing: 10) { ProgressView(); Text("Đang chuẩn bị tệp…").font(.footnote).foregroundStyle(.secondary) }
            }
        }
        .navigationTitle(url.lastPathComponent)
        .navigationBarTitleDisplayMode(.inline)
        .task {
            let u = url
            let r: String? = await Task.detached { ExternalAccess.materialize(u) }.value
            if let r { error = r } else { item = FileOps.item(from: u) }
        }
    }
}

// MARK: - Duyệt thư mục ngoài (chỉ đọc)

struct ExternalFolderView: View {
    let url: URL
    @State private var items: [FileItem] = []
    @State private var query = ""
    @State private var loading = true
    @State private var copyTarget: FileItem?
    @State private var busy = false
    @State private var message: String?

    private var shown: [FileItem] {
        let b = query.isEmpty ? items : items.filter { $0.name.localizedCaseInsensitiveContains(query) }
        return b.sorted {
            if $0.isDirectory != $1.isDirectory { return $0.isDirectory }
            return $0.name.localizedStandardCompare($1.name) == .orderedAscending
        }
    }

    var body: some View {
        Group {
            if loading { ProgressView() }
            else if shown.isEmpty {
                ContentUnavailableView(query.isEmpty ? "Thư mục trống" : "Không tìm thấy", systemImage: "folder")
            } else {
                List(shown) { item in
                    NavigationLink(value: item) {
                        HStack(spacing: 12) {
                            ThumbView(item: item).frame(width: 44, height: 44)
                                .clipShape(RoundedRectangle(cornerRadius: 8))
                            VStack(alignment: .leading, spacing: 2) {
                                Text(item.name).lineLimit(1)
                                Text([item.size.map(Fmt.size), Fmt.date(item.modified)].compactMap { $0 }.joined(separator: " • "))
                                    .font(.caption).foregroundStyle(.secondary)
                            }
                        }
                    }
                    .contextMenu {
                        Button { copyTarget = item } label: { Label("Sao chép vào Jinn Files…", systemImage: "square.and.arrow.down") }
                        if !item.isDirectory { ShareLink(item: item.url) { Label("Chia sẻ", systemImage: "square.and.arrow.up") } }
                    }
                }
                .listStyle(.plain)
            }
        }
        .navigationTitle(url.lastPathComponent)
        .navigationBarTitleDisplayMode(.inline)
        .searchable(text: $query, prompt: "Tìm theo tên")
        .refreshable { await load() }
        .task { await load() }
        .overlay { if busy { ProgressView("Đang sao chép…").padding(20).background(.regularMaterial, in: RoundedRectangle(cornerRadius: 14)) } }
        .sheet(item: $copyTarget) { t in
            FolderPicker(title: "Sao chép vào…", exclude: []) { dest in copy(t, to: dest) }
        }
        .alert("Thông báo", isPresented: Binding(get: { message != nil }, set: { if !$0 { message = nil } })) {
            Button("OK") { message = nil }
        } message: { Text(message ?? "") }
    }

    private func load() async {
        let u = url
        items = await Task.detached { FileOps.list(u) }.value
        loading = false
    }

    private func copy(_ item: FileItem, to dest: URL) {
        busy = true
        let src = item.url
        Task {
            let result: String = await Task.detached {
                do {
                    try FileOps.checkSpace(needed: FileOps.size(of: src))
                    var err: NSError?
                    var inner: Error?
                    NSFileCoordinator().coordinate(readingItemAt: src, options: [.withoutChanges], error: &err) { r in
                        do { try FileManager.default.copyItem(at: r, to: FileOps.uniqueURL(dir: dest, name: src.lastPathComponent)) }
                        catch { inner = error }
                    }
                    if let e = err { throw e }
                    if let e = inner { throw e }
                    return "Đã sao chép vào Jinn Files."
                } catch { return "Lỗi: \(error.localizedDescription)" }
            }.value
            busy = false
            message = result
        }
    }
}
