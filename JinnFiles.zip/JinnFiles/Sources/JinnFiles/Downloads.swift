import SwiftUI
import UIKit

/// Thư mục tạm, dùng ngoài MainActor
let downloadStagingDir = Paths.base.appendingPathComponent("DownloadStaging", isDirectory: true)

final class AppDelegate: NSObject, UIApplicationDelegate {
    nonisolated(unsafe) static var backgroundCompletion: (() -> Void)?

    func application(_ application: UIApplication, handleEventsForBackgroundURLSession identifier: String,
                     completionHandler: @escaping () -> Void) {
        AppDelegate.backgroundCompletion = completionHandler
        _ = DownloadManager.shared   // dựng lại phiên tải để nhận các sự kiện đang chờ
    }
}

enum DownloadState: String, Codable {
    case queued, downloading, paused, completed, failed
}

struct DownloadRecord: Codable, Identifiable, Equatable {
    var id: UUID
    var url: String
    var fileName: String
    var destPath: String            // tương đối so với Files/ ("" = thư mục gốc)
    var state: DownloadState
    var received: Int64
    var total: Int64
    var error: String?
    var created: Date
    var finished: Date?
    var savedPath: String?

    var fraction: Double { total > 0 ? min(1, Double(received) / Double(total)) : 0 }
}

/// Bộ nhận sự kiện của phiên tải nền
final class DownloadDelegate: NSObject, URLSessionDownloadDelegate, @unchecked Sendable {
    weak var manager: DownloadManager?
    private var lastTick: [Int: Date] = [:]

    private func uuid(_ t: URLSessionTask) -> UUID? { t.taskDescription.flatMap { UUID(uuidString: $0) } }

    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didWriteData bytesWritten: Int64,
                    totalBytesWritten: Int64, totalBytesExpectedToWrite: Int64) {
        guard let id = uuid(downloadTask) else { return }
        let now = Date()
        if let last = lastTick[downloadTask.taskIdentifier], now.timeIntervalSince(last) < 0.3,
           totalBytesWritten != totalBytesExpectedToWrite { return }
        lastTick[downloadTask.taskIdentifier] = now
        Task { @MainActor in self.manager?.progress(id, received: totalBytesWritten, total: totalBytesExpectedToWrite) }
    }

    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didFinishDownloadingTo location: URL) {
        guard let id = uuid(downloadTask) else { return }
        let code = (downloadTask.response as? HTTPURLResponse)?.statusCode ?? 200
        let suggested = downloadTask.response?.suggestedFilename
        guard (200..<300).contains(code) else {
            Task { @MainActor in self.manager?.fail(id, "Máy chủ trả về mã lỗi \(code).", resume: nil) }
            return
        }
        let fm = FileManager.default
        try? fm.createDirectory(at: downloadStagingDir, withIntermediateDirectories: true)
        let staged = downloadStagingDir.appendingPathComponent(id.uuidString)
        try? fm.removeItem(at: staged)
        do { try fm.moveItem(at: location, to: staged) }
        catch {
            let m = error.localizedDescription
            Task { @MainActor in self.manager?.fail(id, m, resume: nil) }
            return
        }
        Task { @MainActor in self.manager?.finish(id, staged: staged, suggested: suggested) }
    }

    func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        guard let error, let id = uuid(task) else { return }
        let ns = error as NSError
        let resume = ns.userInfo[NSURLSessionDownloadTaskResumeData] as? Data
        let cancelled = ns.code == NSURLErrorCancelled
        let msg = error.localizedDescription
        Task { @MainActor in
            if cancelled { self.manager?.cancelledByUser(id, resume: resume) }
            else { self.manager?.fail(id, msg, resume: resume) }
        }
    }

    func urlSessionDidFinishEvents(forBackgroundURLSession session: URLSession) {
        DispatchQueue.main.async {
            AppDelegate.backgroundCompletion?()
            AppDelegate.backgroundCompletion = nil
        }
    }
}

@MainActor
final class DownloadManager: NSObject, ObservableObject {
    static let shared = DownloadManager()

    @Published private(set) var records: [DownloadRecord] = []
    private var session: URLSession!
    private var tasks: [UUID: URLSessionDownloadTask] = [:]
    private var headers: [UUID: [String: String]] = [:]
    private let delegate = DownloadDelegate()
    private var file: URL { Paths.meta.appendingPathComponent("downloads.json") }

    override init() {
        super.init()
        Paths.bootstrap()
        load()
        let cfg = URLSessionConfiguration.background(withIdentifier: "com.jinn.JinnFiles.downloads")
        cfg.sessionSendsLaunchEvents = true
        cfg.isDiscretionary = false
        cfg.waitsForConnectivity = true
        delegate.manager = self
        session = URLSession(configuration: cfg, delegate: delegate, delegateQueue: nil)
        session.getAllTasks { tasks in
            Task { @MainActor in self.adopt(tasks) }
        }
    }

    // MARK: Lưu trữ

    private func load() {
        if let d = try? Data(contentsOf: file) {
            let dec = JSONDecoder(); dec.dateDecodingStrategy = .iso8601
            records = (try? dec.decode([DownloadRecord].self, from: d)) ?? []
        }
    }

    private func save() {
        let enc = JSONEncoder(); enc.dateEncodingStrategy = .iso8601
        if let d = try? enc.encode(records) { try? d.write(to: file, options: .atomic) }
    }

    private func resumeFile(_ id: UUID) -> URL { Paths.meta.appendingPathComponent("resume-\(id.uuidString).data") }
    private func index(_ id: UUID) -> Int? { records.firstIndex { $0.id == id } }

    private func adopt(_ list: [URLSessionTask]) {
        for t in list {
            guard let d = t.taskDescription, let id = UUID(uuidString: d), let dt = t as? URLSessionDownloadTask else { continue }
            tasks[id] = dt
            if let i = index(id), records[i].state != .completed { records[i].state = .downloading }
        }
        // Mục đang tải nhưng không còn tác vụ (ứng dụng bị đóng đột ngột)
        for i in records.indices where records[i].state == .downloading && tasks[records[i].id] == nil {
            records[i].state = .failed
            records[i].error = "Bị gián đoạn. Bấm Tải lại để tiếp tục."
        }
        save()
    }

    // MARK: Điều khiển

    func enqueue(url: URL, fileName: String, destPath: String, headers: [String: String] = [:]) {
        let rec = DownloadRecord(id: UUID(), url: url.absoluteString, fileName: fileName, destPath: destPath,
                                 state: .downloading, received: 0, total: 0, error: nil,
                                 created: Date(), finished: nil, savedPath: nil)
        records.insert(rec, at: 0)
        self.headers[rec.id] = headers
        start(rec.id)
    }

    private func start(_ id: UUID) {
        guard let i = index(id) else { return }
        let task: URLSessionDownloadTask
        if let data = try? Data(contentsOf: resumeFile(id)) {
            task = session.downloadTask(withResumeData: data)
            try? FileManager.default.removeItem(at: resumeFile(id))
        } else {
            guard let url = URL(string: records[i].url) else { fail(id, "Địa chỉ không hợp lệ.", resume: nil); return }
            var req = URLRequest(url: url)
            for (k, v) in headers[id] ?? [:] { req.setValue(v, forHTTPHeaderField: k) }
            task = session.downloadTask(with: req)
        }
        task.taskDescription = id.uuidString
        tasks[id] = task
        records[i].state = .downloading
        records[i].error = nil
        task.resume()
        save()
    }

    func pause(_ id: UUID) {
        guard let i = index(id), let t = tasks[id] else { return }
        records[i].state = .paused
        t.cancel(byProducingResumeData: { data in
            Task { @MainActor in self.cancelledByUser(id, resume: data) }
        })
        tasks[id] = nil
        save()
    }

    func resume(_ id: UUID) { start(id) }
    func retry(_ id: UUID) { start(id) }

    func remove(_ id: UUID, deleteFile: Bool = false) {
        tasks[id]?.cancel()
        tasks[id] = nil
        try? FileManager.default.removeItem(at: resumeFile(id))
        if deleteFile, let i = index(id), let p = records[i].savedPath {
            try? FileManager.default.removeItem(at: Paths.files.appendingPathComponent(p))
        }
        records.removeAll { $0.id == id }
        save()
    }

    func clearHistory() {
        records.removeAll { $0.state == .completed }
        save()
    }

    // MARK: Sự kiện từ phiên tải

    fileprivate func progress(_ id: UUID, received: Int64, total: Int64) {
        guard let i = index(id), records[i].state == .downloading else { return }
        records[i].received = received
        records[i].total = max(total, 0)
    }

    fileprivate func cancelledByUser(_ id: UUID, resume: Data?) {
        guard let i = index(id) else { return }
        if let data = resume { try? data.write(to: resumeFile(id), options: .atomic) }
        if records[i].state != .paused { return }
        save()
    }

    fileprivate func fail(_ id: UUID, _ message: String, resume: Data?) {
        guard let i = index(id) else { return }
        if let data = resume { try? data.write(to: resumeFile(id), options: .atomic) }
        tasks[id] = nil
        if records[i].state == .paused { return }
        records[i].state = .failed
        records[i].error = message
        save()
    }

    fileprivate func finish(_ id: UUID, staged: URL, suggested: String?) {
        guard let i = index(id) else { try? FileManager.default.removeItem(at: staged); return }
        tasks[id] = nil
        let fm = FileManager.default
        let dir = records[i].destPath.isEmpty ? Paths.files : Paths.files.appendingPathComponent(records[i].destPath, isDirectory: true)
        var name = records[i].fileName.trimmingCharacters(in: .whitespacesAndNewlines)
        if name.isEmpty { name = suggested ?? "tai-xuong" }
        if (name as NSString).pathExtension.isEmpty, let s = suggested, !(s as NSString).pathExtension.isEmpty {
            name += "." + (s as NSString).pathExtension
        }
        name = name.replacingOccurrences(of: "/", with: "-")
        do {
            try fm.createDirectory(at: dir, withIntermediateDirectories: true)
            let target = FileOps.uniqueURL(dir: dir, name: name)
            try fm.moveItem(at: staged, to: target)
            let size = FileOps.size(of: target)
            records[i].state = .completed
            records[i].received = size
            records[i].total = size
            records[i].finished = Date()
            records[i].savedPath = FileOps.relative(target)
            records[i].fileName = target.lastPathComponent
            records[i].error = nil
        } catch {
            records[i].state = .failed
            records[i].error = error.localizedDescription
        }
        headers[id] = nil
        save()
    }
}

// MARK: - Giao diện

struct DownloadManagerView: View {
    @EnvironmentObject private var dm: DownloadManager
    @AppStorage("downloadFolder") private var downloadFolder = "Downloads"
    @State private var showAdd = false
    @State private var newURL = ""
    @State private var showFolderPicker = false

    private var active: [DownloadRecord] { dm.records.filter { $0.state != .completed } }
    private var history: [DownloadRecord] { dm.records.filter { $0.state == .completed } }

    var body: some View {
        List {
            Section {
                Button { showFolderPicker = true } label: {
                    LabeledContent("Thư mục lưu mặc định") {
                        Text("Files/" + downloadFolder).foregroundStyle(.secondary).lineLimit(1)
                    }
                }
                .buttonStyle(.plain)
            }
            if !active.isEmpty {
                Section("Đang tải") { ForEach(active) { activeRow($0) } }
            }
            Section("Lịch sử tải xuống") {
                if history.isEmpty { Text("Chưa có tệp nào tải xong").foregroundStyle(.secondary) }
                ForEach(history) { historyRow($0) }
            }
        }
        .navigationTitle("Tải xuống")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Menu {
                    Button { newURL = ""; showAdd = true } label: { Label("Thêm liên kết tải xuống", systemImage: "plus") }
                    Button { showFolderPicker = true } label: { Label("Chọn thư mục lưu", systemImage: "folder") }
                    Button(role: .destructive) { dm.clearHistory() } label: { Label("Xóa lịch sử", systemImage: "trash") }
                } label: { Image(systemName: "ellipsis.circle") }
            }
        }
        .alert("Thêm liên kết", isPresented: $showAdd) {
            TextField("https://…", text: $newURL)
                .textInputAutocapitalization(.never).autocorrectionDisabled().keyboardType(.URL)
            Button("Hủy", role: .cancel) {}
            Button("Tải xuống") {
                if let u = URL(string: newURL.trimmingCharacters(in: .whitespacesAndNewlines)), u.scheme?.hasPrefix("http") == true {
                    let name = u.lastPathComponent.isEmpty ? "tai-xuong" : u.lastPathComponent
                    dm.enqueue(url: u, fileName: name, destPath: downloadFolder)
                }
            }
        }
        .sheet(isPresented: $showFolderPicker) {
            FolderPicker(title: "Lưu tệp tải xuống vào…", exclude: []) { downloadFolder = FileOps.relative($0) }
        }
    }

    private func activeRow(_ r: DownloadRecord) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack {
                Image(systemName: icon(r.state)).foregroundStyle(color(r.state))
                Text(r.fileName).lineLimit(1)
                Spacer()
                actionButtons(r)
            }
            if r.state == .downloading || r.state == .paused {
                if r.total > 0 { ProgressView(value: r.fraction) } else { ProgressView() }
            }
            Text(detail(r)).font(.caption).foregroundStyle(r.state == .failed ? Color.red : Color.secondary).lineLimit(2)
        }
        .padding(.vertical, 2)
    }

    @ViewBuilder private func actionButtons(_ r: DownloadRecord) -> some View {
        HStack(spacing: 14) {
            switch r.state {
            case .downloading, .queued:
                Button { dm.pause(r.id) } label: { Image(systemName: "pause.circle") }
            case .paused:
                Button { dm.resume(r.id) } label: { Image(systemName: "play.circle") }
            case .failed:
                Button { dm.retry(r.id) } label: { Image(systemName: "arrow.clockwise.circle") }
            case .completed:
                EmptyView()
            }
            Button(role: .destructive) { dm.remove(r.id) } label: { Image(systemName: "xmark.circle") }
        }
        .font(.title3)
        .buttonStyle(.borderless)
    }

    private func historyRow(_ r: DownloadRecord) -> some View {
        let url = r.savedPath.map { Paths.files.appendingPathComponent($0) }
        return Group {
            if let url, FileManager.default.fileExists(atPath: url.path) {
                NavigationLink { PreviewView(item: FileOps.item(from: url)) } label: { historyLabel(r) }
            } else {
                historyLabel(r).foregroundStyle(.secondary)
            }
        }
        .swipeActions {
            Button(role: .destructive) { dm.remove(r.id) } label: { Label("Xóa khỏi lịch sử", systemImage: "trash") }
        }
        .contextMenu {
            if let url { ShareLink(item: url) { Label("Chia sẻ", systemImage: "square.and.arrow.up") } }
            Button(role: .destructive) { dm.remove(r.id, deleteFile: true) } label: { Label("Xóa cả tệp", systemImage: "trash") }
        }
    }

    private func historyLabel(_ r: DownloadRecord) -> some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(r.fileName).lineLimit(1)
            Text("\(Fmt.size(r.total)) • \(r.finished.map(Fmt.date) ?? "") • Files/\(r.savedPath ?? "")")
                .font(.caption).foregroundStyle(.secondary).lineLimit(2)
        }
    }

    private func detail(_ r: DownloadRecord) -> String {
        switch r.state {
        case .downloading: return r.total > 0 ? "\(Fmt.size(r.received)) / \(Fmt.size(r.total)) • \(Int(r.fraction * 100))%" : "\(Fmt.size(r.received)) • đang tải…"
        case .paused: return "Tạm dừng • \(Fmt.size(r.received))" + (r.total > 0 ? " / \(Fmt.size(r.total))" : "")
        case .queued: return "Đang chờ"
        case .failed: return r.error ?? "Tải thất bại"
        case .completed: return ""
        }
    }

    private func icon(_ s: DownloadState) -> String {
        switch s {
        case .downloading, .queued: return "arrow.down.circle"
        case .paused: return "pause.circle"
        case .failed: return "exclamationmark.triangle"
        case .completed: return "checkmark.circle"
        }
    }

    private func color(_ s: DownloadState) -> Color {
        switch s {
        case .downloading, .queued: return Color.accentColor
        case .paused: return .orange
        case .failed: return .red
        case .completed: return .green
        }
    }
}

/// Hộp thoại lưu tệp khi tải từ trình duyệt
struct DownloadPromptView: View {
    let pending: PendingDownload
    @EnvironmentObject private var dm: DownloadManager
    @Environment(\.dismiss) private var dismiss
    @AppStorage("downloadFolder") private var folder = "Downloads"
    @State private var name = ""
    @State private var showPicker = false

    var body: some View {
        NavigationStack {
            Form {
                Section("Tệp") {
                    TextField("Tên tệp", text: $name)
                    LabeledContent("Từ", value: pending.url.host ?? pending.url.absoluteString)
                    if pending.size > 0 { LabeledContent("Dung lượng", value: Fmt.size(pending.size)) }
                }
                Section("Lưu vào Jinn Files") {
                    Button { showPicker = true } label: {
                        HStack {
                            Image(systemName: "folder.fill").foregroundStyle(Color.accentColor)
                            Text("Files/" + folder)
                            Spacer()
                            Image(systemName: "chevron.right").font(.footnote).foregroundStyle(.tertiary)
                        }
                    }
                    .buttonStyle(.plain)
                }
            }
            .navigationTitle("Tải xuống")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) { Button("Hủy") { dismiss() } }
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Tải xuống") {
                        dm.enqueue(url: pending.url, fileName: name, destPath: folder, headers: pending.headers)
                        dismiss()
                    }
                    .fontWeight(.semibold)
                    .disabled(name.trimmingCharacters(in: .whitespaces).isEmpty)
                }
            }
            .onAppear { name = pending.fileName }
            .sheet(isPresented: $showPicker) {
                FolderPicker(title: "Lưu vào…", exclude: []) { folder = FileOps.relative($0) }
            }
        }
        .presentationDetents([.medium, .large])
    }
}
