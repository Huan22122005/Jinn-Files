// swift-tools-version: 5.9
import PackageDescription

let package = Package(
    name: "JinnFiles",
    platforms: [.iOS(.v17), .macOS(.v14)],
    products: [
        .library(name: "JinnFiles", targets: ["JinnFiles"])
    ],
    dependencies: [
        .package(url: "https://github.com/weichsel/ZIPFoundation.git", from: "0.9.19"),
        // Thư viện Swift thuần (không có mã C/x86), biên dịch chéo sang iOS được
        .package(url: "https://github.com/tsolomko/SWCompression.git", from: "4.8.0")
    ],
    targets: [
        .target(
            name: "JinnFiles",
            dependencies: [
                .product(name: "ZIPFoundation", package: "ZIPFoundation"),
                .product(name: "SWCompression", package: "SWCompression")
            ]
        )
    ]
)
