# Jinn Files 2.0

- Tab: Tệp của tôi, Công cụ (Gửi nhanh), Tài khoản (Google Photos), Thùng rác, Cài đặt.
- Giao diện Liquid Glass (iOS 26+), tự dùng vật liệu mờ trên bản cũ hơn.
- Build: GitHub Actions (macos-26, Xcode 26) hoặc `xtool dev build -c release --ipa`.
- Google Photos: nhập OAuth Client ID (loại iOS) trong tab Tài khoản.
