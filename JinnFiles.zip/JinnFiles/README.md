# Jinn Files

Build (WSL Ubuntu, trong thư mục dự án):

    xtool dev build -c debug
    xtool dev build -c release --ipa      # -> xtool/JinnFiles.ipa

Thư viện: ZIPFoundation (ZIP), SWCompression (7Z, Swift thuần).
Dữ liệu: Documents/JinnFiles/{Files,Trash,Thumbnails,Metadata}.
