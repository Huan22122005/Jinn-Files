# Jinn Files 3.0

- Tab: Tệp của tôi (có thư mục Google Drive), Công cụ (Gửi nhanh), Tài khoản (Google), Thùng rác, Cài đặt.
- Google Drive: duyệt, tạo thư mục, đổi tên, di chuyển, sao chép, xóa, tải lên/tải về.
- Giao diện Liquid Glass (iOS 26+), 7 bảng màu, nền sáng/tối.
- Build: GitHub Actions (macos-26, Xcode 26).
